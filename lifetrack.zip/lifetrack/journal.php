<?php
/**
 * LifeTrack - Personal Growth Diary & Journal
 */
require_once __DIR__ . '/includes/auth.php';

require_login();

$user_id = current_user_id();
$pdo = get_db();
$today = get_current_date();

// Handle Form Submissions: Create, Update, Delete
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        set_flash('danger', 'Security token expired. Please try again.');
        header('Location: journal.php');
        exit;
    }

    if ($action === 'create_entry') {
        $entry_date = !empty($_POST['entry_date']) ? trim($_POST['entry_date']) : $today;
        $title = trim($_POST['title'] ?? '');
        $mood = in_array($_POST['mood'] ?? '', ['great', 'good', 'okay', 'difficult', 'very_difficult']) ? $_POST['mood'] : 'good';
        $content = trim($_POST['content'] ?? '');
        $gratitude = trim($_POST['gratitude'] ?? '');
        $lessons = trim($_POST['lessons'] ?? '');

        if (empty($title) || empty($content)) {
            set_flash('danger', 'Both title and journal content are required.');
        } else {
            $stmt = $pdo->prepare("
                INSERT INTO journal_entries (user_id, entry_date, title, content, mood, gratitude, lessons) 
                VALUES (:user_id, :entry_date, :title, :content, :mood, :gratitude, :lessons)
            ");
            $stmt->execute([
                'user_id' => $user_id,
                'entry_date' => $entry_date,
                'title' => $title,
                'content' => $content,
                'mood' => $mood,
                'gratitude' => $gratitude ?: null,
                'lessons' => $lessons ?: null
            ]);
            set_flash('success', 'Journal entry saved successfully.');
        }
        header('Location: journal.php');
        exit;
    }

    if ($action === 'update_entry') {
        $entry_id = (int)($_POST['entry_id'] ?? 0);
        $entry_date = !empty($_POST['entry_date']) ? trim($_POST['entry_date']) : $today;
        $title = trim($_POST['title'] ?? '');
        $mood = in_array($_POST['mood'] ?? '', ['great', 'good', 'okay', 'difficult', 'very_difficult']) ? $_POST['mood'] : 'good';
        $content = trim($_POST['content'] ?? '');
        $gratitude = trim($_POST['gratitude'] ?? '');
        $lessons = trim($_POST['lessons'] ?? '');

        if ($entry_id <= 0 || empty($title) || empty($content)) {
            set_flash('danger', 'Valid title and content are required.');
        } else {
            $stmt = $pdo->prepare("
                UPDATE journal_entries 
                SET entry_date = :entry_date, title = :title, content = :content, mood = :mood, gratitude = :gratitude, lessons = :lessons 
                WHERE id = :id AND user_id = :user_id
            ");
            $stmt->execute([
                'entry_date' => $entry_date,
                'title' => $title,
                'content' => $content,
                'mood' => $mood,
                'gratitude' => $gratitude ?: null,
                'lessons' => $lessons ?: null,
                'id' => $entry_id,
                'user_id' => $user_id
            ]);
            set_flash('success', 'Journal entry updated.');
        }
        header('Location: journal.php');
        exit;
    }

    if ($action === 'delete_entry') {
        $entry_id = (int)($_POST['entry_id'] ?? 0);
        if ($entry_id > 0) {
            $stmt = $pdo->prepare("DELETE FROM journal_entries WHERE id = :id AND user_id = :user_id");
            $stmt->execute(['id' => $entry_id, 'user_id' => $user_id]);
            set_flash('success', 'Journal entry deleted.');
        }
        header('Location: journal.php');
        exit;
    }
}

// Search and Filter Handling
$search_query = trim($_GET['q'] ?? '');
$filter_date = trim($_GET['date'] ?? '');
$filter_mood = trim($_GET['mood'] ?? '');

$sql = "SELECT * FROM journal_entries WHERE user_id = :user_id";
$params = ['user_id' => $user_id];

if (!empty($search_query)) {
    $sql .= " AND (title LIKE :search OR content LIKE :search OR gratitude LIKE :search OR lessons LIKE :search)";
    $params['search'] = '%' . $search_query . '%';
}

if (!empty($filter_date)) {
    $sql .= " AND entry_date = :entry_date";
    $params['entry_date'] = $filter_date;
}

if (!empty($filter_mood)) {
    $sql .= " AND mood = :mood";
    $params['mood'] = $filter_mood;
}

$sql .= " ORDER BY entry_date DESC, id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$entries = $stmt->fetchAll();

// Check if an entry was requested for editing via GET
$editing_entry = null;
if (isset($_GET['edit'])) {
    $edit_id = (int)$_GET['edit'];
    $edit_stmt = $pdo->prepare("SELECT * FROM journal_entries WHERE id = :id AND user_id = :user_id LIMIT 1");
    $edit_stmt->execute(['id' => $edit_id, 'user_id' => $user_id]);
    $editing_entry = $edit_stmt->fetch() ?: null;
}

$page_title = 'Journal & Diary - LifeTrack';
$page_heading = "Personal Growth Journal";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<main class="app-main">
    <?php require_once __DIR__ . '/includes/navbar.php'; ?>

    <div class="app-content">
        <?php $flash = get_flash(); if ($flash): ?>
            <div class="alert alert-<?= e($flash['type']) ?> alert-dismissible fade show mb-4 rounded-3 border-0 shadow-sm" role="alert">
                <i class="bi bi-info-circle-fill me-2"></i> <?= e($flash['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Search & Actions Header Bar -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-3">
                <form method="GET" action="journal.php" class="row g-2 align-items-center">
                    <div class="col-md-5">
                        <div class="input-group">
                            <span class="input-group-text bg-light text-muted border-end-0"><i class="bi bi-search"></i></span>
                            <input type="text" name="q" class="form-control border-start-0" placeholder="Search title, reflections, gratitude..." value="<?= e($search_query) ?>">
                        </div>
                    </div>
                    <div class="col-sm-3 col-md-2">
                        <input type="date" name="date" class="form-control" value="<?= e($filter_date) ?>" title="Filter by date">
                    </div>
                    <div class="col-sm-3 col-md-2">
                        <select name="mood" class="form-select">
                            <option value="">All Moods</option>
                            <option value="great" <?= $filter_mood === 'great' ? 'selected' : '' ?>>😊 Great</option>
                            <option value="good" <?= $filter_mood === 'good' ? 'selected' : '' ?>>🙂 Good</option>
                            <option value="okay" <?= $filter_mood === 'okay' ? 'selected' : '' ?>>😐 Okay</option>
                            <option value="difficult" <?= $filter_mood === 'difficult' ? 'selected' : '' ?>>😔 Difficult</option>
                            <option value="very_difficult" <?= $filter_mood === 'very_difficult' ? 'selected' : '' ?>>😣 Very difficult</option>
                        </select>
                    </div>
                    <div class="col-auto d-flex gap-2">
                        <button type="submit" class="btn btn-light">Filter</button>
                        <?php if ($search_query || $filter_date || $filter_mood): ?>
                            <a href="journal.php" class="btn btn-outline-secondary">Reset</a>
                        <?php endif; ?>
                    </div>
                    <div class="col text-end">
                        <button type="button" class="btn btn-primary d-inline-flex align-items-center gap-1 shadow-sm" data-bs-toggle="modal" data-bs-target="#newEntryModal">
                            <i class="bi bi-pencil-square"></i> <span class="d-none d-sm-inline">New Journal Entry</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Journal Entries List -->
        <?php if (empty($entries)): ?>
            <div class="card border-0 shadow-sm">
                <div class="card-body p-5">
                    <div class="empty-state">
                        <div class="empty-state-icon">
                            <i class="bi bi-journal-text"></i>
                        </div>
                        <h5 class="empty-state-title">
                            <?= ($search_query || $filter_date || $filter_mood) ? 'No entries match your search' : 'Your journal is empty' ?>
                        </h5>
                        <p class="empty-state-text">
                            <?= ($search_query || $filter_date || $filter_mood) ? 'Try adjusting your search criteria or resetting filters.' : 'Journaling regularly helps clarify your thoughts, cultivate gratitude, and document your spiritual and personal growth.' ?>
                        </p>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#newEntryModal">
                            <i class="bi bi-pencil-square me-1"></i> Write Your First Entry
                        </button>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="row g-4">
                <?php foreach ($entries as $item): 
                    $mood = get_mood_details($item['mood']);
                ?>
                    <div class="col-lg-6">
                        <div class="journal-card h-100 d-flex flex-column justify-content-between">
                            <div>
                                <!-- Entry Header -->
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <div class="d-flex align-items-center gap-2">
                                        <span class="mood-badge">
                                            <span><?= $mood['emoji'] ?></span>
                                            <span><?= $mood['label'] ?></span>
                                        </span>
                                        <span class="text-muted small fw-medium">
                                            <i class="bi bi-calendar3 me-1"></i> <?= e(format_date_friendly($item['entry_date'])) ?>
                                        </span>
                                    </div>

                                    <!-- Dropdown for Edit/Delete -->
                                    <div class="dropdown">
                                        <button class="btn btn-light btn-sm p-1 rounded-circle border-0" type="button" data-bs-toggle="dropdown">
                                            <i class="bi bi-three-dots-vertical"></i>
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0">
                                            <li>
                                                <button type="button" class="dropdown-item py-2" data-bs-toggle="modal" data-bs-target="#editEntryModal<?= (int)$item['id'] ?>">
                                                    <i class="bi bi-pencil me-2 text-secondary"></i> Edit Entry
                                                </button>
                                            </li>
                                            <li>
                                                <form method="POST" action="journal.php" onsubmit="return confirm('Delete this journal entry permanently?');">
                                                    <?= csrf_field() ?>
                                                    <input type="hidden" name="action" value="delete_entry">
                                                    <input type="hidden" name="entry_id" value="<?= (int)$item['id'] ?>">
                                                    <button type="submit" class="dropdown-item py-2 text-danger">
                                                        <i class="bi bi-trash me-2"></i> Delete Entry
                                                    </button>
                                                </form>
                                            </li>
                                        </ul>
                                    </div>
                                </div>

                                <h5 class="fw-bold text-dark mb-2"><?= e($item['title']) ?></h5>
                                <div class="text-secondary mb-3" style="font-size: 0.95rem; line-height: 1.6; white-space: pre-line;">
                                    <?= e($item['content']) ?>
                                </div>

                                <?php if (!empty($item['gratitude'])): ?>
                                    <div class="journal-prompt-box">
                                        <div class="journal-prompt-label"><i class="bi bi-heart-fill text-danger me-1"></i> What I am grateful for</div>
                                        <div class="text-dark small"><?= e($item['gratitude']) ?></div>
                                    </div>
                                <?php endif; ?>

                                <?php if (!empty($item['lessons'])): ?>
                                    <div class="journal-prompt-box mt-2" style="border-left-color: var(--primary-color);">
                                        <div class="journal-prompt-label" style="color: var(--primary-color);"><i class="bi bi-lightbulb-fill text-warning me-1"></i> What I learned today</div>
                                        <div class="text-dark small"><?= e($item['lessons']) ?></div>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="mt-3 pt-2 border-top text-muted small d-flex justify-content-between">
                                <span>Recorded <?= e(format_date_short($item['created_at'])) ?></span>
                            </div>
                        </div>

                        <!-- Edit Entry Modal for this item -->
                        <div class="modal fade" id="editEntryModal<?= (int)$item['id'] ?>" tabindex="-1" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered modal-lg">
                                <div class="modal-content border-0 shadow">
                                    <form method="POST" action="journal.php">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="update_entry">
                                        <input type="hidden" name="entry_id" value="<?= (int)$item['id'] ?>">
                                        <div class="modal-header">
                                            <h5 class="modal-title fw-bold">Edit Journal Entry</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="row g-3 mb-3">
                                                <div class="col-sm-8">
                                                    <label class="form-label fw-semibold small">Title</label>
                                                    <input type="text" name="title" class="form-control" value="<?= e($item['title']) ?>" required>
                                                </div>
                                                <div class="col-sm-4">
                                                    <label class="form-label fw-semibold small">Date</label>
                                                    <input type="date" name="entry_date" class="form-control" value="<?= e($item['entry_date']) ?>" required>
                                                </div>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label fw-semibold small">How are you feeling? (Mood)</label>
                                                <select name="mood" class="form-select">
                                                    <option value="great" <?= $item['mood'] === 'great' ? 'selected' : '' ?>>😊 Great</option>
                                                    <option value="good" <?= $item['mood'] === 'good' ? 'selected' : '' ?>>🙂 Good</option>
                                                    <option value="okay" <?= $item['mood'] === 'okay' ? 'selected' : '' ?>>😐 Okay</option>
                                                    <option value="difficult" <?= $item['mood'] === 'difficult' ? 'selected' : '' ?>>😔 Difficult</option>
                                                    <option value="very_difficult" <?= $item['mood'] === 'very_difficult' ? 'selected' : '' ?>>😣 Very difficult</option>
                                                </select>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label fw-semibold small">Journal Thoughts & Reflections</label>
                                                <textarea name="content" class="form-control" rows="5" required><?= e($item['content']) ?></textarea>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label fw-semibold small">What am I grateful for today?</label>
                                                <textarea name="gratitude" class="form-control" rows="2"><?= e($item['gratitude'] ?? '') ?></textarea>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label fw-semibold small">What did I learn today?</label>
                                                <textarea name="lessons" class="form-control" rows="2"><?= e($item['lessons'] ?? '') ?></textarea>
                                            </div>
                                        </div>
                                        <div class="modal-footer bg-light">
                                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                                            <button type="submit" class="btn btn-primary">Save Changes</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

<!-- New Journal Entry Modal -->
<div class="modal fade" id="newEntryModal" tabindex="-1" aria-labelledby="newEntryModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 shadow">
            <form method="POST" action="journal.php">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="create_entry">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold" id="newEntryModalLabel">Write Journal Entry</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3 mb-3">
                        <div class="col-sm-8">
                            <label for="entryTitle" class="form-label fw-semibold small">Title</label>
                            <input type="text" id="entryTitle" name="title" class="form-control" placeholder="e.g. A peaceful morning of clarity" required autofocus>
                        </div>
                        <div class="col-sm-4">
                            <label for="entryDate" class="form-label fw-semibold small">Date</label>
                            <input type="date" id="entryDate" name="entry_date" class="form-control" value="<?= e($today) ?>" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="entryMood" class="form-label fw-semibold small">Current Mood</label>
                        <select id="entryMood" name="mood" class="form-select">
                            <option value="great">😊 Great</option>
                            <option value="good" selected>🙂 Good</option>
                            <option value="okay">😐 Okay</option>
                            <option value="difficult">😔 Difficult</option>
                            <option value="very_difficult">😣 Very difficult</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="entryContent" class="form-label fw-semibold small">Journal Content / Thoughts</label>
                        <textarea id="entryContent" name="content" class="form-control" rows="5" placeholder="Write openly about your day, prayers, thoughts, and reflections..." required></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="entryGratitude" class="form-label fw-semibold small">What am I grateful for?</label>
                        <textarea id="entryGratitude" name="gratitude" class="form-control" rows="2" placeholder="List 1 to 3 blessings or positive moments..."></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="entryLessons" class="form-label fw-semibold small">What did I learn today?</label>
                        <textarea id="entryLessons" name="lessons" class="form-control" rows="2" placeholder="A principle, insight, or realization..."></textarea>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Journal Entry</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if ((isset($_GET['action']) && $_GET['action'] === 'new') || $editing_entry): ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        <?php if ($editing_entry): ?>
            var editModalEl = document.getElementById('editEntryModal<?= (int)$editing_entry['id'] ?>');
            if (editModalEl) {
                var editModal = new bootstrap.Modal(editModalEl);
                editModal.show();
            }
        <?php else: ?>
            var modal = new bootstrap.Modal(document.getElementById('newEntryModal'));
            modal.show();
        <?php endif; ?>
    });
</script>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
