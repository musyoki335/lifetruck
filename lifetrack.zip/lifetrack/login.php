<?php
/**
 * LifeTrack - User Login
 */
require_once __DIR__ . '/includes/auth.php';

// Redirect if already logged in
require_guest();

$error = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        $error = 'Security session expired. Please try again.';
    } elseif (empty($email) || empty($password)) {
        $error = 'Please enter both your email and password.';
    } else {
        try {
            $pdo = get_db();
            $stmt = $pdo->prepare("SELECT id, full_name, email, password FROM users WHERE email = :email LIMIT 1");
            $stmt->execute(['email' => strtolower($email)]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                // Login successful
                login_user($user);
                set_flash('success', "Welcome back, {$user['full_name']}!");
                header('Location: dashboard.php');
                exit;
            } else {
                $error = 'Incorrect email or password.';
            }
        } catch (Exception $e) {
            error_log("Login error: " . $e->getMessage());
            $error = 'An error occurred during authentication. Please try again.';
        }
    }
}

$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In - LifeTrack</title>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            background: linear-gradient(135deg, #F4F6F2 0%, #E9EEE6 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem 1rem;
        }
        .auth-card {
            background: #FFFFFF;
            border-radius: var(--radius-lg);
            box-shadow: 0 15px 35px rgba(31, 77, 58, 0.08);
            border: 1px solid var(--border-color);
            width: 100%;
            max-width: 440px;
            padding: 2.5rem;
        }
    </style>
</head>
<body>

<div class="auth-card">
    <div class="text-center mb-4">
        <div class="brand-icon mx-auto mb-3" style="width: 48px; height: 48px; font-size: 1.5rem;">
            <i class="bi bi-compass"></i>
        </div>
        <h2 class="fw-bold mb-1" style="color: var(--primary-color);">Welcome Back</h2>
        <p class="text-muted small">Log in to track your habits and daily walk.</p>
    </div>

    <?php if ($flash): ?>
        <div class="alert alert-<?= e($flash['type']) ?> py-2 px-3 mb-4 rounded-3 small text-center">
            <?= e($flash['message']) ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($error)): ?>
        <div class="alert alert-danger py-2 px-3 mb-4 rounded-3 small text-center">
            <?= e($error) ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="login.php" novalidate>
        <?= csrf_field() ?>

        <div class="mb-3">
            <label for="email" class="form-label fw-semibold text-secondary-emphasis small">Email Address</label>
            <div class="input-group">
                <span class="input-group-text bg-light text-muted border-end-0"><i class="bi bi-envelope"></i></span>
                <input type="email" class="form-control border-start-0" id="email" name="email" value="<?= e($email) ?>" placeholder="name@example.com" required autofocus>
            </div>
        </div>

        <div class="mb-3">
            <div class="d-flex justify-content-between align-items-center mb-1">
                <label for="password" class="form-label fw-semibold text-secondary-emphasis small mb-0">Password</label>
                <a href="forgot-password.php" class="text-muted small text-decoration-none">Forgot password?</a>
            </div>
            <div class="input-group">
                <span class="input-group-text bg-light text-muted border-end-0"><i class="bi bi-lock"></i></span>
                <input type="password" class="form-control border-start-0" id="password" name="password" placeholder="Enter your password" required>
            </div>
        </div>

        <button type="submit" class="btn btn-primary w-100 py-2 mb-3 shadow-sm">
            Sign In to LifeTrack
        </button>

        <div class="text-center">
            <p class="small text-muted mb-0">Don't have an account? <a href="register.php" class="fw-bold">Sign Up</a></p>
        </div>
    </form>
</div>

</body>
</html>
