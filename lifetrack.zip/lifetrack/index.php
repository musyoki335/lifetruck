<?php
/**
 * LifeTrack - Landing & Gateway Page
 */
require_once __DIR__ . '/includes/auth.php';

// If already logged in, jump straight to the dashboard
if (is_logged_in()) {
    header('Location: dashboard.php');
    exit;
}

$pdo = get_db();
$today = date('Y-m-d');
$sample_verse = get_daily_verse($pdo, $today);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LifeTrack - Plan. Build. Reflect. Grow.</title>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .hero-section {
            padding: 5rem 0 3rem 0;
            background: radial-gradient(circle at top right, #E8EFEA 0%, #F7F8F5 60%);
        }
        .feature-icon-box {
            width: 52px;
            height: 52px;
            border-radius: 12px;
            background-color: var(--primary-light);
            color: var(--primary-color);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>

<!-- Navigation Header -->
<header class="bg-white border-bottom py-3">
    <div class="container d-flex justify-content-between align-items-center">
        <a href="index.php" class="d-flex align-items-center text-decoration-none">
            <div class="brand-icon">
                <i class="bi bi-compass"></i>
            </div>
            <div>
                <span class="brand-title">LifeTrack</span>
                <div class="brand-subtitle">Plan. Build. Reflect. Grow.</div>
            </div>
        </a>
        <div class="d-flex align-items-center gap-2">
            <a href="download.php" class="btn btn-light border px-3 py-2 d-none d-sm-inline-flex align-items-center gap-1">
                <i class="bi bi-download text-success"></i> Download ZIP
            </a>
            <a href="login.php" class="btn btn-outline-primary px-3 py-2">Sign In</a>
            <a href="register.php" class="btn btn-primary px-3 py-2">Get Started Free</a>
        </div>
    </div>
</header>

<!-- Hero Section -->
<section class="hero-section">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-6">
                <span class="badge px-3 py-2 rounded-pill mb-3" style="background-color: #E8EFEA; color: #1F4D3A; font-weight: 700;">
                    <i class="bi bi-stars text-warning me-1"></i> Purposeful Personal Growth System
                </span>
                <h1 class="display-4 fw-extrabold mb-3" style="color: var(--primary-color); letter-spacing: -1px; font-weight: 800;">
                    Plan your days.<br>
                    Build faithful habits.<br>
                    Reflect with gratitude.
                </h1>
                <p class="lead text-muted mb-4" style="font-size: 1.15rem;">
                    LifeTrack combines daily task planning, habit streak tracking, mindful journaling, and daily Bible-based encouragement to help you grow with intentionality.
                </p>
                <div class="d-flex flex-wrap gap-3">
                    <a href="register.php" class="btn btn-primary btn-lg px-4 py-3 shadow-sm">
                        Start Your Growth Journey <i class="bi bi-arrow-right ms-2"></i>
                    </a>
                    <a href="login.php" class="btn btn-light btn-lg px-4 py-3 border">
                        Sign In to Account
                    </a>
                </div>
            </div>

            <div class="col-lg-6">
                <!-- Today's Inspiration Preview Card -->
                <div class="verse-card shadow-lg mb-4">
                    <span class="verse-tag"><i class="bi bi-sun-fill me-1"></i> Today's Encouragement</span>
                    <div class="verse-quote">"<?= e($sample_verse['verse_text']) ?>"</div>
                    <div class="verse-ref">
                        <i class="bi bi-book-half"></i> <?= e($sample_verse['reference']) ?>
                    </div>
                </div>

                <!-- Preview mini cards -->
                <div class="row g-3">
                    <div class="col-sm-6">
                        <div class="card p-3 shadow-sm border-0 h-100">
                            <div class="d-flex align-items-center gap-3">
                                <div class="p-2 rounded-3 bg-success-subtle text-success fs-4">
                                    <i class="bi bi-check2-square"></i>
                                </div>
                                <div>
                                    <h6 class="fw-bold mb-0 text-dark">Daily Planner</h6>
                                    <small class="text-muted">Prioritized checklists</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="card p-3 shadow-sm border-0 h-100">
                            <div class="d-flex align-items-center gap-3">
                                <div class="p-2 rounded-3 bg-warning-subtle text-warning fs-4">
                                    <i class="bi bi-fire"></i>
                                </div>
                                <div>
                                    <h6 class="fw-bold mb-0 text-dark">Habit Streaks</h6>
                                    <small class="text-muted">Consistent momentum</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Features Grid -->
<section class="py-5 bg-white border-top border-bottom">
    <div class="container py-4">
        <div class="text-center max-w-700 mx-auto mb-5">
            <h2 class="fw-bold text-dark mb-2">Everything You Need To Grow</h2>
            <p class="text-muted">A calm, unified workspace free of clutter and distractions.</p>
        </div>

        <div class="row g-4">
            <div class="col-md-4">
                <div class="card h-100 p-4 border-0 shadow-sm">
                    <div class="feature-icon-box">
                        <i class="bi bi-calendar-check"></i>
                    </div>
                    <h5 class="fw-bold text-dark">Daily & Weekly Planning</h5>
                    <p class="text-muted small mb-0">Organize high-impact tasks by priority. Set weekly targets and keep your schedule aligned with your highest purpose.</p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card h-100 p-4 border-0 shadow-sm">
                    <div class="feature-icon-box" style="background-color: #FEF3C7; color: #D97706;">
                        <i class="bi bi-fire"></i>
                    </div>
                    <h5 class="fw-bold text-dark">Visual Habit Tracker</h5>
                    <p class="text-muted small mb-0">Track streaks, monitor your completion rates, and view 7-day calendars for prayer, reading, fitness, and discipline.</p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card h-100 p-4 border-0 shadow-sm">
                    <div class="feature-icon-box" style="background-color: #E0F2FE; color: #0284C7;">
                        <i class="bi bi-journal-richtext"></i>
                    </div>
                    <h5 class="fw-bold text-dark">Diary & Gratitude Journal</h5>
                    <p class="text-muted small mb-0">Record your thoughts, log your mood, write daily gratitude lists, and review lessons learned day by day.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Footer -->
<footer class="py-4 text-center bg-light text-muted small">
    <div class="container">
        <p class="mb-1 fw-medium">"Small progress every day becomes meaningful change."</p>
        <div>&copy; <?= date('Y') ?> LifeTrack &bull; Plan. Build. Reflect. Grow.</div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
