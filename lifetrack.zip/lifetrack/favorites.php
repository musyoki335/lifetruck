<?php
/**
 * LifeTrack - Saved & Favorite Bible Verses
 */
require_once __DIR__ . '/includes/auth.php';

require_login();

$user_id = current_user_id();
$pdo = get_db();

// Handle removal from favorites
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        set_flash('danger', 'Security session expired.');
        header('Location: favorites.php');
        exit;
    }

    if ($action === 'remove_favorite') {
        $verse_id = (int)($_POST['verse_id'] ?? 0);
        if ($verse_id > 0) {
            $del = $pdo->prepare("DELETE FROM favorite_verses WHERE user_id = :user_id AND verse_id = :verse_id");
            $del->execute(['user_id' => $user_id, 'verse_id' => $verse_id]);
            set_flash('info', 'Verse removed from your saved favorites.');
        }
        header('Location: favorites.php');
        exit;
    }
}

// Fetch favorite verses
$stmt = $pdo->prepare("
    SELECT bv.id, bv.verse_text, bv.reference, bv.theme, fv.created_at AS saved_at
    FROM favorite_verses fv
    JOIN bible_verses bv ON fv.verse_id = bv.id
    WHERE fv.user_id = :user_id
    ORDER BY fv.created_at DESC
");
$stmt->execute(['user_id' => $user_id]);
$favorites = $stmt->fetchAll();

$page_title = 'Favorite Bible Verses - LifeTrack';
$page_heading = "Saved Bible Verses";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<main class="app-main">
    <?php require_once __DIR__ . '/includes/navbar.php'; ?>

    <div class="app-content">
        <?php $flash = get_flash(); if ($flash): ?>
            <div class="alert alert-<?= e($flash['type']) ?> alert-dismissible fade show mb-4 rounded-3 border-0 shadow-sm" role="alert">
                <i class="bi bi-info-circle-fill me-2"></i> <?= e($flash['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h4 class="fw-bold text-dark mb-1">Your Inspirational Verses</h4>
                <p class="text-muted small mb-0">Scriptures you have saved during your daily walk and reflections.</p>
            </div>
            <span class="badge bg-light text-dark border px-3 py-2 fs-6">
                <?= count($favorites) ?> Saved
            </span>
        </div>

        <?php if (empty($favorites)): ?>
            <div class="card border-0 shadow-sm">
                <div class="card-body p-5">
                    <div class="empty-state">
                        <div class="empty-state-icon" style="background-color: #FEF3C7; color: #D97706;">
                            <i class="bi bi-star"></i>
                        </div>
                        <h5 class="empty-state-title">No saved verses yet</h5>
                        <p class="empty-state-text">
                            When a daily Bible verse resonates with you on your Dashboard, tap the star icon to save it here for encouragement.
                        </p>
                        <a href="dashboard.php" class="btn btn-primary">
                            <i class="bi bi-arrow-left me-1"></i> Return to Dashboard
                        </a>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="row g-4">
                <?php foreach ($favorites as $v): ?>
                    <div class="col-md-6">
                        <div class="card border-0 shadow-sm h-100 p-4 d-flex flex-column justify-content-between position-relative">
                            <div>
                                <div class="d-flex justify-content-between align-items-start mb-3">
                                    <span class="badge px-3 py-1 rounded-pill" style="background-color: var(--primary-light); color: var(--primary-color); font-weight: 700;">
                                        <?= strtoupper(e($v['theme'])) ?>
                                    </span>

                                    <!-- Remove button -->
                                    <form method="POST" action="favorites.php" onsubmit="return confirm('Remove this verse from your favorites?');" class="mb-0">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="remove_favorite">
                                        <input type="hidden" name="verse_id" value="<?= (int)$v['id'] ?>">
                                        <button type="submit" class="btn btn-light btn-sm text-danger p-1 rounded-circle border-0" title="Remove from favorites">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </div>

                                <blockquote class="blockquote mb-3">
                                    <p class="fs-6 fst-italic text-dark mb-2" style="line-height: 1.6;">
                                        "<?= e($v['verse_text']) ?>"
                                    </p>
                                    <footer class="blockquote-footer fw-bold" style="color: var(--secondary-color);">
                                        <?= e($v['reference']) ?>
                                    </footer>
                                </blockquote>
                            </div>

                            <div class="pt-3 border-top d-flex justify-content-between align-items-center text-muted small">
                                <span><i class="bi bi-clock me-1"></i> Saved <?= e(format_date_short($v['saved_at'])) ?></span>
                                <span class="text-warning"><i class="bi bi-star-fill"></i></span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
