<?php
/**
 * LifeTrack - Progress & Growth Analytics Dashboard
 */
require_once __DIR__ . '/includes/auth.php';

require_login();

$user_id = current_user_id();
$pdo = get_db();
$today = get_current_date();

// 1. Daily Metrics
$daily_stmt = $pdo->prepare("
    SELECT 
        COUNT(*) AS planned,
        SUM(CASE WHEN completed = 1 THEN 1 ELSE 0 END) AS completed
    FROM daily_plans 
    WHERE user_id = :user_id AND plan_date = :today
");
$daily_stmt->execute(['user_id' => $user_id, 'today' => $today]);
$daily_stats = $daily_stmt->fetch();
$daily_planned = (int)($daily_stats['planned'] ?? 0);
$daily_completed = (int)($daily_stats['completed'] ?? 0);
$daily_pct = $daily_planned > 0 ? (int)round(($daily_completed / $daily_planned) * 100) : 0;

// 2. Weekly Metrics (Current Week)
$week_start = get_week_start_date($today);
$week_end = date('Y-m-d', strtotime('+6 days', strtotime($week_start)));

$wg_stmt = $pdo->prepare("
    SELECT 
        COUNT(*) AS total_goals,
        SUM(CASE WHEN completed = 1 THEN 1 ELSE 0 END) AS completed_goals
    FROM weekly_plans 
    WHERE user_id = :user_id AND week_start = :week_start
");
$wg_stmt->execute(['user_id' => $user_id, 'week_start' => $week_start]);
$wg_stats = $wg_stmt->fetch();
$weekly_goals_total = (int)($wg_stats['total_goals'] ?? 0);
$weekly_goals_completed = (int)($wg_stats['completed_goals'] ?? 0);
$weekly_goals_pct = $weekly_goals_total > 0 ? (int)round(($weekly_goals_completed / $weekly_goals_total) * 100) : 0;

$wh_stmt = $pdo->prepare("
    SELECT COUNT(*) 
    FROM habit_logs 
    WHERE user_id = :user_id AND completed = 1 AND completion_date BETWEEN :start_date AND :end_date
");
$wh_stmt->execute(['user_id' => $user_id, 'start_date' => $week_start, 'end_date' => $week_end]);
$weekly_habits_completed = (int)$wh_stmt->fetchColumn();

$wj_stmt = $pdo->prepare("
    SELECT COUNT(*) 
    FROM journal_entries 
    WHERE user_id = :user_id AND entry_date BETWEEN :start_date AND :end_date
");
$wj_stmt->execute(['user_id' => $user_id, 'start_date' => $week_start, 'end_date' => $week_end]);
$weekly_journal_count = (int)$wj_stmt->fetchColumn();

// 3. Monthly Metrics (Current Month)
$month_start = date('Y-m-01', strtotime($today));
$month_end = date('Y-m-t', strtotime($today));

$mt_stmt = $pdo->prepare("
    SELECT 
        COUNT(*) AS total,
        SUM(CASE WHEN completed = 1 THEN 1 ELSE 0 END) AS completed
    FROM daily_plans 
    WHERE user_id = :user_id AND plan_date BETWEEN :start_date AND :end_date
");
$mt_stmt->execute(['user_id' => $user_id, 'start_date' => $month_start, 'end_date' => $month_end]);
$month_tasks = $mt_stmt->fetch();
$month_tasks_total = (int)($month_tasks['total'] ?? 0);
$month_tasks_completed = (int)($month_tasks['completed'] ?? 0);
$month_tasks_pct = $month_tasks_total > 0 ? (int)round(($month_tasks_completed / $month_tasks_total) * 100) : 0;

$mh_stmt = $pdo->prepare("
    SELECT COUNT(*) 
    FROM habit_logs 
    WHERE user_id = :user_id AND completed = 1 AND completion_date BETWEEN :start_date AND :end_date
");
$mh_stmt->execute(['user_id' => $user_id, 'start_date' => $month_start, 'end_date' => $month_end]);
$month_habits_count = (int)$mh_stmt->fetchColumn();

$mj_stmt = $pdo->prepare("
    SELECT COUNT(*) 
    FROM journal_entries 
    WHERE user_id = :user_id AND entry_date BETWEEN :start_date AND :end_date
");
$mj_stmt->execute(['user_id' => $user_id, 'start_date' => $month_start, 'end_date' => $month_end]);
$month_journal_count = (int)$mj_stmt->fetchColumn();

// 4. Best Habit Streak Across all habits
$habits_stmt = $pdo->prepare("SELECT id FROM habits WHERE user_id = :user_id");
$habits_stmt->execute(['user_id' => $user_id]);
$all_habit_ids = $habits_stmt->fetchAll(PDO::FETCH_COLUMN);

$best_habit_streak = 0;
foreach ($all_habit_ids as $hid) {
    $st = calculate_habit_streak($pdo, (int)$hid, $user_id);
    if ($st['longest_streak'] > $best_habit_streak) {
        $best_habit_streak = $st['longest_streak'];
    }
}

// 5. Chart 1: Last 7 Days Habit Completions
$last_7_days_labels = [];
$last_7_days_habit_counts = [];
for ($i = 6; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $last_7_days_labels[] = date('D (M j)', strtotime($d));
    
    $c_stmt = $pdo->prepare("SELECT COUNT(*) FROM habit_logs WHERE user_id = :user_id AND completed = 1 AND completion_date = :date");
    $c_stmt->execute(['user_id' => $user_id, 'date' => $d]);
    $last_7_days_habit_counts[] = (int)$c_stmt->fetchColumn();
}

// 6. Chart 2: Mood Distribution
$mood_stmt = $pdo->prepare("
    SELECT mood, COUNT(*) AS count 
    FROM journal_entries 
    WHERE user_id = :user_id 
    GROUP BY mood
");
$mood_stmt->execute(['user_id' => $user_id]);
$mood_counts = [
    'great' => 0,
    'good' => 0,
    'okay' => 0,
    'difficult' => 0,
    'very_difficult' => 0
];
while ($row = $mood_stmt->fetch()) {
    $k = strtolower($row['mood']);
    if (isset($mood_counts[$k])) {
        $mood_counts[$k] = (int)$row['count'];
    }
}

$page_title = 'Progress & Growth - LifeTrack';
$page_heading = "Progress & Growth Analytics";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<main class="app-main">
    <?php require_once __DIR__ . '/includes/navbar.php'; ?>

    <div class="app-content">
        <!-- 1. Daily Analytics Card Group -->
        <h5 class="fw-bold text-dark mb-3"><i class="bi bi-clock-history text-success me-2"></i> Today's Performance</h5>
        <div class="row g-3 mb-4">
            <div class="col-md-4">
                <div class="card border-0 shadow-sm p-3">
                    <div class="text-muted small fw-semibold">Tasks Completed Today</div>
                    <div class="d-flex align-items-baseline gap-2 mt-1">
                        <span class="h3 fw-bold text-dark mb-0"><?= $daily_completed ?></span>
                        <span class="text-muted small">/ <?= $daily_planned ?> planned</span>
                    </div>
                    <div class="progress mt-2" style="height: 6px;">
                        <div class="progress-bar bg-success" style="width: <?= $daily_pct ?>%;"></div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card border-0 shadow-sm p-3">
                    <div class="text-muted small fw-semibold">Daily Execution Rate</div>
                    <div class="d-flex align-items-baseline gap-2 mt-1">
                        <span class="h3 fw-bold text-primary mb-0"><?= $daily_pct ?>%</span>
                        <span class="text-muted small">completion</span>
                    </div>
                    <div class="progress mt-2" style="height: 6px;">
                        <div class="progress-bar bg-primary" style="width: <?= $daily_pct ?>%;"></div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card border-0 shadow-sm p-3">
                    <div class="text-muted small fw-semibold">Record Reflection</div>
                    <div class="d-flex align-items-center justify-content-between mt-1">
                        <span class="fw-bold text-dark">Today's Journal</span>
                        <a href="journal.php?action=new" class="btn btn-sm btn-outline-primary py-1 px-2">Write Entry</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- 2. Weekly & Monthly Overview -->
        <div class="row g-4 mb-4">
            <!-- Weekly -->
            <div class="col-lg-6">
                <div class="card border-0 shadow-sm h-100 p-4">
                    <h5 class="fw-bold text-dark mb-3"><i class="bi bi-calendar-week text-primary me-2"></i> Weekly Highlights</h5>
                    <div class="row g-3">
                        <div class="col-6">
                            <div class="p-3 bg-light rounded-3">
                                <div class="text-muted small">Weekly Goals Achieved</div>
                                <div class="h4 fw-bold text-dark mb-0"><?= $weekly_goals_completed ?> / <?= $weekly_goals_total ?></div>
                                <div class="small text-success mt-1"><?= $weekly_goals_pct ?>% accomplished</div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="p-3 bg-light rounded-3">
                                <div class="text-muted small">Habits Logged This Week</div>
                                <div class="h4 fw-bold text-dark mb-0"><?= $weekly_habits_completed ?></div>
                                <div class="small text-muted mt-1">Completions</div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="p-3 bg-light rounded-3 d-flex justify-content-between align-items-center">
                                <div>
                                    <div class="text-muted small">Weekly Diary Entries</div>
                                    <div class="h5 fw-bold text-dark mb-0"><?= $weekly_journal_count ?> Written</div>
                                </div>
                                <span class="badge bg-secondary-subtle text-secondary-emphasis">Week of <?= e(format_date_short($week_start)) ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Monthly -->
            <div class="col-lg-6">
                <div class="card border-0 shadow-sm h-100 p-4">
                    <h5 class="fw-bold text-dark mb-3"><i class="bi bi-calendar-month text-warning me-2"></i> Monthly Overview (<?= date('F') ?>)</h5>
                    <div class="row g-3">
                        <div class="col-6">
                            <div class="p-3 bg-light rounded-3">
                                <div class="text-muted small">Total Tasks Finished</div>
                                <div class="h4 fw-bold text-dark mb-0"><?= $month_tasks_completed ?></div>
                                <div class="small text-muted mt-1"><?= $month_tasks_pct ?>% of <?= $month_tasks_total ?> planned</div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="p-3 bg-light rounded-3">
                                <div class="text-muted small">Best Habit Streak</div>
                                <div class="h4 fw-bold text-warning mb-0">🔥 <?= $best_habit_streak ?> Days</div>
                                <div class="small text-muted mt-1">All-time record</div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="p-3 bg-light rounded-3 d-flex justify-content-between align-items-center">
                                <div>
                                    <div class="text-muted small">Monthly Journal Reflections</div>
                                    <div class="h5 fw-bold text-dark mb-0"><?= $month_journal_count ?> Entries Logged</div>
                                </div>
                                <span class="badge bg-success-subtle text-success">Consistent Growth</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 3. Charts Section -->
        <div class="row g-4">
            <!-- 7-Day Habit Activity Chart -->
            <div class="col-lg-8">
                <div class="card border-0 shadow-sm p-4 h-100">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="fw-bold text-dark mb-0">
                            <i class="bi bi-bar-chart-fill text-success me-2"></i> 7-Day Habit Activity
                        </h5>
                        <small class="text-muted">Total habits completed per day</small>
                    </div>
                    <div>
                        <canvas id="habitActivityChart" height="220"></canvas>
                    </div>
                </div>
            </div>

            <!-- Mood Distribution Chart -->
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm p-4 h-100">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="fw-bold text-dark mb-0">
                            <i class="bi bi-emoji-smile text-info me-2"></i> Mood Distribution
                        </h5>
                        <small class="text-muted">Journal feelings</small>
                    </div>
                    <div>
                        <canvas id="moodChart" height="220"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    // 1. Habit Activity Bar Chart
    const habitCtx = document.getElementById('habitActivityChart');
    if (habitCtx) {
        new Chart(habitCtx, {
            type: 'bar',
            data: {
                labels: <?= json_encode($last_7_days_labels) ?>,
                datasets: [{
                    label: 'Habits Completed',
                    data: <?= json_encode($last_7_days_habit_counts) ?>,
                    backgroundColor: '#1F4D3A',
                    borderRadius: 6,
                    borderSkipped: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: { stepSize: 1 }
                    }
                }
            }
        });
    }

    // 2. Mood Distribution Doughnut Chart
    const moodCtx = document.getElementById('moodChart');
    if (moodCtx) {
        new Chart(moodCtx, {
            type: 'doughnut',
            data: {
                labels: ['Great 😊', 'Good 🙂', 'Okay 😐', 'Difficult 😔', 'Very Difficult 😣'],
                datasets: [{
                    data: [
                        <?= $mood_counts['great'] ?>,
                        <?= $mood_counts['good'] ?>,
                        <?= $mood_counts['okay'] ?>,
                        <?= $mood_counts['difficult'] ?>,
                        <?= $mood_counts['very_difficult'] ?>
                    ],
                    backgroundColor: ['#10B981', '#3B82F6', '#F59E0B', '#EC4899', '#EF4444']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom' }
                }
            }
        });
    }
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
