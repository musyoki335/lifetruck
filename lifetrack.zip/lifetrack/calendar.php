<?php
/**
 * LifeTrack - Interactive Monthly Calendar
 */
require_once __DIR__ . '/includes/auth.php';

require_login();

$user_id = current_user_id();
$pdo = get_db();

// Month & Year selection
$month = isset($_GET['month']) ? (int)$_GET['month'] : (int)date('n');
$year = isset($_GET['year']) ? (int)$_GET['year'] : (int)date('Y');

// Normalize month/year bounds
if ($month < 1) {
    $month = 12;
    $year--;
} elseif ($month > 12) {
    $month = 1;
    $year++;
}

// Previous & Next navigation
$prev_month = $month - 1;
$prev_year = $year;
if ($prev_month < 1) {
    $prev_month = 12;
    $prev_year--;
}

$next_month = $month + 1;
$next_year = $year;
if ($next_month > 12) {
    $next_month = 1;
    $next_year++;
}

$first_day_of_month = sprintf('%04d-%02d-01', $year, $month);
$days_in_month = (int)date('t', strtotime($first_day_of_month));
$month_name = date('F Y', strtotime($first_day_of_month));
$first_day_weekday = (int)date('N', strtotime($first_day_of_month)); // 1 (Mon) to 7 (Sun)

$start_date_range = sprintf('%04d-%02d-01', $year, $month);
$end_date_range = sprintf('%04d-%02d-%02d', $year, $month, $days_in_month);

// 1. Fetch dates with completed daily plans
$tasks_stmt = $pdo->prepare("
    SELECT plan_date, COUNT(*) AS total, SUM(CASE WHEN completed = 1 THEN 1 ELSE 0 END) AS completed
    FROM daily_plans 
    WHERE user_id = :user_id AND plan_date BETWEEN :start_date AND :end_date
    GROUP BY plan_date
");
$tasks_stmt->execute(['user_id' => $user_id, 'start_date' => $start_date_range, 'end_date' => $end_date_range]);
$month_tasks = [];
while ($row = $tasks_stmt->fetch()) {
    $month_tasks[$row['plan_date']] = [
        'total' => (int)$row['total'],
        'completed' => (int)$row['completed']
    ];
}

// 2. Fetch dates with completed habits
$habits_stmt = $pdo->prepare("
    SELECT completion_date, COUNT(*) AS count
    FROM habit_logs 
    WHERE user_id = :user_id AND completed = 1 AND completion_date BETWEEN :start_date AND :end_date
    GROUP BY completion_date
");
$habits_stmt->execute(['user_id' => $user_id, 'start_date' => $start_date_range, 'end_date' => $end_date_range]);
$month_habits = [];
while ($row = $habits_stmt->fetch()) {
    $month_habits[$row['completion_date']] = (int)$row['count'];
}

// 3. Fetch dates with journal entries
$journal_stmt = $pdo->prepare("
    SELECT entry_date, id, title 
    FROM journal_entries 
    WHERE user_id = :user_id AND entry_date BETWEEN :start_date AND :end_date
");
$journal_stmt->execute(['user_id' => $user_id, 'start_date' => $start_date_range, 'end_date' => $end_date_range]);
$month_journals = [];
while ($row = $journal_stmt->fetch()) {
    $month_journals[$row['entry_date']] = $row;
}

$today = get_current_date();

$page_title = 'Growth Calendar - LifeTrack';
$page_heading = "Activity & Growth Calendar";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<main class="app-main">
    <?php require_once __DIR__ . '/includes/navbar.php'; ?>

    <div class="app-content">
        <!-- Calendar Header Navigation Bar -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-3">
                <div class="d-flex flex-column flex-sm-row justify-content-between align-items-sm-center gap-3">
                    <div class="d-flex align-items-center gap-2">
                        <a href="calendar.php?month=<?= $prev_month ?>&year=<?= $prev_year ?>" class="btn btn-light btn-sm" title="Previous Month">
                            <i class="bi bi-chevron-left"></i>
                        </a>
                        <h4 class="fw-bold mb-0 text-dark px-2"><?= e($month_name) ?></h4>
                        <a href="calendar.php?month=<?= $next_month ?>&year=<?= $next_year ?>" class="btn btn-light btn-sm" title="Next Month">
                            <i class="bi bi-chevron-right"></i>
                        </a>
                        <?php if ($month !== (int)date('n') || $year !== (int)date('Y')): ?>
                            <a href="calendar.php" class="btn btn-outline-secondary btn-sm ms-2">Today</a>
                        <?php endif; ?>
                    </div>

                    <!-- Legend -->
                    <div class="d-flex flex-wrap gap-2 align-items-center small">
                        <span class="badge cal-badge-plan border"><i class="bi bi-check2"></i> Plan Done</span>
                        <span class="badge cal-badge-habit border"><i class="bi bi-fire"></i> Habit Done</span>
                        <span class="badge cal-badge-journal border"><i class="bi bi-journal"></i> Journal</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Monthly Calendar Grid Card -->
        <div class="card border-0 shadow-sm">
            <div class="card-body p-2 p-md-3">
                <div class="table-responsive">
                    <table class="calendar-table">
                        <thead>
                            <tr>
                                <th>Mon</th>
                                <th>Tue</th>
                                <th>Wed</th>
                                <th>Thu</th>
                                <th>Fri</th>
                                <th>Sat</th>
                                <th>Sun</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <?php
                                // Pad leading days from previous month
                                for ($pad = 1; $pad < $first_day_weekday; $pad++) {
                                    echo '<td class="calendar-day-cell other-month"></td>';
                                }

                                $current_col = $first_day_weekday;

                                for ($day = 1; $day <= $days_in_month; $day++) {
                                    $date_str = sprintf('%04d-%02d-%02d', $year, $month, $day);
                                    $is_today = ($date_str === $today);

                                    $has_task = isset($month_tasks[$date_str]);
                                    $task_info = $month_tasks[$date_str] ?? null;
                                    $has_habit = isset($month_habits[$date_str]);
                                    $habit_count = $month_habits[$date_str] ?? 0;
                                    $has_journal = isset($month_journals[$date_str]);
                                    ?>
                                    <td class="calendar-day-cell <?= $is_today ? 'is-today' : '' ?>" data-date="<?= $date_str ?>" title="Click to view <?= $date_str ?> details">
                                        <div class="d-flex justify-content-between align-items-start">
                                            <span class="calendar-day-number <?= $is_today ? 'badge bg-primary' : '' ?>"><?= $day ?></span>
                                            <?php if ($is_today): ?>
                                                <span class="badge bg-warning text-dark p-1" style="font-size: 0.6rem;">TODAY</span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="calendar-indicators">
                                            <?php if ($has_task && $task_info['completed'] > 0): ?>
                                                <span class="cal-badge cal-badge-plan" title="<?= $task_info['completed'] ?> tasks done">
                                                    ✓ <?= $task_info['completed'] ?>
                                                </span>
                                            <?php endif; ?>

                                            <?php if ($has_habit && $habit_count > 0): ?>
                                                <span class="cal-badge cal-badge-habit" title="<?= $habit_count ?> habits completed">
                                                    🔥 <?= $habit_count ?>
                                                </span>
                                            <?php endif; ?>

                                            <?php if ($has_journal): ?>
                                                <span class="cal-badge cal-badge-journal" title="Journal entry logged">
                                                    📝 Entry
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <?php

                                    if ($current_col % 7 == 0 && $day < $days_in_month) {
                                        echo '</tr><tr>';
                                        $current_col = 0;
                                    }
                                    $current_col++;
                                }

                                // Pad trailing days to complete last row
                                while (($current_col - 1) % 7 != 0) {
                                    echo '<td class="calendar-day-cell other-month"></td>';
                                    $current_col++;
                                }
                                ?>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="text-center text-muted small mt-3">
            <i class="bi bi-info-circle me-1"></i> Tap on any day to open its comprehensive breakdown of tasks, habit logs, and reflections.
        </div>
    </div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
