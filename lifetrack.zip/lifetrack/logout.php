<?php
/**
 * LifeTrack - User Logout
 */
require_once __DIR__ . '/includes/auth.php';

logout_user();

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
set_flash('info', 'You have been logged out safely. See you soon!');
header('Location: login.php');
exit;
