-- =======================================================================
-- LifeTrack Database Schema & Seed Data
-- Web Application: LifeTrack - Personal Growth Diary & Habit Tracker
-- Character Set: utf8mb4, Engine: InnoDB
-- =======================================================================

CREATE DATABASE IF NOT EXISTS `lifetrack` 
    CHARACTER SET utf8mb4 
    COLLATE utf8mb4_unicode_ci;

USE `lifetrack`;

-- Disable foreign key checks for clean recreation
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `favorite_verses`;
DROP TABLE IF EXISTS `bible_verses`;
DROP TABLE IF EXISTS `journal_entries`;
DROP TABLE IF EXISTS `weekly_plans`;
DROP TABLE IF EXISTS `daily_plans`;
DROP TABLE IF EXISTS `habit_logs`;
DROP TABLE IF EXISTS `habits`;
DROP TABLE IF EXISTS `notifications`;
DROP TABLE IF EXISTS `users`;

SET FOREIGN_KEY_CHECKS = 1;

-- -----------------------------------------------------------------------
-- 1. Table: users
-- -----------------------------------------------------------------------
CREATE TABLE `users` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `full_name` VARCHAR(100) NOT NULL,
    `email` VARCHAR(150) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_users_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------
-- 2. Table: habits
-- -----------------------------------------------------------------------
CREATE TABLE `habits` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL,
    `name` VARCHAR(150) NOT NULL,
    `description` TEXT NULL,
    `frequency` ENUM('daily', 'weekdays', 'weekends', 'custom') DEFAULT 'daily',
    `color` VARCHAR(20) DEFAULT '#1F4D3A',
    `is_active` TINYINT(1) DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    INDEX `idx_habits_user_active` (`user_id`, `is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------
-- 3. Table: habit_logs
-- -----------------------------------------------------------------------
CREATE TABLE `habit_logs` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `habit_id` INT UNSIGNED NOT NULL,
    `user_id` INT UNSIGNED NOT NULL,
    `completion_date` DATE NOT NULL,
    `completed` TINYINT(1) DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`habit_id`) REFERENCES `habits`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    UNIQUE KEY `unique_habit_date` (`habit_id`, `completion_date`),
    INDEX `idx_habit_logs_user_date` (`user_id`, `completion_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------
-- 4. Table: daily_plans
-- -----------------------------------------------------------------------
CREATE TABLE `daily_plans` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL,
    `plan_date` DATE NOT NULL,
    `task` VARCHAR(255) NOT NULL,
    `priority` ENUM('low', 'medium', 'high') DEFAULT 'medium',
    `completed` TINYINT(1) DEFAULT 0,
    `notes` TEXT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    INDEX `idx_daily_plans_user_date` (`user_id`, `plan_date`),
    INDEX `idx_daily_plans_completed` (`user_id`, `completed`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------
-- 5. Table: weekly_plans
-- -----------------------------------------------------------------------
CREATE TABLE `weekly_plans` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL,
    `week_start` DATE NOT NULL,
    `goal` VARCHAR(255) NOT NULL,
    `description` TEXT NULL,
    `completed` TINYINT(1) DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    INDEX `idx_weekly_plans_user_week` (`user_id`, `week_start`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------
-- 6. Table: journal_entries
-- -----------------------------------------------------------------------
CREATE TABLE `journal_entries` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL,
    `entry_date` DATE NOT NULL,
    `title` VARCHAR(200) NOT NULL,
    `content` MEDIUMTEXT NOT NULL,
    `mood` VARCHAR(30) DEFAULT 'good',
    `gratitude` TEXT NULL,
    `lessons` TEXT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    INDEX `idx_journal_user_date` (`user_id`, `entry_date`),
    FULLTEXT INDEX `idx_journal_search` (`title`, `content`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------
-- 7. Table: bible_verses
-- -----------------------------------------------------------------------
CREATE TABLE `bible_verses` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `verse_text` TEXT NOT NULL,
    `reference` VARCHAR(100) NOT NULL,
    `theme` VARCHAR(50) DEFAULT 'Wisdom',
    `display_date` DATE NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_bible_display_date` (`display_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------
-- 8. Table: favorite_verses
-- -----------------------------------------------------------------------
CREATE TABLE `favorite_verses` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL,
    `verse_id` INT UNSIGNED NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`verse_id`) REFERENCES `bible_verses`(`id`) ON DELETE CASCADE,
    UNIQUE KEY `unique_user_verse` (`user_id`, `verse_id`),
    INDEX `idx_favorite_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------
-- 9. Table: notifications
-- -----------------------------------------------------------------------
CREATE TABLE `notifications` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL,
    `title` VARCHAR(150) NOT NULL,
    `message` TEXT NOT NULL,
    `is_read` TINYINT(1) DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    INDEX `idx_notifications_user_read` (`user_id`, `is_read`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =======================================================================
-- BIBLE VERSES SEED DATA (120+ Verses covering 4+ months starting Oct 2026)
-- Themes: Discipline, Wisdom, Hope, Courage, Patience, Faith, Work,
-- Purpose, Perseverance, Integrity, Peace, Strength, Planning, Growth.
-- =======================================================================

INSERT INTO `bible_verses` (`display_date`, `verse_text`, `reference`, `theme`) VALUES
('2026-10-01', 'Commit your deeds to the Lord, and your plans shall succeed.', 'Proverbs 16:3', 'Planning'),
('2026-10-02', 'For I know the thoughts that I think toward you, says the Lord, thoughts of peace, and not of evil, to give you hope and a future.', 'Jeremiah 29:11', 'Hope'),
('2026-10-03', 'Trust in the Lord with all your heart, and do not lean on your own understanding. In all your ways acknowledge him, and he will direct your paths.', 'Proverbs 3:5-6', 'Faith'),
('2026-10-04', 'I can do all things through Christ, who strengthens me.', 'Philippians 4:13', 'Strength'),
('2026-10-05', 'Whatever your hand finds to do, do it with your might; for there is no work, nor device, nor knowledge, nor wisdom, in Sheol, where you are going.', 'Ecclesiastes 9:10', 'Work'),
('2026-10-06', 'Be strong and courageous. Do not be afraid, neither be dismayed; for the Lord your God is with you wherever you go.', 'Joshua 1:9', 'Courage'),
('2026-10-07', 'The plans of the diligent lead surely to plenty, as surely as haste leads to poverty.', 'Proverbs 21:5', 'Discipline'),
('2026-10-08', 'Let us not become weary in doing good, for in due season we will reap, if we do not give up.', 'Galatians 6:9', 'Perseverance'),
('2026-10-09', 'If any of you lacks wisdom, let him ask of God, who gives to all liberally and without reproach; and it will be given to him.', 'James 1:5', 'Wisdom'),
('2026-10-10', 'Peace I leave with you. My peace I give to you; not as the world gives, give I to you. Do not let your heart be troubled, neither let it be afraid.', 'John 14:27', 'Peace'),
('2026-10-11', 'A man’s heart plans his course, but the Lord directs his steps.', 'Proverbs 16:9', 'Planning'),
('2026-10-12', 'Whatever you do, work at it with all your heart, as working for the Lord, not for human masters.', 'Colossians 3:23', 'Work'),
('2026-10-13', 'Those who wait on the Lord shall renew their strength. They shall mount up with wings like eagles. They shall run, and not be weary. They shall walk, and not faint.', 'Isaiah 40:31', 'Patience'),
('2026-10-14', 'He who walks with integrity walks securely, but he who perverts his ways will be found out.', 'Proverbs 10:9', 'Integrity'),
('2026-10-15', 'Do not conform to the pattern of this world, but be transformed by the renewing of your mind, that you may prove what is that good, well-pleasing, and perfect will of God.', 'Romans 12:2', 'Growth'),
('2026-10-16', 'Cast your burden on the Lord, and he will sustain you. He will never allow the righteous to be shaken.', 'Psalm 55:22', 'Peace'),
('2026-10-17', 'Where there is no counsel, plans fail; but in a multitude of counselors they are established.', 'Proverbs 15:22', 'Wisdom'),
('2026-10-18', 'For God didn’t give us a spirit of fear, but of power, love, and self-control.', '2 Timothy 1:7', 'Discipline'),
('2026-10-19', 'Your word is a lamp to my feet, and a light for my path.', 'Psalm 119:105', 'Guidance'),
('2026-10-20', 'Let your eyes look straight ahead, and fix your gaze directly before you. Give careful thought to the paths for your feet and be steadfast in all your ways.', 'Proverbs 4:25-26', 'Focus'),
('2026-10-21', 'Come to me, all you who labor and are heavily burdened, and I will give you rest.', 'Matthew 11:28', 'Peace'),
('2026-10-22', 'Every good gift and every perfect gift is from above, coming down from the Father of lights, with whom there is no variation, neither shadow that is cast by turning.', 'James 1:17', 'Gratitude'),
('2026-10-23', 'The hand of the diligent will rule, but laziness will be put to forced labor.', 'Proverbs 12:24', 'Discipline'),
('2026-10-24', 'For we walk by faith, not by sight.', '2 Corinthians 5:7', 'Faith'),
('2026-10-25', 'Do not be anxious about anything, but in everything by prayer and supplication with thanksgiving let your requests be made known to God.', 'Philippians 4:6', 'Peace'),
('2026-10-26', 'A soft answer turns away wrath, but a harsh word stirs up anger.', 'Proverbs 15:1', 'Wisdom'),
('2026-10-27', 'Be watchful, stand firm in the faith, be courageous, be strong. Let all that you do be done in love.', '1 Corinthians 16:13-14', 'Courage'),
('2026-10-28', 'The Lord is my shepherd; I shall not want. He makes me lie down in green pastures. He leads me beside still waters.', 'Psalm 23:1-2', 'Peace'),
('2026-10-29', 'Instruct the wise and they will be wiser still; teach the righteous and they will add to their learning.', 'Proverbs 9:9', 'Growth'),
('2026-10-30', 'Therefore do not worry about tomorrow, for tomorrow will worry about its own things. Sufficient for the day is its own trouble.', 'Matthew 6:34', 'Peace'),
('2026-10-31', 'In all labor there is profit, but idle talk leads only to poverty.', 'Proverbs 14:23', 'Work'),
('2026-11-01', 'For we are his workmanship, created in Christ Jesus for good works, which God prepared before that we would walk in them.', 'Ephesians 2:10', 'Purpose'),
('2026-11-02', 'Better is a little with the fear of the Lord, than great treasure with turmoil.', 'Proverbs 15:16', 'Integrity'),
('2026-11-03', 'Consider it pure joy, my brothers and sisters, whenever you face trials of many kinds, because you know that the testing of your faith produces perseverance.', 'James 1:2-3', 'Perseverance'),
('2026-11-04', 'The fruit of the Spirit is love, joy, peace, patience, kindness, goodness, faithfulness, gentleness, and self-control.', 'Galatians 5:22-23', 'Discipline'),
('2026-11-05', 'Apply your heart to instruction, and your ears to words of knowledge.', 'Proverbs 23:12', 'Growth'),
('2026-11-06', 'The Lord will fight for you; you need only to be still.', 'Exodus 14:14', 'Faith'),
('2026-11-07', 'A faithful man will abound with blessings, but he who hurries to be rich will not go unpunished.', 'Proverbs 28:20', 'Integrity'),
('2026-11-08', 'Rejoice always. Pray without ceasing. In everything give thanks, for this is the will of God in Christ Jesus toward you.', '1 Thessalonians 5:16-18', 'Gratitude'),
('2026-11-09', 'Iron sharpens iron; so a man sharpens the countenance of his friend.', 'Proverbs 27:17', 'Growth'),
('2026-11-10', 'Now faith is the assurance of things hoped for, the conviction of things not seen.', 'Hebrews 11:1', 'Faith'),
('2026-11-11', 'The soul of the sluggard desires, and has nothing; but the desire of the diligent shall be fully satisfied.', 'Proverbs 13:4', 'Discipline'),
('2026-11-12', 'Set your minds on things above, not on earthly things.', 'Colossians 3:2', 'Focus'),
('2026-11-13', 'He who gathers by labor will increase.', 'Proverbs 13:11', 'Work'),
('2026-11-14', 'My grace is sufficient for you, for my power is made perfect in weakness.', '2 Corinthians 12:9', 'Strength'),
('2026-11-15', 'Do not despise these small beginnings, for the Lord rejoices to see the work begin.', 'Zechariah 4:10', 'Hope'),
('2026-11-16', 'He who guards his mouth guards his soul. One who opens wide his lips comes to ruin.', 'Proverbs 13:3', 'Discipline'),
('2026-11-17', 'You will keep him in perfect peace, whose mind is stayed on you; because he trusts in you.', 'Isaiah 26:3', 'Peace'),
('2026-11-18', 'Commit your way to the Lord. Trust also in him, and he will do this: he will make your righteousness go forth as the light, and your justice as the noon day sun.', 'Psalm 37:5-6', 'Faith'),
('2026-11-19', 'A prudent man foresees the evil and hides himself, but the simple pass on, and suffer for it.', 'Proverbs 22:3', 'Wisdom'),
('2026-11-20', 'Let everything that has breath praise the Lord.', 'Psalm 150:6', 'Gratitude'),
('2026-11-21', 'As water reflects the face, so one’s life reflects the heart.', 'Proverbs 27:19', 'Integrity'),
('2026-11-22', 'And let the peace of God rule in your hearts, to which also you were called in one body; and be thankful.', 'Colossians 3:15', 'Peace'),
('2026-11-23', 'Ponder the path of your feet, and let all your ways be established.', 'Proverbs 4:26', 'Planning'),
('2026-11-24', 'Wait for the Lord; be strong, and let your heart take courage; yes, wait for the Lord.', 'Psalm 27:14', 'Patience'),
('2026-11-25', 'He who is faithful in a very little is faithful also in much.', 'Luke 16:10', 'Integrity'),
('2026-11-26', 'For the Lord gives wisdom. Out of his mouth comes knowledge and understanding.', 'Proverbs 2:6', 'Wisdom'),
('2026-11-27', 'Be completely humble and gentle; be patient, bearing with one another in love.', 'Ephesians 4:2', 'Patience'),
('2026-11-28', 'The name of the Lord is a strong tower. The righteous runs to him, and is safe.', 'Proverbs 18:10', 'Strength'),
('2026-11-29', 'May he grant you your heart’s desire, and fulfill all your counsel.', 'Psalm 20:4', 'Purpose'),
('2026-11-30', 'Do you see a man skilled in his work? He will stand before kings; he will not stand before obscure men.', 'Proverbs 22:29', 'Work'),
('2026-12-01', 'For everything there is a season, and a time for every purpose under heaven.', 'Ecclesiastes 3:1', 'Patience'),
('2026-12-02', 'A cheerful heart is good medicine, but a crushed spirit dries up the bones.', 'Proverbs 17:22', 'Joy'),
('2026-12-03', 'Blessed is the man who walks not in the counsel of the ungodly... but his delight is in the law of the Lord.', 'Psalm 1:1-2', 'Growth'),
('2026-12-04', 'Even youths grow tired and weary, and young men stumble and fall; but those who hope in the Lord will renew their strength.', 'Isaiah 40:30-31', 'Strength'),
('2026-12-05', 'Better is a patient person than a warrior, one with self-control than one who takes a city.', 'Proverbs 16:32', 'Discipline'),
('2026-12-06', 'Seek first God’s Kingdom, and his righteousness; and all these things will be given to you as well.', 'Matthew 6:33', 'Purpose'),
('2026-12-07', 'The integrity of the upright will guide them, but the perverseness of the treacherous will destroy them.', 'Proverbs 11:3', 'Integrity'),
('2026-12-08', 'Taste and see that the Lord is good. Blessed is the man who takes refuge in him.', 'Psalm 34:8', 'Gratitude'),
('2026-12-09', 'An intelligent heart acquires knowledge, and the ear of the wise seeks knowledge.', 'Proverbs 18:15', 'Wisdom'),
('2026-12-10', 'Be devoted to one another in love. Honor one another above yourselves. Never be lacking in zeal, but keep your spiritual fervor, serving the Lord.', 'Romans 12:10-11', 'Work'),
('2026-12-11', 'She considers a field and buys it; out of her earnings she plants a vineyard. She sets about her work vigorously; her arms are strong for her tasks.', 'Proverbs 31:16-17', 'Work'),
('2026-12-12', 'The Lord is my light and my salvation; whom shall I fear? The Lord is the strength of my life; of whom shall I be afraid?', 'Psalm 27:1', 'Courage'),
('2026-12-13', 'Hope deferred makes the heart sick, but when longing is fulfilled, it is a tree of life.', 'Proverbs 13:12', 'Hope'),
('2026-12-14', 'I will give thanks to you, Lord, with all my heart; I will tell of all your wonderful deeds.', 'Psalm 9:1', 'Gratitude'),
('2026-12-15', 'A gentle tongue is a tree of life, but deceit in it crushes the spirit.', 'Proverbs 15:4', 'Peace'),
('2026-12-16', 'Look carefully then how you walk, not as unwise but as wise, making the best use of the time, because the days are evil.', 'Ephesians 5:15-16', 'Discipline'),
('2026-12-17', 'The heart of man plans his way, but the Lord establishes his steps.', 'Proverbs 16:9', 'Planning'),
('2026-12-18', 'Create in me a clean heart, O God; and renew a right spirit within me.', 'Psalm 51:10', 'Growth'),
('2026-12-19', 'Pride goes before destruction, and a haughty spirit before a fall.', 'Proverbs 16:18', 'Wisdom'),
('2026-12-20', 'This is the day that the Lord has made. We will rejoice and be glad in it.', 'Psalm 118:24', 'Joy'),
('2026-12-21', 'The memory of the righteous is blessed, but the name of the wicked will rot.', 'Proverbs 10:7', 'Integrity'),
('2026-12-22', 'He gives power to the faint; and to him who has no might he increases strength.', 'Isaiah 40:29', 'Strength'),
('2026-12-23', 'A friend loves at all times; and a brother is born for adversity.', 'Proverbs 17:17', 'Love'),
('2026-12-24', 'For God so loved the world, that he gave his one and only Son, that whoever believes in him should not perish, but have eternal life.', 'John 3:16', 'Faith'),
('2026-12-25', 'Glory to God in the highest, and on earth peace, good will toward men.', 'Luke 2:14', 'Peace'),
('2026-12-26', 'Commit everything you do to the Lord. Trust him to help you do it, and he will.', 'Psalm 37:5', 'Faith'),
('2026-12-27', 'The wisdom from above is first pure, then peaceful, gentle, reasonable, full of mercy and good fruits, without partiality, and without hypocrisy.', 'James 3:17', 'Wisdom'),
('2026-12-28', 'He who walks with wise men will be wise, but the companion of fools will be destroyed.', 'Proverbs 13:20', 'Growth'),
('2026-12-29', 'Teach us to number our days, that we may gain a heart of wisdom.', 'Psalm 90:12', 'Planning'),
('2026-12-30', 'Watch, stand fast in the faith, be brave, be strong.', '1 Corinthians 16:13', 'Courage'),
('2026-12-31', 'Remember not the former things, neither consider the things of old. Behold, I will do a new thing; now it will spring forth.', 'Isaiah 43:18-19', 'Growth'),
('2027-01-01', 'In the beginning, God created the heavens and the earth. So let this new beginning bring fruit in every good work.', 'Genesis 1:1', 'Purpose'),
('2027-01-02', 'Trust in him at all times, you people; pour out your heart before him. God is a refuge for us.', 'Psalm 62:8', 'Faith'),
('2027-01-03', 'A wise man will hear, and will increase learning; and a man of understanding shall attain unto wise counsels.', 'Proverbs 1:5', 'Wisdom'),
('2027-01-04', 'Let your light shine before men, that they may see your good works, and glorify your Father who is in heaven.', 'Matthew 5:16', 'Integrity'),
('2027-01-05', 'The fear of the Lord is the beginning of wisdom; all who follow his precepts have good understanding.', 'Psalm 111:10', 'Wisdom'),
('2027-01-06', 'Do not grow weary in well doing, for you will reap a harvest at the proper time if you do not give up.', 'Galatians 6:9', 'Perseverance'),
('2027-01-07', 'Give thanks to the Lord, for he is good; his love endures forever.', 'Psalm 107:1', 'Gratitude'),
('2027-01-08', 'He who tends a fig tree will eat its fruit, and he who cares for his master will be honored.', 'Proverbs 27:18', 'Work'),
('2027-01-09', 'The tongue of the wise commends knowledge, but the mouths of fools pour out folly.', 'Proverbs 15:2', 'Wisdom'),
('2027-01-10', 'You shall love the Lord your God with all your heart, with all your soul, and with all your mind.', 'Matthew 22:37', 'Faith'),
('2027-01-11', 'Like a city whose walls are broken through is a person who lacks self-control.', 'Proverbs 25:28', 'Discipline'),
('2027-01-12', 'The Lord is close to the brokenhearted and saves those who are crushed in spirit.', 'Psalm 34:18', 'Hope'),
('2027-01-13', 'A cheerful look brings joy to the heart, and good news gives health to the bones.', 'Proverbs 15:30', 'Joy'),
('2027-01-14', 'Stand firm then, with the belt of truth buckled around your waist, with the breastplate of righteousness in place.', 'Ephesians 6:14', 'Integrity'),
('2027-01-15', 'Plans are established by seeking advice; so if you wage war, obtain guidance.', 'Proverbs 20:18', 'Planning'),
('2027-01-16', 'Finally, brothers and sisters, whatever is true, whatever is noble, whatever is right, whatever is pure, whatever is lovely, whatever is admirable—if anything is excellent or praiseworthy—think about such things.', 'Philippians 4:8', 'Focus'),
('2027-01-17', 'Diligent hands will rule, but laziness ends in slave labor.', 'Proverbs 12:24', 'Work'),
('2027-01-18', 'Peace I leave with you; my peace I give you. I do not give to you as the world gives.', 'John 14:27', 'Peace'),
('2027-01-19', 'A prudent man sees danger and takes refuge, but the simple keep going and pay the penalty.', 'Proverbs 27:12', 'Wisdom'),
('2027-01-20', 'He who pursues righteousness and love finds life, prosperity and honor.', 'Proverbs 21:21', 'Purpose'),
('2027-01-21', 'Because of the Lord’s great love we are not consumed, for his compassions never fail. They are new every morning; great is your faithfulness.', 'Lamentations 3:22-23', 'Hope'),
('2027-01-22', 'Wealth gained hastily will dwindle, but whoever gathers little by little will increase it.', 'Proverbs 13:11', 'Discipline'),
('2027-01-23', 'The Lord will guide you continually, giving you water when you are dry and restoring your strength.', 'Isaiah 58:11', 'Guidance'),
('2027-01-24', 'Gracious words are a honeycomb, sweet to the soul and healing to the bones.', 'Proverbs 16:24', 'Peace'),
('2027-01-25', 'Do not say, "I will pay you back for this wrong!" Wait for the Lord, and he will avenge you.', 'Proverbs 20:22', 'Patience'),
('2027-01-26', 'For we are God’s handiwork, created in Christ Jesus to do good works.', 'Ephesians 2:10', 'Purpose'),
('2027-01-27', 'Better a dry crust with peace and quiet than a house full of feasting, with strife.', 'Proverbs 17:1', 'Peace'),
('2027-01-28', 'Search me, God, and know my heart; test me and know my anxious thoughts. See if there is any offensive way in me, and lead me in the way everlasting.', 'Psalm 139:23-24', 'Growth'),
('2027-01-29', 'One who is slack in his work is brother to one who destroys.', 'Proverbs 18:9', 'Work'),
('2027-01-30', 'The Lord makes firm the steps of the one who delights in him.', 'Psalm 37:23', 'Guidance'),
('2027-01-31', 'To everything there is a season, A time for every purpose under heaven.', 'Ecclesiastes 3:1', 'Patience');
