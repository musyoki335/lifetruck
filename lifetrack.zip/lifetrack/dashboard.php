<?php
/**
 * LifeTrack - Main Dashboard
 * Plan. Build. Reflect. Grow.
 */
require_once __DIR__ . '/includes/auth.php';

require_login();

$auth_user = get_auth_user();
$user_id = (int)$auth_user['id'];
$pdo = get_db();

$today = get_current_date();
$greeting = get_time_greeting();
$first_name = explode(' ', trim($auth_user['full_name']))[0];
$today_formatted = format_date_friendly($today);

// 1. Get Daily Encouragement Verse
$verse = get_daily_verse($pdo, $today, $user_id);

// 2. Fetch Today's Daily Tasks
$task_stmt = $pdo->prepare("
    SELECT id, task, priority, completed, notes 
    FROM daily_plans 
    WHERE user_id = :user_id AND plan_date = :plan_date 
    ORDER BY completed ASC, 
             CASE priority WHEN 'high' THEN 1 WHEN 'medium' THEN 2 WHEN 'low' THEN 3 ELSE 4 END, 
             id ASC
");
$task_stmt->execute(['user_id' => $user_id, 'plan_date' => $today]);
$today_tasks = $task_stmt->fetchAll();

$total_tasks = count($today_tasks);
$completed_tasks = 0;
foreach ($today_tasks as $t) {
    if ($t['completed']) {
        $completed_tasks++;
    }
}
$task_progress_pct = $total_tasks > 0 ? (int)round(($completed_tasks / $total_tasks) * 100) : 0;

// 3. Fetch Active Habits with today's status & streak
$habit_stmt = $pdo->prepare("
    SELECT h.id, h.name, h.color, h.frequency,
           (SELECT 1 FROM habit_logs hl WHERE hl.habit_id = h.id AND hl.completion_date = :today AND hl.completed = 1 LIMIT 1) AS is_completed_today
    FROM habits h
    WHERE h.user_id = :user_id AND h.is_active = 1
    ORDER BY h.id ASC
");
$habit_stmt->execute(['user_id' => $user_id, 'today' => $today]);
$active_habits = $habit_stmt->fetchAll();

// Calculate streaks for each habit
$habits_with_data = [];
$habits_completed_today_count = 0;
foreach ($active_habits as $h) {
    $streak_data = calculate_habit_streak($pdo, (int)$h['id'], $user_id);
    $is_done = !empty($h['is_completed_today']);
    if ($is_done) {
        $habits_completed_today_count++;
    }
    $habits_with_data[] = array_merge($h, [
        'is_done' => $is_done,
        'current_streak' => $streak_data['current_streak'],
        'longest_streak' => $streak_data['longest_streak']
    ]);
}
$total_habits = count($habits_with_data);
$habit_progress_pct = $total_habits > 0 ? (int)round(($habits_completed_today_count / $total_habits) * 100) : 0;

// 4. Fetch Weekly Goals
$current_week_start = get_week_start_date($today);
$weekly_stmt = $pdo->prepare("
    SELECT id, goal, completed 
    FROM weekly_plans 
    WHERE user_id = :user_id AND week_start = :week_start 
    ORDER BY completed ASC, id ASC
");
$weekly_stmt->execute(['user_id' => $user_id, 'week_start' => $current_week_start]);
$weekly_goals = $weekly_stmt->fetchAll();

$total_weekly = count($weekly_goals);
$completed_weekly = 0;
foreach ($weekly_goals as $wg) {
    if ($wg['completed']) {
        $completed_weekly++;
    }
}
$weekly_progress_pct = $total_weekly > 0 ? (int)round(($completed_weekly / $total_weekly) * 100) : 0;

// 5. Fetch Today's Journal Entry
$journal_stmt = $pdo->prepare("
    SELECT id, title, mood, gratitude, lessons, content 
    FROM journal_entries 
    WHERE user_id = :user_id AND entry_date = :today 
    LIMIT 1
");
$journal_stmt->execute(['user_id' => $user_id, 'today' => $today]);
$today_journal = $journal_stmt->fetch();

$page_title = 'Dashboard - LifeTrack';
$page_heading = "Dashboard";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<main class="app-main">
    <?php require_once __DIR__ . '/includes/navbar.php'; ?>

    <div class="app-content">
        <!-- Flash Alert if exists -->
        <?php $flash = get_flash(); if ($flash): ?>
            <div class="alert alert-<?= e($flash['type']) ?> alert-dismissible fade show mb-4 rounded-3 border-0 shadow-sm" role="alert">
                <i class="bi bi-info-circle-fill me-2"></i> <?= e($flash['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Welcome Banner Header -->
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
            <div>
                <h1 class="h3 fw-bold mb-1" style="color: var(--primary-color);">
                    <?= e($greeting) ?>, <?= e($first_name) ?> 👋
                </h1>
                <p class="text-muted mb-0">
                    Here is your focus and momentum for <span class="fw-semibold text-dark"><?= e($today_formatted) ?></span>.
                </p>
            </div>
            
            <!-- Quick Actions -->
            <div class="d-flex flex-wrap gap-2">
                <a href="daily-plan.php?action=new" class="btn btn-outline-primary btn-sm d-flex align-items-center gap-1 shadow-sm">
                    <i class="bi bi-plus-circle"></i> Add Task
                </a>
                <a href="habits.php?action=new" class="btn btn-outline-primary btn-sm d-flex align-items-center gap-1 shadow-sm">
                    <i class="bi bi-fire"></i> Add Habit
                </a>
                <a href="journal.php?action=new" class="btn btn-secondary-gold btn-sm d-flex align-items-center gap-1 shadow-sm">
                    <i class="bi bi-pencil-square"></i> Write Journal
                </a>
            </div>
        </div>

        <!-- 1. Daily Bible Encouragement Card -->
        <div class="verse-card mb-4 shadow">
            <div class="d-flex justify-content-between align-items-start mb-2">
                <span class="verse-tag">
                    <i class="bi bi-sun-fill me-1"></i> DAILY ENCOURAGEMENT &bull; <?= strtoupper(e($verse['theme'])) ?>
                </span>
                <button type="button" 
                        id="favVerseBtn" 
                        class="btn-favorite-verse <?= $verse['is_favorite'] ? 'favorited' : '' ?>" 
                        data-verse-id="<?= (int)$verse['id'] ?>" 
                        title="<?= $verse['is_favorite'] ? 'Saved in favorites' : 'Save to favorites' ?>">
                    <i class="bi <?= $verse['is_favorite'] ? 'bi-star-fill text-warning' : 'bi-star' ?>"></i>
                </button>
            </div>
            <div class="verse-quote">"<?= e($verse['verse_text']) ?>"</div>
            <div class="verse-ref">
                <i class="bi bi-book-half"></i> <?= e($verse['reference']) ?>
            </div>
        </div>

        <!-- 2. Today's Progress Bar Card -->
        <div class="card border-0 shadow-sm p-4 mb-4">
            <div class="d-flex flex-column flex-sm-row justify-content-between align-items-sm-center gap-2 mb-2">
                <div>
                    <h5 class="fw-bold mb-0 text-dark">
                        <i class="bi bi-graph-up-arrow text-success me-2"></i> Today's Progress
                    </h5>
                    <small class="text-muted" id="dailyProgressCount">
                        <?= $completed_tasks ?> of <?= $total_tasks ?> tasks completed
                    </small>
                </div>
                <div class="display-6 fw-bold text-success" id="dailyProgressText" style="font-size: 1.85rem;">
                    <?= $task_progress_pct ?>%
                </div>
            </div>
            <div class="progress" style="height: 12px;">
                <div id="dailyProgressBar" 
                     class="progress-bar progress-bar-primary progress-bar-striped progress-bar-animated" 
                     role="progressbar" 
                     style="width: <?= $task_progress_pct ?>%; background-color: var(--primary-color);" 
                     aria-valuenow="<?= $task_progress_pct ?>" 
                     aria-valuemin="0" 
                     aria-valuemax="100"></div>
            </div>
        </div>

        <div class="row g-4">
            <!-- Left Column: Daily Tasks & Habits -->
            <div class="col-lg-7">
                <!-- TODAY'S PLAN CARD -->
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-white d-flex justify-content-between align-items-center py-3">
                        <div class="fw-bold text-dark fs-6 d-flex align-items-center gap-2">
                            <i class="bi bi-check2-square text-success"></i> TODAY'S PLAN
                        </div>
                        <a href="daily-plan.php" class="small text-decoration-none fw-semibold">View Planner <i class="bi bi-chevron-right"></i></a>
                    </div>
                    <div class="card-body p-3">
                        <?php if (empty($today_tasks)): ?>
                            <div class="empty-state py-4 text-center">
                                <div class="empty-state-icon" style="width: 50px; height: 50px; font-size: 1.3rem;">
                                    <i class="bi bi-clipboard-check"></i>
                                </div>
                                <h6 class="fw-bold text-dark mb-1">No tasks planned for today</h6>
                                <p class="text-muted small mb-3">Add your first task and conquer your day step by step.</p>
                                <a href="daily-plan.php?action=new" class="btn btn-primary btn-sm px-3">
                                    <i class="bi bi-plus-lg me-1"></i> Add Task
                                </a>
                            </div>
                        <?php else: ?>
                            <div class="task-list">
                                <?php foreach ($today_tasks as $t): ?>
                                    <div class="task-item <?= $t['completed'] ? 'is-completed' : '' ?>" id="task-item-<?= (int)$t['id'] ?>">
                                        <input class="form-check-input task-checkbox task-checkbox-ajax" 
                                               type="checkbox" 
                                               data-task-id="<?= (int)$t['id'] ?>" 
                                               id="task-<?= (int)$t['id'] ?>"
                                               <?= $t['completed'] ? 'checked' : '' ?>>
                                        <label class="form-check-label flex-grow-1 task-title mb-0 cursor-pointer" for="task-<?= (int)$t['id'] ?>">
                                            <?= e($t['task']) ?>
                                            <?php if (!empty($t['notes'])): ?>
                                                <div class="small text-muted fst-italic" style="font-size: 0.8rem;"><?= e($t['notes']) ?></div>
                                            <?php endif; ?>
                                        </label>
                                        <span class="badge priority-badge priority-<?= e($t['priority']) ?> ms-2">
                                            <?= e($t['priority']) ?>
                                        </span>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- HABITS CHECKLIST CARD -->
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-white d-flex justify-content-between align-items-center py-3">
                        <div class="fw-bold text-dark fs-6 d-flex align-items-center gap-2">
                            <i class="bi bi-fire text-warning"></i> TODAY'S HABITS
                        </div>
                        <a href="habits.php" class="small text-decoration-none fw-semibold">Manage Habits <i class="bi bi-chevron-right"></i></a>
                    </div>
                    <div class="card-body p-3">
                        <?php if (empty($habits_with_data)): ?>
                            <div class="empty-state py-4 text-center">
                                <div class="empty-state-icon" style="width: 50px; height: 50px; font-size: 1.3rem;">
                                    <i class="bi bi-fire"></i>
                                </div>
                                <h6 class="fw-bold text-dark mb-1">No habits yet</h6>
                                <p class="text-muted small mb-3">Create your first habit and start building momentum.</p>
                                <a href="habits.php?action=new" class="btn btn-primary btn-sm px-3">
                                    <i class="bi bi-plus-lg me-1"></i> Create Habit
                                </a>
                            </div>
                        <?php else: ?>
                            <div class="habit-list">
                                <?php foreach ($habits_with_data as $h): ?>
                                    <div class="d-flex align-items-center justify-content-between p-2 mb-2 rounded border bg-light-subtle">
                                        <div class="d-flex align-items-center gap-3">
                                            <button type="button" 
                                                    class="habit-check-btn habit-check-ajax <?= $h['is_done'] ? 'completed' : '' ?>" 
                                                    data-habit-id="<?= (int)$h['id'] ?>"
                                                    data-date="<?= e($today) ?>"
                                                    title="Mark completed today">
                                                <?= $h['is_done'] ? '<i class="bi bi-check-lg"></i>' : '' ?>
                                            </button>
                                            <div>
                                                <div class="fw-bold text-dark small"><?= e($h['name']) ?></div>
                                                <div class="text-muted" style="font-size: 0.75rem;"><?= e($h['frequency']) ?></div>
                                            </div>
                                        </div>
                                        <div>
                                            <span class="streak-badge" id="habit-streak-<?= (int)$h['id'] ?>">
                                                🔥 <?= (int)$h['current_streak'] ?> day streak
                                            </span>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Right Column: Weekly Goals & Journal Quick Card -->
            <div class="col-lg-5">
                <!-- WEEKLY GOALS CARD -->
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-white d-flex justify-content-between align-items-center py-3">
                        <div class="fw-bold text-dark fs-6 d-flex align-items-center gap-2">
                            <i class="bi bi-bullseye text-info"></i> WEEKLY GOALS
                        </div>
                        <a href="weekly-plan.php" class="small text-decoration-none fw-semibold">Weekly View <i class="bi bi-chevron-right"></i></a>
                    </div>
                    <div class="card-body p-3">
                        <div class="d-flex justify-content-between align-items-center mb-2 small">
                            <span class="text-muted">Weekly Completion:</span>
                            <span class="fw-bold text-dark" id="weeklyProgressText"><?= $weekly_progress_pct ?>%</span>
                        </div>
                        <div class="progress mb-3" style="height: 6px;">
                            <div id="weeklyProgressBar" class="progress-bar bg-info" style="width: <?= $weekly_progress_pct ?>%;"></div>
                        </div>

                        <?php if (empty($weekly_goals)): ?>
                            <div class="text-center py-3">
                                <p class="text-muted small mb-2 fst-italic">No goals set for this week.</p>
                                <a href="weekly-plan.php?action=new" class="btn btn-outline-primary btn-sm">Set Weekly Goals</a>
                            </div>
                        <?php else: ?>
                            <div class="weekly-goals-list">
                                <?php foreach ($weekly_goals as $wg): ?>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input weekly-goal-checkbox-ajax" 
                                               type="checkbox" 
                                               data-goal-id="<?= (int)$wg['id'] ?>" 
                                               id="goal-<?= (int)$wg['id'] ?>"
                                               <?= $wg['completed'] ? 'checked' : '' ?>>
                                        <label class="form-check-label small <?= $wg['completed'] ? 'text-decoration-line-through text-muted' : 'fw-medium text-dark' ?>" 
                                               id="goal-item-<?= (int)$wg['id'] ?>" 
                                               for="goal-<?= (int)$wg['id'] ?>">
                                            <?= e($wg['goal']) ?>
                                        </label>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- TODAY'S JOURNAL PREVIEW CARD -->
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-white d-flex justify-content-between align-items-center py-3">
                        <div class="fw-bold text-dark fs-6 d-flex align-items-center gap-2">
                            <i class="bi bi-journal-richtext text-primary"></i> DAILY JOURNAL
                        </div>
                        <a href="journal.php" class="small text-decoration-none fw-semibold">All Entries <i class="bi bi-chevron-right"></i></a>
                    </div>
                    <div class="card-body p-3">
                        <?php if ($today_journal): 
                            $mood = get_mood_details($today_journal['mood']);
                        ?>
                            <div class="d-flex align-items-center justify-content-between mb-2">
                                <span class="mood-badge">
                                    <span><?= $mood['emoji'] ?></span>
                                    <span><?= $mood['label'] ?></span>
                                </span>
                                <small class="text-muted">Today's Reflection</small>
                            </div>
                            <h6 class="fw-bold text-dark mb-1"><?= e($today_journal['title']) ?></h6>
                            <p class="text-muted small mb-3">
                                <?= e(mb_strimwidth($today_journal['content'], 0, 140, '...')) ?>
                            </p>
                            <?php if (!empty($today_journal['gratitude'])): ?>
                                <div class="journal-prompt-box mb-3">
                                    <div class="journal-prompt-label"><i class="bi bi-heart text-danger"></i> Grateful for:</div>
                                    <div class="small text-dark"><?= e(mb_strimwidth($today_journal['gratitude'], 0, 100, '...')) ?></div>
                                </div>
                            <?php endif; ?>
                            <a href="journal.php?edit=<?= (int)$today_journal['id'] ?>" class="btn btn-outline-primary btn-sm w-100">
                                <i class="bi bi-pencil me-1"></i> Edit Today's Entry
                            </a>
                        <?php else: ?>
                            <div class="text-center py-3">
                                <p class="text-muted small mb-3">You haven't written your reflections or gratitude for today yet.</p>
                                <a href="journal.php?action=new" class="btn btn-primary btn-sm w-100 shadow-sm">
                                    <i class="bi bi-pencil-square me-1"></i> Write Today's Journal
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
