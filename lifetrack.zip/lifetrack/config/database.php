<?php
/**
 * LifeTrack - Database Configuration & PDO Connection
 * Development Environment: XAMPP / Apache / MySQL
 */

// Timezone Configuration
if (!defined('APP_TIMEZONE')) {
    define('APP_TIMEZONE', 'Africa/Nairobi');
}
date_default_timezone_set(APP_TIMEZONE);

// Database Credentials (XAMPP Defaults)
define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', 'lifetrack');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

/**
 * Returns a singleton PDO database connection instance.
 *
 * @return PDO
 */
function get_db(): PDO {
    static $pdo = null;

    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
        ];

        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // Log error internally if logging is configured
            error_log("LifeTrack DB Connection Error: " . $e->getMessage());

            // Check if request is AJAX
            $is_ajax = (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest')
                || (isset($_SERVER['CONTENT_TYPE']) && str_contains($_SERVER['CONTENT_TYPE'], 'application/json'));

            if ($is_ajax) {
                header('Content-Type: application/json');
                http_response_code(500);
                echo json_encode([
                    'success' => false,
                    'message' => 'Unable to connect to the database right now. Please ensure MySQL is running in XAMPP and lifetrack database is imported.'
                ]);
                exit;
            }

            // Display friendly user error page without exposing credentials
            die('
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Database Connection Issue - LifeTrack</title>
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
                <style>
                    body { background-color: #F7F8F5; color: #1F2937; font-family: system-ui, -apple-system, sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; padding: 20px; }
                    .error-card { background: #FFFFFF; border-radius: 16px; box-shadow: 0 10px 25px rgba(0,0,0,0.05); padding: 40px; max-width: 520px; width: 100%; border-top: 4px solid #1F4D3A; }
                    .btn-brand { background-color: #1F4D3A; color: #ffffff; border-radius: 8px; font-weight: 600; padding: 10px 20px; text-decoration: none; display: inline-block; }
                    .btn-brand:hover { background-color: #163729; color: #ffffff; }
                    .code-hint { background: #F3F4F6; padding: 12px; border-radius: 8px; font-family: monospace; font-size: 0.9rem; margin-top: 15px; }
                </style>
            </head>
            <body>
                <div class="error-card text-center">
                    <h2 class="h4 fw-bold mb-3" style="color: #1F4D3A;">Unable to Connect to Database</h2>
                    <p class="text-muted">LifeTrack could not connect to MySQL. Please verify that your XAMPP MySQL service is running and the database has been imported.</p>
                    <div class="code-hint text-start">
                        1. Open XAMPP Control Panel<br>
                        2. Start Apache and MySQL<br>
                        3. Open phpMyAdmin (http://localhost/phpmyadmin)<br>
                        4. Create database: <strong>lifetrack</strong><br>
                        5. Import <strong>database/lifetrack.sql</strong>
                    </div>
                    <div class="mt-4">
                        <a href="javascript:location.reload()" class="btn btn-brand">Retry Connection</a>
                    </div>
                </div>
            </body>
            </html>
            ');
        }
    }

    return $pdo;
}
