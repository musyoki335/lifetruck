<?php
/**
 * LifeTrack - Reusable Footer Component
 */
?>
        </div> <!-- End .app-content -->

        <!-- Motivational Footer -->
        <footer class="app-footer">
            <div class="container-fluid text-center">
                <p class="mb-1 text-muted fw-medium fst-italic">"Small progress every day becomes meaningful change."</p>
                <div class="small text-secondary" style="font-size: 0.75rem;">
                    &copy; <?= date('Y') ?> <strong>LifeTrack</strong> &bull; Plan. Build. Reflect. Grow.
                </div>
            </div>
        </footer>
    </main> <!-- End .app-main -->
</div> <!-- End .app-container -->

<!-- Interactive Calendar Day Details Modal -->
<div class="modal fade" id="dayDetailsModal" tabindex="-1" aria-labelledby="dayDetailsModalDate" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 shadow">
            <div class="modal-header" style="background-color: var(--primary-color); color: #FFFFFF;">
                <h5 class="modal-title fw-bold" id="dayDetailsModalDate">Day Overview</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-4" id="dayDetailsModalBody">
                <div class="text-center py-4">
                    <div class="spinner-border text-success" role="status"></div>
                </div>
            </div>
            <div class="modal-footer bg-light border-0">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Toast Container for Notifications -->
<div class="lifetrack-toast-container"></div>

<!-- Bootstrap 5.3 Bundle JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Chart.js 4.4 -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<!-- Custom LifeTrack App JS -->
<script src="assets/js/app.js"></script>
</body>
</html>
