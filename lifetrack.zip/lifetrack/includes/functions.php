<?php
/**
 * LifeTrack - Core Functions & Helpers
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Escape output for XSS prevention
 */
function e(?string $value): string {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * Generate or get CSRF token
 */
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Output hidden CSRF field for forms
 */
function csrf_field(): string {
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

/**
 * Verify CSRF token
 */
function verify_csrf_token(?string $token): bool {
    if (empty($token) || empty($_SESSION['csrf_token'])) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Set a flash notification message
 */
function set_flash(string $type, string $message): void {
    $_SESSION['flash'] = [
        'type' => $type, // 'success', 'danger', 'warning', 'info'
        'message' => $message
    ];
}

/**
 * Get and clear flash message
 */
function get_flash(): ?array {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/**
 * Greeting based on current time
 * 5 AM - 11:59 AM: Good morning
 * 12 PM - 5:59 PM: Good afternoon
 * 6 PM - 4:59 AM: Good evening
 */
function get_time_greeting(): string {
    $hour = (int)date('G');
    if ($hour >= 5 && $hour < 12) {
        return 'Good morning';
    } elseif ($hour >= 12 && $hour < 18) {
        return 'Good afternoon';
    } else {
        return 'Good evening';
    }
}

/**
 * Format date to human-friendly format
 * Example: Saturday, October 3, 2026
 */
function format_date_friendly(?string $date_str): string {
    if (!$date_str) return '';
    $timestamp = strtotime($date_str);
    return date('l, F j, Y', $timestamp);
}

/**
 * Format date to short readable format
 * Example: Oct 3, 2026
 */
function format_date_short(?string $date_str): string {
    if (!$date_str) return '';
    $timestamp = strtotime($date_str);
    return date('M j, Y', $timestamp);
}

/**
 * Format date to input value format (YYYY-MM-DD)
 */
function get_current_date(): string {
    return date('Y-m-d');
}

/**
 * Get the Monday of the week for a given date
 */
function get_week_start_date(?string $date = null): string {
    $timestamp = $date ? strtotime($date) : time();
    $day_of_week = (int)date('N', $timestamp); // 1 (Mon) to 7 (Sun)
    $monday_timestamp = strtotime('-' . ($day_of_week - 1) . ' days', $timestamp);
    return date('Y-m-d', $monday_timestamp);
}

/**
 * Get array of 7 days starting from week_start (Mon-Sun)
 */
function get_week_days(string $week_start): array {
    $days = [];
    $start_ts = strtotime($week_start);
    for ($i = 0; $i < 7; $i++) {
        $curr_ts = strtotime("+$i days", $start_ts);
        $days[] = [
            'date' => date('Y-m-d', $curr_ts),
            'day_name' => date('l', $curr_ts),
            'day_short' => date('D', $curr_ts),
            'day_num' => date('j', $curr_ts),
            'month_short' => date('M', $curr_ts),
            'is_today' => date('Y-m-d', $curr_ts) === date('Y-m-d')
        ];
    }
    return $days;
}

/**
 * Retrieve the daily Bible verse for a specific date with deterministic fallback.
 * The same date always yields the same verse, regardless of refreshes.
 */
function get_daily_verse(PDO $pdo, string $date, ?int $user_id = null): array {
    // 1. Try to find a verse explicitly set for this date
    $stmt = $pdo->prepare("SELECT * FROM bible_verses WHERE display_date = :display_date LIMIT 1");
    $stmt->execute(['display_date' => $date]);
    $verse = $stmt->fetch();

    // 2. Deterministic fallback if no verse is assigned for that date
    if (!$verse) {
        $total_stmt = $pdo->query("SELECT COUNT(*) FROM bible_verses");
        $total_count = (int)$total_stmt->fetchColumn();

        if ($total_count > 0) {
            // Use deterministic integer hash of date string
            $date_hash = abs((int)crc32($date));
            $offset = $date_hash % $total_count;

            $fallback_stmt = $pdo->prepare("SELECT * FROM bible_verses ORDER BY id ASC LIMIT 1 OFFSET :offset");
            $fallback_stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
            $fallback_stmt->execute();
            $verse = $fallback_stmt->fetch();
        }
    }

    // Default static fallback if database is somehow empty
    if (!$verse) {
        $verse = [
            'id' => 0,
            'verse_text' => 'Commit your deeds to the Lord, and your plans shall succeed.',
            'reference' => 'Proverbs 16:3',
            'theme' => 'Planning',
            'display_date' => $date
        ];
    }

    // Check if favorited by current user
    $is_favorite = false;
    if ($user_id && $verse['id'] > 0) {
        $fav_stmt = $pdo->prepare("SELECT 1 FROM favorite_verses WHERE user_id = :user_id AND verse_id = :verse_id LIMIT 1");
        $fav_stmt->execute(['user_id' => $user_id, 'verse_id' => $verse['id']]);
        $is_favorite = (bool)$fav_stmt->fetchColumn();
    }

    $verse['is_favorite'] = $is_favorite;
    return $verse;
}

/**
 * Calculate habit streaks and metrics
 *
 * @param PDO $pdo
 * @param int $habit_id
 * @param int $user_id
 * @return array [
 *   'current_streak' => int,
 *   'longest_streak' => int,
 *   'completion_rate' => float,
 *   'total_completions' => int,
 *   'last_7_days' => array
 * ]
 */
function calculate_habit_streak(PDO $pdo, int $habit_id, int $user_id): array {
    // Get all completed dates in ascending order
    $stmt = $pdo->prepare("
        SELECT completion_date 
        FROM habit_logs 
        WHERE habit_id = :habit_id AND user_id = :user_id AND completed = 1
        ORDER BY completion_date ASC
    ");
    $stmt->execute(['habit_id' => $habit_id, 'user_id' => $user_id]);
    $dates = $stmt->fetchAll(PDO::FETCH_COLUMN);

    $total_completions = count($dates);
    $date_set = array_flip($dates);

    // Calculate Longest Streak
    $longest_streak = 0;
    $current_run = 0;
    $prev_date = null;

    foreach ($dates as $d) {
        if ($prev_date === null) {
            $current_run = 1;
        } else {
            $diff = (strtotime($d) - strtotime($prev_date)) / 86400;
            if ($diff == 1) {
                $current_run++;
            } else {
                $current_run = 1;
            }
        }
        if ($current_run > $longest_streak) {
            $longest_streak = $current_run;
        }
        $prev_date = $d;
    }

    // Calculate Current Streak
    $today = date('Y-m-d');
    $yesterday = date('Y-m-d', strtotime('-1 day'));

    $current_streak = 0;
    $check_date = null;

    if (isset($date_set[$today])) {
        // Today is completed, count backwards starting from today
        $check_date = $today;
    } elseif (isset($date_set[$yesterday])) {
        // Yesterday was completed, streak is still alive!
        $check_date = $yesterday;
    } else {
        // Neither today nor yesterday completed: streak reset to 0
        $current_streak = 0;
    }

    if ($check_date !== null) {
        while (isset($date_set[$check_date])) {
            $current_streak++;
            $check_date = date('Y-m-d', strtotime('-1 day', strtotime($check_date)));
        }
    }

    // Get habit creation date for completion rate
    $h_stmt = $pdo->prepare("SELECT created_at FROM habits WHERE id = :id AND user_id = :user_id");
    $h_stmt->execute(['id' => $habit_id, 'user_id' => $user_id]);
    $created_at = $h_stmt->fetchColumn();

    $days_since_created = 1;
    if ($created_at) {
        $days_since_created = max(1, (int)floor((time() - strtotime($created_at)) / 86400) + 1);
    }
    // Limit denominator to 30 days for recent completion rate or all-time
    $completion_rate = min(100, round(($total_completions / max(1, $days_since_created)) * 100));

    // Build last 7 days visual map (Ending today)
    $last_7_days = [];
    for ($i = 6; $i >= 0; $i--) {
        $d = date('Y-m-d', strtotime("-$i days"));
        $last_7_days[] = [
            'date' => $d,
            'day_name' => date('D', strtotime($d)),
            'day_num' => date('j', strtotime($d)),
            'completed' => isset($date_set[$d]),
            'is_today' => ($d === $today)
        ];
    }

    return [
        'current_streak' => $current_streak,
        'longest_streak' => max($longest_streak, $current_streak),
        'completion_rate' => $completion_rate,
        'total_completions' => $total_completions,
        'last_7_days' => $last_7_days
    ];
}

/**
 * Get mood emoji and label
 */
function get_mood_details(?string $mood): array {
    $moods = [
        'great' => ['emoji' => '😊', 'label' => 'Great', 'color' => '#10B981'],
        'good' => ['emoji' => '🙂', 'label' => 'Good', 'color' => '#3B82F6'],
        'okay' => ['emoji' => '😐', 'label' => 'Okay', 'color' => '#F59E0B'],
        'difficult' => ['emoji' => '😔', 'label' => 'Difficult', 'color' => '#EC4899'],
        'very_difficult' => ['emoji' => '😣', 'label' => 'Very difficult', 'color' => '#EF4444']
    ];

    $key = strtolower($mood ?? 'good');
    return $moods[$key] ?? $moods['good'];
}
