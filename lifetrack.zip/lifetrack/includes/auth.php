<?php
/**
 * LifeTrack - Authentication Guard & Session Management
 */

if (session_status() === PHP_SESSION_NONE) {
    // Harden session security
    ini_set('session.cookie_httponly', '1');
    ini_set('session.use_only_cookies', '1');
    session_start();
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';

/**
 * Check if a user is currently logged in
 */
function is_logged_in(): bool {
    return !empty($_SESSION['user_id']);
}

/**
 * Get current logged in user ID
 */
function current_user_id(): ?int {
    return $_SESSION['user_id'] ?? null;
}

/**
 * Get full user record for logged in user
 */
function get_auth_user(): ?array {
    if (!is_logged_in()) {
        return null;
    }

    static $cached_user = null;
    if ($cached_user !== null) {
        return $cached_user;
    }

    $pdo = get_db();
    $stmt = $pdo->prepare("SELECT id, full_name, email, created_at, updated_at FROM users WHERE id = :id LIMIT 1");
    $stmt->execute(['id' => $_SESSION['user_id']]);
    $cached_user = $stmt->fetch() ?: null;

    if (!$cached_user) {
        // User record was deleted or invalid; clear session
        logout_user();
    }

    return $cached_user;
}

/**
 * Require user to be logged in to view page
 */
function require_login(): void {
    if (!is_logged_in()) {
        set_flash('warning', 'Please log in to access this page.');
        header('Location: login.php');
        exit;
    }
}

/**
 * Require guest (unauthenticated) state; e.g. for login or register pages
 */
function require_guest(): void {
    if (is_logged_in()) {
        header('Location: dashboard.php');
        exit;
    }
}

/**
 * Log in a user securely and regenerate session id
 */
function login_user(array $user): void {
    session_regenerate_id(true);
    $_SESSION['user_id'] = (int)$user['id'];
    $_SESSION['user_name'] = $user['full_name'];
    $_SESSION['user_email'] = $user['email'];
}

/**
 * Cleanly log out the user
 */
function logout_user(): void {
    $_SESSION = [];
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params["path"],
            $params["domain"],
            $params["secure"],
            $params["httponly"]
        );
    }
    session_destroy();
}
