<?php
/**
 * LifeTrack - Reusable Navbar Component
 */
$auth_user = get_auth_user();
$today_formatted = format_date_friendly(get_current_date());
?>
<header class="app-navbar">
    <div class="d-flex align-items-center gap-3">
        <!-- Mobile Sidebar Toggle -->
        <button id="sidebarToggleBtn" class="btn btn-light d-lg-none p-2 border-0" type="button" aria-label="Toggle navigation">
            <i class="bi bi-list fs-4"></i>
        </button>

        <div>
            <div class="header-date-badge d-none d-sm-flex">
                <i class="bi bi-calendar4-event text-success"></i>
                <span><?= e($today_formatted) ?></span>
            </div>
            <h2 class="page-title d-none d-md-block fs-5 mb-0 text-dark"><?= e($page_heading ?? 'Dashboard') ?></h2>
        </div>
    </div>

    <div class="d-flex align-items-center gap-2">
        <!-- Quick Action Dropdown -->
        <div class="dropdown">
            <button class="btn btn-secondary-gold btn-sm dropdown-toggle d-flex align-items-center gap-1 shadow-sm" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="bi bi-plus-lg"></i>
                <span class="d-none d-sm-inline">Quick Add</span>
            </button>
            <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0 py-2" style="border-radius: 12px;">
                <li><h6 class="dropdown-header text-uppercase text-muted fw-bold" style="font-size: 0.7rem;">Quick Actions</h6></li>
                <li><a class="dropdown-item py-2" href="daily-plan.php?action=new"><i class="bi bi-check2-square text-success me-2"></i> Add Daily Task</a></li>
                <li><a class="dropdown-item py-2" href="habits.php?action=new"><i class="bi bi-fire text-warning me-2"></i> Create Habit</a></li>
                <li><a class="dropdown-item py-2" href="journal.php?action=new"><i class="bi bi-journal-plus text-primary me-2"></i> Write Journal Entry</a></li>
                <li><a class="dropdown-item py-2" href="weekly-plan.php?action=new"><i class="bi bi-bullseye text-info me-2"></i> Add Weekly Goal</a></li>
            </ul>
        </div>

        <!-- User Dropdown Menu -->
        <?php if ($auth_user): ?>
        <div class="dropdown">
            <button class="btn btn-light p-1 rounded-circle border dropdown-toggle d-flex align-items-center justify-content-center" type="button" data-bs-toggle="dropdown" aria-expanded="false" style="width: 40px; height: 40px;">
                <span class="fw-bold text-dark small"><?= strtoupper(substr(e($auth_user['full_name']), 0, 1)) ?></span>
            </button>
            <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0 py-2" style="border-radius: 12px; min-width: 200px;">
                <li class="px-3 py-2 border-bottom">
                    <div class="fw-bold text-dark text-truncate"><?= e($auth_user['full_name']) ?></div>
                    <div class="text-muted small text-truncate"><?= e($auth_user['email']) ?></div>
                </li>
                <li><a class="dropdown-item py-2" href="profile.php"><i class="bi bi-person me-2"></i> My Profile</a></li>
                <li><a class="dropdown-item py-2" href="favorites.php"><i class="bi bi-star me-2"></i> Saved Verses</a></li>
                    <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item py-2 text-danger" href="logout.php"><i class="bi bi-box-arrow-right me-2"></i> Log Out</a></li>
            </ul>
        </div>
        <?php endif; ?>
    </div>
</header>
