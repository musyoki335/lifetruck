<?php
/**
 * LifeTrack - Reusable Sidebar Component
 */
$auth_user = get_auth_user();
$active_page = basename($_SERVER['PHP_SELF'], '.php');
?>
<!-- Mobile Backdrop -->
<div id="sidebarBackdrop" class="modal-backdrop fade show d-none" style="z-index: 995;"></div>

<!-- Sidebar Navigation -->
<aside class="app-sidebar shadow-sm">
    <!-- Brand / Logo -->
    <div class="sidebar-brand">
        <a href="dashboard.php" class="d-flex align-items-center text-decoration-none">
            <div class="brand-icon">
                <i class="bi bi-compass"></i>
            </div>
            <div>
                <h1 class="brand-title">LifeTrack</h1>
                <p class="brand-subtitle">Plan. Build. Reflect. Grow.</p>
            </div>
        </a>
    </div>

    <!-- Navigation Menu Items -->
    <div class="sidebar-menu">
        <div class="nav-section-title">Navigation</div>
        
        <a href="dashboard.php" class="nav-link-custom <?= $active_page === 'dashboard' ? 'active' : '' ?>">
            <i class="bi bi-grid-1x2"></i>
            <span>Dashboard</span>
        </a>

        <a href="daily-plan.php" class="nav-link-custom <?= $active_page === 'daily-plan' ? 'active' : '' ?>">
            <i class="bi bi-check2-square"></i>
            <span>Daily Plan</span>
        </a>

        <a href="weekly-plan.php" class="nav-link-custom <?= $active_page === 'weekly-plan' ? 'active' : '' ?>">
            <i class="bi bi-calendar-week"></i>
            <span>Weekly Plan</span>
        </a>

        <a href="habits.php" class="nav-link-custom <?= $active_page === 'habits' ? 'active' : '' ?>">
            <i class="bi bi-fire"></i>
            <span>Habits</span>
        </a>

        <a href="journal.php" class="nav-link-custom <?= $active_page === 'journal' ? 'active' : '' ?>">
            <i class="bi bi-journal-text"></i>
            <span>Journal</span>
        </a>

        <a href="calendar.php" class="nav-link-custom <?= $active_page === 'calendar' ? 'active' : '' ?>">
            <i class="bi bi-calendar3"></i>
            <span>Calendar</span>
        </a>

        <a href="progress.php" class="nav-link-custom <?= $active_page === 'progress' ? 'active' : '' ?>">
            <i class="bi bi-graph-up-arrow"></i>
            <span>Progress</span>
        </a>

        <div class="nav-section-title mt-3">Inspiration & Account</div>

        <a href="favorites.php" class="nav-link-custom <?= $active_page === 'favorites' ? 'active' : '' ?>">
            <i class="bi bi-star"></i>
            <span>Favorite Verses</span>
        </a>

        <a href="profile.php" class="nav-link-custom <?= $active_page === 'profile' ? 'active' : '' ?>">
            <i class="bi bi-person-circle"></i>
            <span>Profile</span>
        </a>

        <a href="logout.php" class="nav-link-custom text-danger mt-2">
            <i class="bi bi-box-arrow-right text-danger"></i>
            <span>Logout</span>
        </a>
    </div>

    <!-- Logged In User Pill -->
    <?php if ($auth_user): ?>
    <div class="sidebar-user">
        <div class="avatar-initial">
            <?= strtoupper(substr(e($auth_user['full_name']), 0, 1)) ?>
        </div>
        <div class="overflow-hidden">
            <div class="fw-bold text-truncate text-dark small"><?= e($auth_user['full_name']) ?></div>
            <div class="text-muted text-truncate" style="font-size: 0.75rem;"><?= e($auth_user['email']) ?></div>
        </div>
    </div>
    <?php endif; ?>
</aside>
