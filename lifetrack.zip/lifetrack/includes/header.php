<?php
/**
 * LifeTrack - Reusable Header Component
 */
if (!defined('APP_INIT')) {
    define('APP_INIT', true);
}
require_once __DIR__ . '/auth.php';

$current_page = basename($_SERVER['PHP_SELF'], '.php');
$page_title_text = $page_title ?? 'LifeTrack - Plan. Build. Reflect. Grow.';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
    <meta name="csrf-token" content="<?= e(csrf_token()) ?>">
    <title><?= e($page_title_text) ?></title>
    <link rel="icon" type="image/svg+xml" href="assets/images/logo.svg">

    <!-- Google Fonts: Plus Jakarta Sans -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">

    <!-- LifeTrack Custom Design System -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="app-container">
