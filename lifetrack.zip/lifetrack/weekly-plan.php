<?php
/**
 * LifeTrack - Weekly Planner & Goal Setter
 */
require_once __DIR__ . '/includes/auth.php';

require_login();

$user_id = current_user_id();
$pdo = get_db();

// Determine week start date (Monday)
$week_start = $_GET['week'] ?? get_week_start_date();
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $week_start)) {
    $week_start = get_week_start_date();
} else {
    $week_start = get_week_start_date($week_start);
}

// Calculate week end date (Sunday)
$week_end = date('Y-m-d', strtotime('+6 days', strtotime($week_start)));
$prev_week = date('Y-m-d', strtotime('-7 days', strtotime($week_start)));
$next_week = date('Y-m-d', strtotime('+7 days', strtotime($week_start)));

// Handle Form Submissions: Create, Edit, Delete Weekly Goals
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        set_flash('danger', 'Invalid security token.');
        header("Location: weekly-plan.php?week=" . urlencode($week_start));
        exit;
    }

    if ($action === 'create_goal') {
        $goal = trim($_POST['goal'] ?? '');
        $description = trim($_POST['description'] ?? '');

        if (empty($goal)) {
            set_flash('danger', 'Please enter a goal title.');
        } else {
            $stmt = $pdo->prepare("INSERT INTO weekly_plans (user_id, week_start, goal, description) VALUES (:user_id, :week_start, :goal, :description)");
            $stmt->execute([
                'user_id' => $user_id,
                'week_start' => $week_start,
                'goal' => $goal,
                'description' => $description ?: null
            ]);
            set_flash('success', 'Weekly goal created successfully.');
        }
        header("Location: weekly-plan.php?week=" . urlencode($week_start));
        exit;
    }

    if ($action === 'update_goal') {
        $goal_id = (int)($_POST['goal_id'] ?? 0);
        $goal = trim($_POST['goal'] ?? '');
        $description = trim($_POST['description'] ?? '');

        if ($goal_id <= 0 || empty($goal)) {
            set_flash('danger', 'Invalid goal details.');
        } else {
            $stmt = $pdo->prepare("UPDATE weekly_plans SET goal = :goal, description = :description WHERE id = :id AND user_id = :user_id");
            $stmt->execute([
                'goal' => $goal,
                'description' => $description ?: null,
                'id' => $goal_id,
                'user_id' => $user_id
            ]);
            set_flash('success', 'Weekly goal updated.');
        }
        header("Location: weekly-plan.php?week=" . urlencode($week_start));
        exit;
    }

    if ($action === 'delete_goal') {
        $goal_id = (int)($_POST['goal_id'] ?? 0);
        if ($goal_id > 0) {
            $stmt = $pdo->prepare("DELETE FROM weekly_plans WHERE id = :id AND user_id = :user_id");
            $stmt->execute(['id' => $goal_id, 'user_id' => $user_id]);
            set_flash('success', 'Weekly goal removed.');
        }
        header("Location: weekly-plan.php?week=" . urlencode($week_start));
        exit;
    }
}

// Fetch Weekly Goals for this week
$goal_stmt = $pdo->prepare("
    SELECT * FROM weekly_plans 
    WHERE user_id = :user_id AND week_start = :week_start 
    ORDER BY completed ASC, id ASC
");
$goal_stmt->execute(['user_id' => $user_id, 'week_start' => $week_start]);
$goals = $goal_stmt->fetchAll();

$total_goals = count($goals);
$completed_goals = 0;
foreach ($goals as $g) {
    if ($g['completed']) $completed_goals++;
}
$completion_pct = $total_goals > 0 ? (int)round(($completed_goals / $total_goals) * 100) : 0;

// Fetch 7 Days (Mon - Sun) daily tasks overview
$week_days = get_week_days($week_start);
$day_tasks = [];
foreach ($week_days as $d) {
    $t_stmt = $pdo->prepare("
        SELECT id, task, completed, priority 
        FROM daily_plans 
        WHERE user_id = :user_id AND plan_date = :plan_date
        ORDER BY completed ASC, id ASC
    ");
    $t_stmt->execute(['user_id' => $user_id, 'plan_date' => $d['date']]);
    $day_tasks[$d['date']] = $t_stmt->fetchAll();
}

$page_title = 'Weekly Planner - LifeTrack';
$page_heading = "Weekly Planner";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<main class="app-main">
    <?php require_once __DIR__ . '/includes/navbar.php'; ?>

    <div class="app-content">
        <?php $flash = get_flash(); if ($flash): ?>
            <div class="alert alert-<?= e($flash['type']) ?> alert-dismissible fade show mb-4 rounded-3 border-0 shadow-sm" role="alert">
                <i class="bi bi-info-circle-fill me-2"></i> <?= e($flash['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Week Navigator Bar -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-3">
                <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
                    <div class="d-flex align-items-center gap-2">
                        <a href="weekly-plan.php?week=<?= $prev_week ?>" class="btn btn-light btn-sm" title="Previous Week">
                            <i class="bi bi-chevron-left"></i>
                        </a>
                        <span class="fw-bold fs-6 text-dark px-2">
                            Week of <?= e(format_date_short($week_start)) ?> – <?= e(format_date_short($week_end)) ?>
                        </span>
                        <a href="weekly-plan.php?week=<?= $next_week ?>" class="btn btn-light btn-sm" title="Next Week">
                            <i class="bi bi-chevron-right"></i>
                        </a>
                        <?php if ($week_start !== get_week_start_date()): ?>
                            <a href="weekly-plan.php" class="btn btn-outline-secondary btn-sm ms-2">Current Week</a>
                        <?php endif; ?>
                    </div>

                    <div class="d-flex align-items-center gap-3">
                        <div class="text-md-end">
                            <div class="small text-muted">Weekly Goals Progress</div>
                            <span class="fw-bold fs-5 text-dark" id="weeklyProgressText"><?= $completion_pct ?>%</span>
                        </div>
                        <button type="button" class="btn btn-primary btn-sm d-flex align-items-center gap-1 shadow-sm" data-bs-toggle="modal" data-bs-target="#addGoalModal">
                            <i class="bi bi-plus-lg"></i> Add Weekly Goal
                        </button>
                    </div>
                </div>

                <div class="progress mt-3" style="height: 10px;">
                    <div id="weeklyProgressBar" class="progress-bar bg-info" style="width: <?= $completion_pct ?>%;"></div>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <!-- Left: Weekly Goals Checklist -->
            <div class="col-lg-5">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-white d-flex justify-content-between align-items-center py-3">
                        <div class="fw-bold text-dark fs-6 d-flex align-items-center gap-2">
                            <i class="bi bi-bullseye text-info"></i> WEEKLY MILESTONES & GOALS
                        </div>
                        <span class="badge bg-light text-dark border"><?= $completed_goals ?> / <?= $total_goals ?></span>
                    </div>
                    <div class="card-body p-3">
                        <?php if (empty($goals)): ?>
                            <div class="empty-state py-4 text-center">
                                <div class="empty-state-icon" style="width: 52px; height: 52px; font-size: 1.4rem;">
                                    <i class="bi bi-flag"></i>
                                </div>
                                <h6 class="fw-bold text-dark mb-1">No weekly goals set</h6>
                                <p class="text-muted small mb-3">Define 3 to 5 key targets to anchor your week in purposeful focus.</p>
                                <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addGoalModal">
                                    <i class="bi bi-plus-lg me-1"></i> Add Weekly Goal
                                </button>
                            </div>
                        <?php else: ?>
                            <div class="weekly-goals-checklist">
                                <?php foreach ($goals as $g): ?>
                                    <div class="p-3 mb-2 rounded border bg-light-subtle d-flex align-items-start justify-content-between">
                                        <div class="d-flex align-items-start gap-3 flex-grow-1 me-2">
                                            <input class="form-check-input mt-1 weekly-goal-checkbox-ajax" 
                                                   type="checkbox" 
                                                   data-goal-id="<?= (int)$g['id'] ?>" 
                                                   id="wgoal-<?= (int)$g['id'] ?>"
                                                   <?= $g['completed'] ? 'checked' : '' ?>>
                                            <div>
                                                <label class="form-check-label fw-semibold text-dark mb-0 cursor-pointer <?= $g['completed'] ? 'text-decoration-line-through text-muted' : '' ?>" 
                                                       id="goal-item-<?= (int)$g['id'] ?>" 
                                                       for="wgoal-<?= (int)$g['id'] ?>">
                                                    <?= e($g['goal']) ?>
                                                </label>
                                                <?php if (!empty($g['description'])): ?>
                                                    <div class="small text-muted mt-1"><?= e($g['description']) ?></div>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="d-flex align-items-center gap-1">
                                            <button type="button" class="btn btn-light btn-sm text-secondary p-1" data-bs-toggle="modal" data-bs-target="#editGoalModal<?= (int)$g['id'] ?>">
                                                <i class="bi bi-pencil"></i>
                                            </button>
                                            <form method="POST" action="weekly-plan.php?week=<?= urlencode($week_start) ?>" onsubmit="return confirm('Delete this weekly goal?');" class="d-inline mb-0">
                                                <?= csrf_field() ?>
                                                <input type="hidden" name="action" value="delete_goal">
                                                <input type="hidden" name="goal_id" value="<?= (int)$g['id'] ?>">
                                                <button type="submit" class="btn btn-light btn-sm text-danger p-1">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </div>

                                    <!-- Edit Goal Modal -->
                                    <div class="modal fade" id="editGoalModal<?= (int)$g['id'] ?>" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content border-0 shadow">
                                                <form method="POST" action="weekly-plan.php?week=<?= urlencode($week_start) ?>">
                                                    <?= csrf_field() ?>
                                                    <input type="hidden" name="action" value="update_goal">
                                                    <input type="hidden" name="goal_id" value="<?= (int)$g['id'] ?>">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title fw-bold">Edit Weekly Goal</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="mb-3">
                                                            <label class="form-label fw-semibold small">Goal Title</label>
                                                            <input type="text" name="goal" class="form-control" value="<?= e($g['goal']) ?>" required>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label fw-semibold small">Description / Milestones</label>
                                                            <textarea name="description" class="form-control" rows="3"><?= e($g['description'] ?? '') ?></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer bg-light">
                                                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                                                        <button type="submit" class="btn btn-primary">Update Goal</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Right: 7-Day Day-by-Day Task Overview (Mon - Sun) -->
            <div class="col-lg-7">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-white py-3">
                        <div class="fw-bold text-dark fs-6 d-flex align-items-center gap-2">
                            <i class="bi bi-calendar-week text-primary"></i> 7-DAY SCHEDULE (MONDAY – SUNDAY)
                        </div>
                    </div>
                    <div class="card-body p-3">
                        <div class="row g-2">
                            <?php foreach ($week_days as $day): 
                                $tasks_for_day = $day_tasks[$day['date']] ?? [];
                            ?>
                                <div class="col-12">
                                    <div class="p-3 rounded border <?= $day['is_today'] ? 'border-primary bg-light' : 'bg-white' ?>">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <div class="d-flex align-items-center gap-2">
                                                <span class="badge <?= $day['is_today'] ? 'bg-primary' : 'bg-secondary' ?>" style="font-size: 0.75rem;">
                                                    <?= e($day['day_short']) ?> &bull; <?= e($day['month_short']) ?> <?= e($day['day_num']) ?>
                                                </span>
                                                <span class="fw-bold text-dark small"><?= e($day['day_name']) ?></span>
                                                <?php if ($day['is_today']): ?>
                                                    <span class="badge bg-warning text-dark" style="font-size: 0.65rem;">TODAY</span>
                                                <?php endif; ?>
                                            </div>
                                            <a href="daily-plan.php?date=<?= e($day['date']) ?>" class="btn btn-link btn-sm text-decoration-none p-0 small fw-semibold">
                                                Go to Day <i class="bi bi-arrow-right"></i>
                                            </a>
                                        </div>

                                        <?php if (empty($tasks_for_day)): ?>
                                            <p class="text-muted small mb-0 fst-italic">No tasks scheduled.</p>
                                        <?php else: ?>
                                            <div class="d-flex flex-column gap-1">
                                                <?php foreach ($tasks_for_day as $dt): ?>
                                                    <div class="d-flex align-items-center gap-2 small">
                                                        <i class="bi <?= $dt['completed'] ? 'bi-check-circle-fill text-success' : 'bi-circle text-muted' ?>"></i>
                                                        <span class="<?= $dt['completed'] ? 'text-decoration-line-through text-muted' : 'text-dark fw-medium' ?>">
                                                            <?= e($dt['task']) ?>
                                                        </span>
                                                        <span class="badge priority-badge priority-<?= e($dt['priority']) ?> ms-auto" style="font-size: 0.65rem;">
                                                            <?= e($dt['priority']) ?>
                                                        </span>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<!-- Add Goal Modal -->
<div class="modal fade" id="addGoalModal" tabindex="-1" aria-labelledby="addGoalModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <form method="POST" action="weekly-plan.php?week=<?= urlencode($week_start) ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="create_goal">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold" id="addGoalModalLabel">Set New Weekly Goal</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="newGoalTitle" class="form-label fw-semibold small">Goal Objective</label>
                        <input type="text" id="newGoalTitle" name="goal" class="form-control" placeholder="e.g. Exercise at least 4 times" required autofocus>
                    </div>
                    <div class="mb-3">
                        <label for="newGoalDesc" class="form-label fw-semibold small">Description / Target Details</label>
                        <textarea id="newGoalDesc" name="description" class="form-control" rows="3" placeholder="Define success criteria or specific days..."></textarea>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Add Goal</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if (isset($_GET['action']) && $_GET['action'] === 'new'): ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var modal = new bootstrap.Modal(document.getElementById('addGoalModal'));
        modal.show();
    });
</script>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
