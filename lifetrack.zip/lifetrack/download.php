<?php
/**
 * LifeTrack - Project Packager & One-Click ZIP Downloader
 * Bundles the entire LifeTrack application into a single compact downloadable ZIP archive.
 */

// Enable error reporting for packaging diagnostics
error_reporting(E_ALL);
ini_set('display_errors', '1');

$source_dir = __DIR__;
$zip_filename = 'lifetrack.zip';
$zip_filepath = $source_dir . DIRECTORY_SEPARATOR . $zip_filename;

// Also allow creating in parent scratch directory if accessible
$parent_zip_filepath = dirname($source_dir) . DIRECTORY_SEPARATOR . $zip_filename;

function build_zip_archive($source, $destination) {
    if (!extension_loaded('zip')) {
        return false;
    }

    $zip = new ZipArchive();
    if ($zip->open($destination, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        return false;
    }

    $source = realpath($source);
    $files = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($source, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::LEAVES_ONLY
    );

    foreach ($files as $file) {
        // Skip preexisting zip files to avoid recursion
        if (str_ends_with(strtolower($file->getFilename()), '.zip')) {
            continue;
        }

        $file_path = $file->getRealPath();
        // Calculate relative path inside ZIP archive with root directory name 'lifetrack/'
        $relative_path = 'lifetrack/' . str_replace('\\', '/', substr($file_path, strlen($source) + 1));

        $zip->addFile($file_path, $relative_path);
    }

    return $zip->close();
}

// Attempt to create the ZIP archive
$created = build_zip_archive($source_dir, $zip_filepath);

// Also mirror to parent folder if possible
if ($created && is_writable(dirname($source_dir))) {
    @copy($zip_filepath, $parent_zip_filepath);
}

// Check if running from CLI
$is_cli = (php_sapi_name() === 'cli' || empty($_SERVER['REMOTE_ADDR']));

if ($is_cli) {
    if ($created) {
        echo "SUCCESS: Created compact downloadable archive at: \n" . $zip_filepath . "\n";
        exit(0);
    } else {
        echo "ERROR: Failed to create ZIP archive. Ensure PHP zip extension is enabled.\n";
        exit(1);
    }
}

// Running from Web Browser: Trigger immediate file download
if ($created && file_exists($zip_filepath)) {
    header('Content-Description: File Transfer');
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . basename($zip_filepath) . '"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($zip_filepath));
    readfile($zip_filepath);
    exit;
} else {
    http_response_code(500);
    echo '<!DOCTYPE html><html><head><title>Download Error</title></head><body>';
    echo '<h3>Unable to generate ZIP archive automatically.</h3>';
    echo '<p>Please ensure PHP zip extension is enabled in php.ini, or copy the <code>lifetrack/</code> folder directly.</p>';
    echo '</body></html>';
    exit;
}
