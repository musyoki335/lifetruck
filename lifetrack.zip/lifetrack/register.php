<?php
/**
 * LifeTrack - User Registration
 */
require_once __DIR__ . '/includes/auth.php';

// Redirect if already logged in
require_guest();

$errors = [];
$full_name = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $csrf = $_POST['csrf_token'] ?? '';

    // Validate CSRF
    if (!verify_csrf_token($csrf)) {
        $errors[] = 'Security token invalid. Please reload the form.';
    }

    // Validation
    if (empty($full_name)) {
        $errors[] = 'Please enter your full name.';
    } elseif (mb_strlen($full_name) < 2 || mb_strlen($full_name) > 100) {
        $errors[] = 'Full name must be between 2 and 100 characters.';
    }

    if (empty($email)) {
        $errors[] = 'Please enter your email address.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }

    if (empty($password)) {
        $errors[] = 'Please choose a password.';
    } elseif (strlen($password) < 6) {
        $errors[] = 'Password must be at least 6 characters long.';
    }

    if ($password !== $confirm_password) {
        $errors[] = 'Passwords do not match.';
    }

    // Check duplicate email if no prior errors
    if (empty($errors)) {
        try {
            $pdo = get_db();
            $check_stmt = $pdo->prepare("SELECT id FROM users WHERE email = :email LIMIT 1");
            $check_stmt->execute(['email' => strtolower($email)]);
            if ($check_stmt->fetch()) {
                $errors[] = 'An account with this email address already exists. Please log in.';
            } else {
                // Insert user
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $ins_stmt = $pdo->prepare("INSERT INTO users (full_name, email, password) VALUES (:name, :email, :pass)");
                $ins_stmt->execute([
                    'name' => $full_name,
                    'email' => strtolower($email),
                    'pass' => $hash
                ]);

                $user_id = (int)$pdo->lastInsertId();

                // Create initial starter habits for a wonderful onboarding experience
                $starter_habits = [
                    ['Morning Prayer & Reflection', 'Start the day in gratitude and quiet contemplation', 'daily', '#1F4D3A'],
                    ['Read Bible & Journal', 'Read the verse of the day and write reflections', 'daily', '#D4AF37'],
                    ['Physical Exercise', 'At least 30 minutes of intentional movement', 'daily', '#2563EB'],
                    ['Drink 2L Water', 'Hydrate properly throughout the day', 'daily', '#0D9488']
                ];
                $h_stmt = $pdo->prepare("INSERT INTO habits (user_id, name, description, frequency, color) VALUES (:user_id, :name, :desc, :freq, :color)");
                foreach ($starter_habits as $sh) {
                    $h_stmt->execute([
                        'user_id' => $user_id,
                        'name' => $sh[0],
                        'desc' => $sh[1],
                        'freq' => $sh[2],
                        'color' => $sh[3]
                    ]);
                }

                // Create starter daily plan
                $today = date('Y-m-d');
                $plan_stmt = $pdo->prepare("INSERT INTO daily_plans (user_id, plan_date, task, priority) VALUES (:user_id, :date, :task, :priority)");
                $starter_tasks = [
                    ['Review daily Bible encouragement', 'high'],
                    ['Organize workspace & plan weekly milestones', 'medium'],
                    ['Log first journal entry of gratitude', 'low']
                ];
                foreach ($starter_tasks as $st) {
                    $plan_stmt->execute([
                        'user_id' => $user_id,
                        'date' => $today,
                        'task' => $st[0],
                        'priority' => $st[1]
                    ]);
                }

                // Log in user
                login_user([
                    'id' => $user_id,
                    'full_name' => $full_name,
                    'email' => strtolower($email)
                ]);

                set_flash('success', "Welcome to LifeTrack, {$full_name}! Your dashboard is ready.");
                header('Location: dashboard.php');
                exit;
            }
        } catch (Exception $e) {
            error_log("Registration error: " . $e->getMessage());
            $errors[] = 'A registration error occurred. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Your Account - LifeTrack</title>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            background: linear-gradient(135deg, #F4F6F2 0%, #E9EEE6 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem 1rem;
        }
        .auth-card {
            background: #FFFFFF;
            border-radius: var(--radius-lg);
            box-shadow: 0 15px 35px rgba(31, 77, 58, 0.08);
            border: 1px solid var(--border-color);
            width: 100%;
            max-width: 480px;
            padding: 2.5rem;
        }
    </style>
</head>
<body>

<div class="auth-card">
    <div class="text-center mb-4">
        <div class="brand-icon mx-auto mb-3" style="width: 48px; height: 48px; font-size: 1.5rem;">
            <i class="bi bi-compass"></i>
        </div>
        <h2 class="fw-bold mb-1" style="color: var(--primary-color);">Join LifeTrack</h2>
        <p class="text-muted small">Plan your days. Build strong habits. Grow with purpose.</p>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger py-2 px-3 mb-4 rounded-3 small">
            <ul class="mb-0 ps-3">
                <?php foreach ($errors as $error): ?>
                    <li><?= e($error) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="register.php" novalidate>
        <?= csrf_field() ?>

        <div class="mb-3">
            <label for="full_name" class="form-label fw-semibold text-secondary-emphasis small">Full Name</label>
            <div class="input-group">
                <span class="input-group-text bg-light text-muted border-end-0"><i class="bi bi-person"></i></span>
                <input type="text" class="form-control border-start-0" id="full_name" name="full_name" value="<?= e($full_name) ?>" placeholder="e.g. David Kim" required autofocus>
            </div>
        </div>

        <div class="mb-3">
            <label for="email" class="form-label fw-semibold text-secondary-emphasis small">Email Address</label>
            <div class="input-group">
                <span class="input-group-text bg-light text-muted border-end-0"><i class="bi bi-envelope"></i></span>
                <input type="email" class="form-control border-start-0" id="email" name="email" value="<?= e($email) ?>" placeholder="you@example.com" required>
            </div>
        </div>

        <div class="mb-3">
            <label for="password" class="form-label fw-semibold text-secondary-emphasis small">Password</label>
            <div class="input-group">
                <span class="input-group-text bg-light text-muted border-end-0"><i class="bi bi-lock"></i></span>
                <input type="password" class="form-control border-start-0" id="password" name="password" placeholder="At least 6 characters" required>
            </div>
        </div>

        <div class="mb-4">
            <label for="confirm_password" class="form-label fw-semibold text-secondary-emphasis small">Confirm Password</label>
            <div class="input-group">
                <span class="input-group-text bg-light text-muted border-end-0"><i class="bi bi-shield-check"></i></span>
                <input type="password" class="form-control border-start-0" id="confirm_password" name="confirm_password" placeholder="Re-enter password" required>
            </div>
        </div>

        <button type="submit" class="btn btn-primary w-100 py-2 mb-3 shadow-sm">
            Create Free Account
        </button>

        <div class="text-center">
            <p class="small text-muted mb-0">Already have an account? <a href="login.php" class="fw-bold">Sign In</a></p>
        </div>
    </form>
</div>

</body>
</html>
