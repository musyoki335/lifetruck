<?php
/**
 * LifeTrack - Daily Planner
 */
require_once __DIR__ . '/includes/auth.php';

require_login();

$user_id = current_user_id();
$pdo = get_db();

$selected_date = $_GET['date'] ?? get_current_date();
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $selected_date)) {
    $selected_date = get_current_date();
}

$error = '';
$success = '';

// Handle Form Submissions: Create, Edit, Delete
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        set_flash('danger', 'Invalid security token.');
        header("Location: daily-plan.php?date=" . urlencode($selected_date));
        exit;
    }

    if ($action === 'create') {
        $task = trim($_POST['task'] ?? '');
        $priority = in_array($_POST['priority'] ?? '', ['low', 'medium', 'high']) ? $_POST['priority'] : 'medium';
        $notes = trim($_POST['notes'] ?? '');
        $plan_date = $_POST['plan_date'] ?? $selected_date;

        if (empty($task)) {
            set_flash('danger', 'Task name cannot be empty.');
        } else {
            $stmt = $pdo->prepare("INSERT INTO daily_plans (user_id, plan_date, task, priority, notes) VALUES (:user_id, :plan_date, :task, :priority, :notes)");
            $stmt->execute([
                'user_id' => $user_id,
                'plan_date' => $plan_date,
                'task' => $task,
                'priority' => $priority,
                'notes' => $notes ?: null
            ]);
            set_flash('success', 'Task added successfully.');
        }
        header("Location: daily-plan.php?date=" . urlencode($plan_date));
        exit;
    }

    if ($action === 'update') {
        $task_id = (int)($_POST['task_id'] ?? 0);
        $task = trim($_POST['task'] ?? '');
        $priority = in_array($_POST['priority'] ?? '', ['low', 'medium', 'high']) ? $_POST['priority'] : 'medium';
        $notes = trim($_POST['notes'] ?? '');

        if ($task_id <= 0 || empty($task)) {
            set_flash('danger', 'Invalid task details.');
        } else {
            $stmt = $pdo->prepare("UPDATE daily_plans SET task = :task, priority = :priority, notes = :notes WHERE id = :id AND user_id = :user_id");
            $stmt->execute([
                'task' => $task,
                'priority' => $priority,
                'notes' => $notes ?: null,
                'id' => $task_id,
                'user_id' => $user_id
            ]);
            set_flash('success', 'Task updated successfully.');
        }
        header("Location: daily-plan.php?date=" . urlencode($selected_date));
        exit;
    }

    if ($action === 'delete') {
        $task_id = (int)($_POST['task_id'] ?? 0);
        if ($task_id > 0) {
            $stmt = $pdo->prepare("DELETE FROM daily_plans WHERE id = :id AND user_id = :user_id");
            $stmt->execute(['id' => $task_id, 'user_id' => $user_id]);
            set_flash('success', 'Task deleted successfully.');
        }
        header("Location: daily-plan.php?date=" . urlencode($selected_date));
        exit;
    }
}

// Fetch tasks for the selected date
$filter = $_GET['filter'] ?? 'all'; // 'all', 'pending', 'completed'
$sql = "SELECT * FROM daily_plans WHERE user_id = :user_id AND plan_date = :plan_date";

if ($filter === 'pending') {
    $sql .= " AND completed = 0";
} elseif ($filter === 'completed') {
    $sql .= " AND completed = 1";
}
$sql .= " ORDER BY completed ASC, CASE priority WHEN 'high' THEN 1 WHEN 'medium' THEN 2 WHEN 'low' THEN 3 ELSE 4 END, id ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute(['user_id' => $user_id, 'plan_date' => $selected_date]);
$tasks = $stmt->fetchAll();

// Calculate total metrics for selected date
$metric_stmt = $pdo->prepare("
    SELECT 
        COUNT(*) AS total,
        SUM(CASE WHEN completed = 1 THEN 1 ELSE 0 END) AS completed,
        SUM(CASE WHEN priority = 'high' AND completed = 0 THEN 1 ELSE 0 END) AS high_pending
    FROM daily_plans 
    WHERE user_id = :user_id AND plan_date = :plan_date
");
$metric_stmt->execute(['user_id' => $user_id, 'plan_date' => $selected_date]);
$metrics = $metric_stmt->fetch();

$total_tasks = (int)($metrics['total'] ?? 0);
$completed_tasks = (int)($metrics['completed'] ?? 0);
$completion_pct = $total_tasks > 0 ? (int)round(($completed_tasks / $total_tasks) * 100) : 0;
$high_pending = (int)($metrics['high_pending'] ?? 0);

$page_title = 'Daily Planner - LifeTrack';
$page_heading = "Daily Planner";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<main class="app-main">
    <?php require_once __DIR__ . '/includes/navbar.php'; ?>

    <div class="app-content">
        <?php $flash = get_flash(); if ($flash): ?>
            <div class="alert alert-<?= e($flash['type']) ?> alert-dismissible fade show mb-4 rounded-3 border-0 shadow-sm" role="alert">
                <i class="bi bi-info-circle-fill me-2"></i> <?= e($flash['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Date Navigator Bar -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-3">
                <div class="row g-3 align-items-center justify-content-between">
                    <div class="col-md-auto d-flex align-items-center gap-2">
                        <?php 
                            $prev_date = date('Y-m-d', strtotime('-1 day', strtotime($selected_date)));
                            $next_date = date('Y-m-d', strtotime('+1 day', strtotime($selected_date)));
                        ?>
                        <a href="daily-plan.php?date=<?= $prev_date ?>" class="btn btn-light btn-sm" title="Previous Day">
                            <i class="bi bi-chevron-left"></i>
                        </a>
                        <form method="GET" action="daily-plan.php" class="d-flex align-items-center gap-2 mb-0">
                            <input type="date" name="date" class="form-control form-control-sm fw-semibold" value="<?= e($selected_date) ?>" onchange="this.form.submit()">
                        </form>
                        <a href="daily-plan.php?date=<?= $next_date ?>" class="btn btn-light btn-sm" title="Next Day">
                            <i class="bi bi-chevron-right"></i>
                        </a>
                        <?php if ($selected_date !== get_current_date()): ?>
                            <a href="daily-plan.php?date=<?= get_current_date() ?>" class="btn btn-outline-secondary btn-sm">
                                Jump to Today
                            </a>
                        <?php endif; ?>
                    </div>

                    <div class="col-md-auto d-flex align-items-center gap-3">
                        <div class="text-md-end">
                            <h5 class="mb-0 fw-bold text-dark"><?= e(format_date_friendly($selected_date)) ?></h5>
                            <small class="text-muted"><?= $completed_tasks ?> of <?= $total_tasks ?> tasks completed (<?= $completion_pct ?>%)</small>
                        </div>
                        <button type="button" class="btn btn-primary btn-sm d-flex align-items-center gap-1 shadow-sm" data-bs-toggle="modal" data-bs-target="#addTaskModal">
                            <i class="bi bi-plus-lg"></i> Add Task
                        </button>
                    </div>
                </div>

                <!-- Daily Progress Bar -->
                <div class="progress mt-3" style="height: 8px;">
                    <div id="dailyProgressBar" class="progress-bar" style="width: <?= $completion_pct ?>%; background-color: var(--primary-color);"></div>
                </div>
            </div>
        </div>

        <!-- Task Filters & Grouping -->
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div class="btn-group btn-group-sm">
                <a href="daily-plan.php?date=<?= urlencode($selected_date) ?>&filter=all" class="btn btn-<?= $filter === 'all' ? 'primary' : 'light' ?>">All (<?= $total_tasks ?>)</a>
                <a href="daily-plan.php?date=<?= urlencode($selected_date) ?>&filter=pending" class="btn btn-<?= $filter === 'pending' ? 'primary' : 'light' ?>">Pending (<?= $total_tasks - $completed_tasks ?>)</a>
                <a href="daily-plan.php?date=<?= urlencode($selected_date) ?>&filter=completed" class="btn btn-<?= $filter === 'completed' ? 'primary' : 'light' ?>">Completed (<?= $completed_tasks ?>)</a>
            </div>

            <?php if ($high_pending > 0): ?>
                <span class="badge bg-danger-subtle text-danger border border-danger-subtle px-2 py-1">
                    <i class="bi bi-exclamation-circle me-1"></i> <?= $high_pending ?> High Priority Pending
                </span>
            <?php endif; ?>
        </div>

        <!-- Tasks List Card -->
        <div class="card border-0 shadow-sm">
            <div class="card-body p-3">
                <?php if (empty($tasks)): ?>
                    <div class="empty-state py-5 text-center">
                        <div class="empty-state-icon">
                            <i class="bi bi-calendar2-check"></i>
                        </div>
                        <h5 class="empty-state-title">No tasks for this day</h5>
                        <p class="empty-state-text">Plan ahead to maintain focus and make intentional progress toward your goals.</p>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addTaskModal">
                            <i class="bi bi-plus-lg me-1"></i> Add First Task
                        </button>
                    </div>
                <?php else: ?>
                    <div class="task-list">
                        <?php foreach ($tasks as $t): ?>
                            <div class="task-item d-flex align-items-center justify-content-between <?= $t['completed'] ? 'is-completed' : '' ?>" id="task-item-<?= (int)$t['id'] ?>">
                                <div class="d-flex align-items-center flex-grow-1 me-3">
                                    <input class="form-check-input task-checkbox task-checkbox-ajax" 
                                           type="checkbox" 
                                           data-task-id="<?= (int)$t['id'] ?>" 
                                           id="task-<?= (int)$t['id'] ?>"
                                           <?= $t['completed'] ? 'checked' : '' ?>>
                                    <div class="flex-grow-1">
                                        <label class="form-check-label task-title fw-semibold text-dark mb-0 cursor-pointer" for="task-<?= (int)$t['id'] ?>">
                                            <?= e($t['task']) ?>
                                        </label>
                                        <?php if (!empty($t['notes'])): ?>
                                            <div class="small text-muted mt-1 fst-italic">
                                                <i class="bi bi-sticky me-1"></i> <?= e($t['notes']) ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="d-flex align-items-center gap-2">
                                    <span class="badge priority-badge priority-<?= e($t['priority']) ?>">
                                        <?= strtoupper(e($t['priority'])) ?>
                                    </span>

                                    <!-- Edit Task Trigger -->
                                    <button type="button" 
                                            class="btn btn-light btn-sm text-secondary p-1" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#editTaskModal<?= (int)$t['id'] ?>" 
                                            title="Edit task">
                                        <i class="bi bi-pencil"></i>
                                    </button>

                                    <!-- Delete Task Form -->
                                    <form method="POST" action="daily-plan.php?date=<?= urlencode($selected_date) ?>" onsubmit="return confirm('Are you sure you want to delete this task?');" class="d-inline mb-0">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="task_id" value="<?= (int)$t['id'] ?>">
                                        <button type="submit" class="btn btn-light btn-sm text-danger p-1" title="Delete task">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>

                            <!-- Edit Modal for this task -->
                            <div class="modal fade" id="editTaskModal<?= (int)$t['id'] ?>" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content border-0 shadow">
                                        <form method="POST" action="daily-plan.php?date=<?= urlencode($selected_date) ?>">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="action" value="update">
                                            <input type="hidden" name="task_id" value="<?= (int)$t['id'] ?>">
                                            <div class="modal-header">
                                                <h5 class="modal-title fw-bold">Edit Task</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label class="form-label fw-semibold small">Task Description</label>
                                                    <input type="text" name="task" class="form-control" value="<?= e($t['task']) ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label fw-semibold small">Priority</label>
                                                    <select name="priority" class="form-select">
                                                        <option value="low" <?= $t['priority'] === 'low' ? 'selected' : '' ?>>Low Priority</option>
                                                        <option value="medium" <?= $t['priority'] === 'medium' ? 'selected' : '' ?>>Medium Priority</option>
                                                        <option value="high" <?= $t['priority'] === 'high' ? 'selected' : '' ?>>High Priority</option>
                                                    </select>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label fw-semibold small">Notes / Details (Optional)</label>
                                                    <textarea name="notes" class="form-control" rows="3"><?= e($t['notes'] ?? '') ?></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer bg-light">
                                                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                                                <button type="submit" class="btn btn-primary">Save Changes</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

<!-- Add Task Modal -->
<div class="modal fade" id="addTaskModal" tabindex="-1" aria-labelledby="addTaskModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <form method="POST" action="daily-plan.php?date=<?= urlencode($selected_date) ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="create">
                <input type="hidden" name="plan_date" value="<?= e($selected_date) ?>">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold" id="addTaskModalLabel">Add Daily Task</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="newTaskName" class="form-label fw-semibold small">Task Description</label>
                        <input type="text" id="newTaskName" name="task" class="form-control" placeholder="e.g. Complete quarterly budget review" required autofocus>
                    </div>
                    <div class="mb-3">
                        <label for="newTaskPriority" class="form-label fw-semibold small">Priority Level</label>
                        <select id="newTaskPriority" name="priority" class="form-select">
                            <option value="medium" selected>Medium Priority</option>
                            <option value="high">High Priority</option>
                            <option value="low">Low Priority</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="newTaskNotes" class="form-label fw-semibold small">Notes (Optional)</label>
                        <textarea id="newTaskNotes" name="notes" class="form-control" rows="3" placeholder="Context, links, or specific steps..."></textarea>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Add Task</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if (isset($_GET['action']) && $_GET['action'] === 'new'): ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var modal = new bootstrap.Modal(document.getElementById('addTaskModal'));
        modal.show();
    });
</script>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
