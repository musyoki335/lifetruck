<?php
/**
 * LifeTrack - Password Reset Request
 */
require_once __DIR__ . '/includes/auth.php';

require_guest();

$message = '';
$error = '';
$step = 1; // 1: request email, 2: set new password directly (convenient for local XAMPP)
$reset_email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        $error = 'Session token invalid. Please try again.';
    } elseif ($action === 'verify_email') {
        $reset_email = trim($_POST['email'] ?? '');
        if (empty($reset_email) || !filter_var($reset_email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Please enter a valid email address.';
        } else {
            $pdo = get_db();
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = :email LIMIT 1");
            $stmt->execute(['email' => strtolower($reset_email)]);
            if ($stmt->fetch()) {
                $step = 2;
                $message = 'Account verified. You may now set a new password.';
            } else {
                $error = 'No account found with this email address.';
            }
        }
    } elseif ($action === 'reset_password') {
        $reset_email = trim($_POST['email'] ?? '');
        $new_pass = $_POST['new_password'] ?? '';
        $confirm_pass = $_POST['confirm_password'] ?? '';

        if (strlen($new_pass) < 6) {
            $error = 'New password must be at least 6 characters.';
            $step = 2;
        } elseif ($new_pass !== $confirm_pass) {
            $error = 'Passwords do not match.';
            $step = 2;
        } else {
            $pdo = get_db();
            $hash = password_hash($new_pass, PASSWORD_DEFAULT);
            $upd = $pdo->prepare("UPDATE users SET password = :password WHERE email = :email");
            $upd->execute(['password' => $hash, 'email' => strtolower($reset_email)]);

            set_flash('success', 'Your password has been reset successfully. Please log in.');
            header('Location: login.php');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - LifeTrack</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            background: linear-gradient(135deg, #F4F6F2 0%, #E9EEE6 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem 1rem;
        }
        .auth-card {
            background: #FFFFFF;
            border-radius: var(--radius-lg);
            box-shadow: 0 15px 35px rgba(31, 77, 58, 0.08);
            border: 1px solid var(--border-color);
            width: 100%;
            max-width: 440px;
            padding: 2.5rem;
        }
    </style>
</head>
<body>

<div class="auth-card">
    <div class="text-center mb-4">
        <div class="brand-icon mx-auto mb-3" style="width: 48px; height: 48px; font-size: 1.5rem;">
            <i class="bi bi-key"></i>
        </div>
        <h2 class="fw-bold mb-1" style="color: var(--primary-color);">Reset Password</h2>
        <p class="text-muted small">Regain access to your personal growth dashboard.</p>
    </div>

    <?php if (!empty($message)): ?>
        <div class="alert alert-success py-2 px-3 mb-4 rounded-3 small text-center">
            <?= e($message) ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($error)): ?>
        <div class="alert alert-danger py-2 px-3 mb-4 rounded-3 small text-center">
            <?= e($error) ?>
        </div>
    <?php endif; ?>

    <?php if ($step === 1): ?>
        <form method="POST" action="forgot-password.php">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="verify_email">

            <div class="mb-3">
                <label for="email" class="form-label fw-semibold text-secondary-emphasis small">Registered Email Address</label>
                <div class="input-group">
                    <span class="input-group-text bg-light text-muted border-end-0"><i class="bi bi-envelope"></i></span>
                    <input type="email" class="form-control border-start-0" id="email" name="email" value="<?= e($reset_email) ?>" placeholder="name@example.com" required autofocus>
                </div>
            </div>

            <button type="submit" class="btn btn-primary w-100 py-2 mb-3 shadow-sm">
                Verify Account
            </button>

            <div class="text-center">
                <a href="login.php" class="small text-muted text-decoration-none"><i class="bi bi-arrow-left"></i> Back to Login</a>
            </div>
        </form>
    <?php else: ?>
        <form method="POST" action="forgot-password.php">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="reset_password">
            <input type="hidden" name="email" value="<?= e($reset_email) ?>">

            <div class="mb-3">
                <label for="new_password" class="form-label fw-semibold text-secondary-emphasis small">New Password</label>
                <div class="input-group">
                    <span class="input-group-text bg-light text-muted border-end-0"><i class="bi bi-lock"></i></span>
                    <input type="password" class="form-control border-start-0" id="new_password" name="new_password" placeholder="At least 6 characters" required autofocus>
                </div>
            </div>

            <div class="mb-4">
                <label for="confirm_password" class="form-label fw-semibold text-secondary-emphasis small">Confirm New Password</label>
                <div class="input-group">
                    <span class="input-group-text bg-light text-muted border-end-0"><i class="bi bi-shield-check"></i></span>
                    <input type="password" class="form-control border-start-0" id="confirm_password" name="confirm_password" placeholder="Re-enter password" required>
                </div>
            </div>

            <button type="submit" class="btn btn-primary w-100 py-2 mb-3 shadow-sm">
                Update Password
            </button>

            <div class="text-center">
                <a href="login.php" class="small text-muted text-decoration-none"><i class="bi bi-arrow-left"></i> Cancel</a>
            </div>
        </form>
    <?php endif; ?>
</div>

</body>
</html>
