<?php
/**
 * LifeTrack - Habit Tracker & Streak Engine
 */
require_once __DIR__ . '/includes/auth.php';

require_login();

$user_id = current_user_id();
$pdo = get_db();
$today = get_current_date();

// Handle Actions: Create, Edit, Toggle Archive, Delete
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        set_flash('danger', 'Security token expired. Please try again.');
        header('Location: habits.php');
        exit;
    }

    if ($action === 'create_habit') {
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $frequency = in_array($_POST['frequency'] ?? '', ['daily', 'weekdays', 'weekends', 'custom']) ? $_POST['frequency'] : 'daily';
        $color = trim($_POST['color'] ?? '#1F4D3A');

        if (empty($name)) {
            set_flash('danger', 'Habit name is required.');
        } else {
            $stmt = $pdo->prepare("INSERT INTO habits (user_id, name, description, frequency, color, is_active) VALUES (:user_id, :name, :description, :frequency, :color, 1)");
            $stmt->execute([
                'user_id' => $user_id,
                'name' => $name,
                'description' => $description ?: null,
                'frequency' => $frequency,
                'color' => $color
            ]);
            set_flash('success', 'Habit created successfully! Start building your streak.');
        }
        header('Location: habits.php');
        exit;
    }

    if ($action === 'update_habit') {
        $habit_id = (int)($_POST['habit_id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $frequency = in_array($_POST['frequency'] ?? '', ['daily', 'weekdays', 'weekends', 'custom']) ? $_POST['frequency'] : 'daily';
        $color = trim($_POST['color'] ?? '#1F4D3A');

        if ($habit_id <= 0 || empty($name)) {
            set_flash('danger', 'Habit name is required.');
        } else {
            $stmt = $pdo->prepare("UPDATE habits SET name = :name, description = :description, frequency = :frequency, color = :color WHERE id = :id AND user_id = :user_id");
            $stmt->execute([
                'name' => $name,
                'description' => $description ?: null,
                'frequency' => $frequency,
                'color' => $color,
                'id' => $habit_id,
                'user_id' => $user_id
            ]);
            set_flash('success', 'Habit updated successfully.');
        }
        header('Location: habits.php');
        exit;
    }

    if ($action === 'toggle_archive') {
        $habit_id = (int)($_POST['habit_id'] ?? 0);
        $target_status = !empty($_POST['is_active']) ? 1 : 0;

        if ($habit_id > 0) {
            $stmt = $pdo->prepare("UPDATE habits SET is_active = :status WHERE id = :id AND user_id = :user_id");
            $stmt->execute([
                'status' => $target_status,
                'id' => $habit_id,
                'user_id' => $user_id
            ]);
            $msg = $target_status ? 'Habit restored to active routine.' : 'Habit archived.';
            set_flash('info', $msg);
        }
        header('Location: habits.php');
        exit;
    }

    if ($action === 'delete_habit') {
        $habit_id = (int)($_POST['habit_id'] ?? 0);
        if ($habit_id > 0) {
            $stmt = $pdo->prepare("DELETE FROM habits WHERE id = :id AND user_id = :user_id");
            $stmt->execute(['id' => $habit_id, 'user_id' => $user_id]);
            set_flash('success', 'Habit and history deleted.');
        }
        header('Location: habits.php');
        exit;
    }
}

// Fetch Habits
$view_mode = $_GET['view'] ?? 'active'; // 'active' or 'archived'
$is_active_filter = ($view_mode === 'archived') ? 0 : 1;

$stmt = $pdo->prepare("SELECT * FROM habits WHERE user_id = :user_id AND is_active = :is_active ORDER BY id ASC");
$stmt->execute(['user_id' => $user_id, 'is_active' => $is_active_filter]);
$habits = $stmt->fetchAll();

// Calculate streak data for all habits
$habits_data = [];
$total_streaks_sum = 0;
$best_overall_streak = 0;

foreach ($habits as $h) {
    $streaks = calculate_habit_streak($pdo, (int)$h['id'], $user_id);
    $total_streaks_sum += $streaks['current_streak'];
    if ($streaks['longest_streak'] > $best_overall_streak) {
        $best_overall_streak = $streaks['longest_streak'];
    }
    $habits_data[] = [
        'habit' => $h,
        'metrics' => $streaks
    ];
}

$page_title = 'Habit Tracker - LifeTrack';
$page_heading = "Habit Tracker";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<main class="app-main">
    <?php require_once __DIR__ . '/includes/navbar.php'; ?>

    <div class="app-content">
        <?php $flash = get_flash(); if ($flash): ?>
            <div class="alert alert-<?= e($flash['type']) ?> alert-dismissible fade show mb-4 rounded-3 border-0 shadow-sm" role="alert">
                <i class="bi bi-info-circle-fill me-2"></i> <?= e($flash['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Habit Overview Header & Summary Metrics -->
        <div class="row g-3 mb-4">
            <div class="col-sm-4">
                <div class="card border-0 shadow-sm p-3">
                    <div class="d-flex align-items-center gap-3">
                        <div class="p-3 rounded-circle bg-warning-subtle text-warning fs-3">
                            <i class="bi bi-fire"></i>
                        </div>
                        <div>
                            <div class="text-muted small fw-semibold">Best Longest Streak</div>
                            <div class="h4 fw-bold text-dark mb-0"><?= $best_overall_streak ?> Days</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-4">
                <div class="card border-0 shadow-sm p-3">
                    <div class="d-flex align-items-center gap-3">
                        <div class="p-3 rounded-circle bg-success-subtle text-success fs-3">
                            <i class="bi bi-check2-all"></i>
                        </div>
                        <div>
                            <div class="text-muted small fw-semibold">Active Habits</div>
                            <div class="h4 fw-bold text-dark mb-0"><?= count($habits_data) ?> Tracked</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-4">
                <div class="card border-0 shadow-sm p-3">
                    <div class="d-flex align-items-center gap-3">
                        <div class="p-3 rounded-circle bg-info-subtle text-info fs-3">
                            <i class="bi bi-calendar3-range"></i>
                        </div>
                        <div>
                            <div class="text-muted small fw-semibold">Streak Momentum</div>
                            <div class="h4 fw-bold text-dark mb-0"><?= $total_streaks_sum ?> Total Days</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Controls Bar -->
        <div class="d-flex flex-column flex-sm-row justify-content-between align-items-sm-center gap-3 mb-4">
            <div class="btn-group btn-group-sm">
                <a href="habits.php?view=active" class="btn btn-<?= $view_mode === 'active' ? 'primary' : 'light' ?>">
                    Active Habits
                </a>
                <a href="habits.php?view=archived" class="btn btn-<?= $view_mode === 'archived' ? 'primary' : 'light' ?>">
                    Archived
                </a>
            </div>

            <button type="button" class="btn btn-primary d-flex align-items-center gap-1 shadow-sm" data-bs-toggle="modal" data-bs-target="#createHabitModal">
                <i class="bi bi-plus-lg"></i> Create New Habit
            </button>
        </div>

        <!-- Habits List -->
        <?php if (empty($habits_data)): ?>
            <div class="card border-0 shadow-sm">
                <div class="card-body p-5">
                    <div class="empty-state">
                        <div class="empty-state-icon">
                            <i class="bi bi-fire"></i>
                        </div>
                        <h5 class="empty-state-title"><?= $view_mode === 'archived' ? 'No archived habits' : 'No habits yet' ?></h5>
                        <p class="empty-state-text">
                            <?= $view_mode === 'archived' ? 'When you archive habits, they will appear here.' : 'Create your first habit and start building your routine with consistency and purpose.' ?>
                        </p>
                        <?php if ($view_mode === 'active'): ?>
                            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createHabitModal">
                                <i class="bi bi-plus-lg me-1"></i> Create First Habit
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="row g-3">
                <?php foreach ($habits_data as $item): 
                    $h = $item['habit'];
                    $m = $item['metrics'];
                ?>
                    <div class="col-12">
                        <div class="habit-card shadow-sm border-0">
                            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
                                <!-- Habit Info -->
                                <div class="flex-grow-1">
                                    <div class="d-flex align-items-center gap-2 mb-1">
                                        <span class="rounded-circle d-inline-block" style="width: 12px; height: 12px; background-color: <?= e($h['color']) ?>;"></span>
                                        <h5 class="fw-bold mb-0 text-dark"><?= e($h['name']) ?></h5>
                                        <span class="badge bg-light text-muted border text-capitalize" style="font-size: 0.7rem;"><?= e($h['frequency']) ?></span>
                                    </div>
                                    <?php if (!empty($h['description'])): ?>
                                        <p class="text-muted small mb-2"><?= e($h['description']) ?></p>
                                    <?php endif; ?>
                                    
                                    <div class="d-flex flex-wrap gap-2 align-items-center mt-2">
                                        <span class="streak-badge" id="habit-streak-<?= (int)$h['id'] ?>">
                                            🔥 <?= (int)$m['current_streak'] ?> day streak
                                        </span>
                                        <span class="streak-best-badge" id="habit-best-<?= (int)$h['id'] ?>">
                                            Best: <?= (int)$m['longest_streak'] ?> days
                                        </span>
                                        <span class="badge bg-light text-dark border">
                                            <?= (int)$m['completion_rate'] ?>% rate
                                        </span>
                                    </div>
                                </div>

                                <!-- 7-Day Tracker Matrix -->
                                <div class="habit-day-grid py-2 px-3 bg-light rounded-3">
                                    <?php foreach ($m['last_7_days'] as $day): ?>
                                        <div class="habit-day-item">
                                            <span class="habit-day-name <?= $day['is_today'] ? 'text-dark fw-bold' : '' ?>">
                                                <?= e($day['day_name']) ?>
                                            </span>
                                            <button type="button" 
                                                    class="habit-check-btn habit-check-ajax <?= $day['completed'] ? 'completed' : '' ?> <?= $day['is_today'] ? 'is-today' : '' ?>"
                                                    data-habit-id="<?= (int)$h['id'] ?>"
                                                    data-date="<?= e($day['date']) ?>"
                                                    title="<?= e($day['date']) ?>: Click to toggle">
                                                <?= $day['completed'] ? '<i class="bi bi-check-lg"></i>' : '' ?>
                                            </button>
                                        </div>
                                    <?php endforeach; ?>
                                </div>

                                <!-- Actions Dropdown -->
                                <div class="dropdown align-self-end align-self-md-center">
                                    <button class="btn btn-light btn-sm p-2 rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        <i class="bi bi-three-dots-vertical"></i>
                                    </button>
                                    <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0">
                                        <li>
                                            <button type="button" class="dropdown-item py-2" data-bs-toggle="modal" data-bs-target="#editHabitModal<?= (int)$h['id'] ?>">
                                                <i class="bi bi-pencil me-2 text-secondary"></i> Edit Habit
                                            </button>
                                        </li>
                                        <li>
                                            <form method="POST" action="habits.php">
                                                <?= csrf_field() ?>
                                                <input type="hidden" name="action" value="toggle_archive">
                                                <input type="hidden" name="habit_id" value="<?= (int)$h['id'] ?>">
                                                <input type="hidden" name="is_active" value="<?= $h['is_active'] ? '0' : '1' ?>">
                                                <button type="submit" class="dropdown-item py-2">
                                                    <i class="bi <?= $h['is_active'] ? 'bi-archive text-warning' : 'bi-arrow-counterclockwise text-success' ?> me-2"></i>
                                                    <?= $h['is_active'] ? 'Archive Habit' : 'Restore Habit' ?>
                                                </button>
                                            </form>
                                        </li>
                                        <li><hr class="dropdown-divider"></li>
                                        <li>
                                            <form method="POST" action="habits.php" onsubmit="return confirm('Permanently delete this habit and all logged history?');">
                                                <?= csrf_field() ?>
                                                <input type="hidden" name="action" value="delete_habit">
                                                <input type="hidden" name="habit_id" value="<?= (int)$h['id'] ?>">
                                                <button type="submit" class="dropdown-item py-2 text-danger">
                                                    <i class="bi bi-trash me-2"></i> Delete Habit
                                                </button>
                                            </form>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <!-- Edit Habit Modal -->
                        <div class="modal fade" id="editHabitModal<?= (int)$h['id'] ?>" tabindex="-1" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content border-0 shadow">
                                    <form method="POST" action="habits.php">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="update_habit">
                                        <input type="hidden" name="habit_id" value="<?= (int)$h['id'] ?>">
                                        <div class="modal-header">
                                            <h5 class="modal-title fw-bold">Edit Habit</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="mb-3">
                                                <label class="form-label fw-semibold small">Habit Name</label>
                                                <input type="text" name="name" class="form-control" value="<?= e($h['name']) ?>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label fw-semibold small">Description</label>
                                                <textarea name="description" class="form-control" rows="2"><?= e($h['description'] ?? '') ?></textarea>
                                            </div>
                                            <div class="row g-3">
                                                <div class="col-sm-6">
                                                    <label class="form-label fw-semibold small">Frequency</label>
                                                    <select name="frequency" class="form-select">
                                                        <option value="daily" <?= $h['frequency'] === 'daily' ? 'selected' : '' ?>>Daily</option>
                                                        <option value="weekdays" <?= $h['frequency'] === 'weekdays' ? 'selected' : '' ?>>Weekdays Only</option>
                                                        <option value="weekends" <?= $h['frequency'] === 'weekends' ? 'selected' : '' ?>>Weekends Only</option>
                                                        <option value="custom" <?= $h['frequency'] === 'custom' ? 'selected' : '' ?>>Custom Target</option>
                                                    </select>
                                                </div>
                                                <div class="col-sm-6">
                                                    <label class="form-label fw-semibold small">Color Tag</label>
                                                    <input type="color" name="color" class="form-control form-control-color w-100" value="<?= e($h['color'] ?? '#1F4D3A') ?>">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer bg-light">
                                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                                            <button type="submit" class="btn btn-primary">Save Changes</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

<!-- Create Habit Modal -->
<div class="modal fade" id="createHabitModal" tabindex="-1" aria-labelledby="createHabitModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <form method="POST" action="habits.php">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="create_habit">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold" id="createHabitModalLabel">Create New Habit</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="habitNameInput" class="form-label fw-semibold small">Habit Name</label>
                        <input type="text" id="habitNameInput" name="name" class="form-control" placeholder="e.g. Daily Scripture & Prayer" required autofocus>
                    </div>
                    <div class="mb-3">
                        <label for="habitDescInput" class="form-label fw-semibold small">Description / Why it matters (Optional)</label>
                        <textarea id="habitDescInput" name="description" class="form-control" rows="2" placeholder="Start each morning in peace and intention..."></textarea>
                    </div>
                    <div class="row g-3">
                        <div class="col-sm-6">
                            <label for="habitFreqSelect" class="form-label fw-semibold small">Frequency</label>
                            <select id="habitFreqSelect" name="frequency" class="form-select">
                                <option value="daily" selected>Daily</option>
                                <option value="weekdays">Weekdays</option>
                                <option value="weekends">Weekends</option>
                                <option value="custom">Custom</option>
                            </select>
                        </div>
                        <div class="col-sm-6">
                            <label for="habitColorInput" class="form-label fw-semibold small">Color Indicator</label>
                            <input type="color" id="habitColorInput" name="color" class="form-control form-control-color w-100" value="#1F4D3A">
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Create Habit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if (isset($_GET['action']) && $_GET['action'] === 'new'): ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var modal = new bootstrap.Modal(document.getElementById('createHabitModal'));
        modal.show();
    });
</script>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
