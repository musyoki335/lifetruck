/**
 * LifeTrack - Interactive Client Logic & AJAX Handlers
 */

document.addEventListener('DOMContentLoaded', function () {
    // -------------------------------------------------------------
    // 1. Toast Notification Utility
    // -------------------------------------------------------------
    function showToast(message, type = 'success') {
        let container = document.querySelector('.lifetrack-toast-container');
        if (!container) {
            container = document.createElement('div');
            container.className = 'lifetrack-toast-container';
            document.body.appendChild(container);
        }

        const toast = document.createElement('div');
        toast.className = `lifetrack-toast ${type}`;
        
        const icon = type === 'success' 
            ? '<i class="bi bi-check-circle-fill text-success fs-5"></i>' 
            : '<i class="bi bi-exclamation-triangle-fill text-danger fs-5"></i>';

        toast.innerHTML = `
            ${icon}
            <div class="flex-grow-1">${message}</div>
            <button type="button" class="btn-close btn-close-white ms-2" aria-label="Close"></button>
        `;

        const closeBtn = toast.querySelector('.btn-close');
        closeBtn.addEventListener('click', () => toast.remove());

        container.appendChild(toast);

        setTimeout(() => {
            if (toast.parentNode) {
                toast.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
                toast.style.opacity = '0';
                toast.style.transform = 'translateY(15px)';
                setTimeout(() => toast.remove(), 300);
            }
        }, 3500);
    }
    window.showToast = showToast;

    // Helper to get CSRF token
    function getCsrfToken() {
        const meta = document.querySelector('meta[name="csrf-token"]');
        return meta ? meta.getAttribute('content') : '';
    }

    // -------------------------------------------------------------
    // 2. Mobile Sidebar Toggle
    // -------------------------------------------------------------
    const sidebarToggleBtn = document.getElementById('sidebarToggleBtn');
    const sidebar = document.querySelector('.app-sidebar');
    const sidebarBackdrop = document.getElementById('sidebarBackdrop');

    if (sidebarToggleBtn && sidebar) {
        sidebarToggleBtn.addEventListener('click', function () {
            sidebar.classList.toggle('show');
            if (sidebarBackdrop) {
                sidebarBackdrop.classList.toggle('d-none');
            }
        });
    }

    if (sidebarBackdrop && sidebar) {
        sidebarBackdrop.addEventListener('click', function () {
            sidebar.classList.remove('show');
            sidebarBackdrop.classList.add('d-none');
        });
    }

    // -------------------------------------------------------------
    // 3. AJAX Task Toggle (Daily Planner & Dashboard)
    // -------------------------------------------------------------
    document.querySelectorAll('.task-checkbox-ajax').forEach(function (checkbox) {
        checkbox.addEventListener('change', function () {
            const taskId = this.dataset.taskId;
            const isCompleted = this.checked ? 1 : 0;
            const taskItem = document.getElementById(`task-item-${taskId}`);

            fetch('api/toggle-task.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({
                    task_id: taskId,
                    completed: isCompleted,
                    csrf_token: getCsrfToken()
                })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    if (taskItem) {
                        if (isCompleted) {
                            taskItem.classList.add('is-completed');
                        } else {
                            taskItem.classList.remove('is-completed');
                        }
                    }

                    // Update progress bar & label if present
                    const progressBar = document.getElementById('dailyProgressBar');
                    const progressText = document.getElementById('dailyProgressText');
                    const progressCount = document.getElementById('dailyProgressCount');

                    if (progressBar && data.completion_rate !== undefined) {
                        progressBar.style.width = `${data.completion_rate}%`;
                    }
                    if (progressText && data.completion_rate !== undefined) {
                        progressText.textContent = `${data.completion_rate}%`;
                    }
                    if (progressCount && data.completed_count !== undefined && data.total_count !== undefined) {
                        progressCount.textContent = `${data.completed_count} of ${data.total_count} tasks completed`;
                    }

                    showToast(isCompleted ? 'Task completed! Keep it up.' : 'Task marked active.', 'success');
                } else {
                    // Revert checkbox on error
                    this.checked = !isCompleted;
                    showToast(data.message || 'Unable to update task.', 'error');
                }
            })
            .catch(err => {
                console.error(err);
                checkbox.checked = !isCompleted;
                showToast('Network error while updating task.', 'error');
            });
        });
    });

    // -------------------------------------------------------------
    // 4. AJAX Habit Toggle
    // -------------------------------------------------------------
    document.querySelectorAll('.habit-check-ajax').forEach(function (btn) {
        btn.addEventListener('click', function () {
            const habitId = this.dataset.habitId;
            const date = this.dataset.date;
            const wasCompleted = this.classList.contains('completed');
            const newStatus = wasCompleted ? 0 : 1;

            btn.disabled = true;

            fetch('api/toggle-habit.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({
                    habit_id: habitId,
                    date: date,
                    completed: newStatus,
                    csrf_token: getCsrfToken()
                })
            })
            .then(res => res.json())
            .then(data => {
                btn.disabled = false;
                if (data.success) {
                    if (newStatus === 1) {
                        btn.classList.add('completed');
                        btn.innerHTML = '<i class="bi bi-check-lg"></i>';
                    } else {
                        btn.classList.remove('completed');
                        btn.innerHTML = '';
                    }

                    // Update streak badge if element exists
                    const streakBadge = document.getElementById(`habit-streak-${habitId}`);
                    if (streakBadge && data.current_streak !== undefined) {
                        streakBadge.innerHTML = `🔥 ${data.current_streak} day streak`;
                    }

                    const bestStreak = document.getElementById(`habit-best-${habitId}`);
                    if (bestStreak && data.longest_streak !== undefined) {
                        bestStreak.textContent = `Best: ${data.longest_streak} days`;
                    }

                    showToast(newStatus === 1 ? 'Habit completed today! 🔥' : 'Habit unchecked.', 'success');
                } else {
                    showToast(data.message || 'Unable to update habit.', 'error');
                }
            })
            .catch(err => {
                btn.disabled = false;
                console.error(err);
                showToast('Network error while logging habit.', 'error');
            });
        });
    });

    // -------------------------------------------------------------
    // 5. AJAX Weekly Goal Toggle
    // -------------------------------------------------------------
    document.querySelectorAll('.weekly-goal-checkbox-ajax').forEach(function (checkbox) {
        checkbox.addEventListener('change', function () {
            const goalId = this.dataset.goalId;
            const isCompleted = this.checked ? 1 : 0;
            const goalItem = document.getElementById(`goal-item-${goalId}`);

            fetch('api/toggle-weekly-goal.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({
                    goal_id: goalId,
                    completed: isCompleted,
                    csrf_token: getCsrfToken()
                })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    if (goalItem) {
                        if (isCompleted) {
                            goalItem.classList.add('text-decoration-line-through', 'text-muted');
                        } else {
                            goalItem.classList.remove('text-decoration-line-through', 'text-muted');
                        }
                    }

                    // Update weekly progress bar
                    const weeklyBar = document.getElementById('weeklyProgressBar');
                    const weeklyText = document.getElementById('weeklyProgressText');
                    if (weeklyBar && data.completion_rate !== undefined) {
                        weeklyBar.style.width = `${data.completion_rate}%`;
                    }
                    if (weeklyText && data.completion_rate !== undefined) {
                        weeklyText.textContent = `${data.completion_rate}%`;
                    }

                    showToast(isCompleted ? 'Weekly goal completed!' : 'Goal marked active.', 'success');
                } else {
                    this.checked = !isCompleted;
                    showToast(data.message || 'Unable to update weekly goal.', 'error');
                }
            })
            .catch(err => {
                console.error(err);
                checkbox.checked = !isCompleted;
                showToast('Network error while updating goal.', 'error');
            });
        });
    });

    // -------------------------------------------------------------
    // 6. AJAX Bible Verse Favorite Toggle
    // -------------------------------------------------------------
    const favVerseBtn = document.getElementById('favVerseBtn');
    if (favVerseBtn) {
        favVerseBtn.addEventListener('click', function () {
            const verseId = this.dataset.verseId;
            const isFav = this.classList.contains('favorited');

            fetch('api/toggle-favorite.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({
                    verse_id: verseId,
                    csrf_token: getCsrfToken()
                })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    if (data.favorited) {
                        favVerseBtn.classList.add('favorited');
                        favVerseBtn.innerHTML = '<i class="bi bi-star-fill text-warning"></i>';
                        showToast('Verse saved to your favorites!', 'success');
                    } else {
                        favVerseBtn.classList.remove('favorited');
                        favVerseBtn.innerHTML = '<i class="bi bi-star"></i>';
                        showToast('Verse removed from favorites.', 'info');
                    }
                } else {
                    showToast(data.message || 'Could not update favorite.', 'error');
                }
            })
            .catch(err => {
                console.error(err);
                showToast('Error updating favorite verse.', 'error');
            });
        });
    }

    // -------------------------------------------------------------
    // 7. Interactive Calendar Day Click Modal
    // -------------------------------------------------------------
    document.querySelectorAll('.calendar-day-cell').forEach(function (cell) {
        cell.addEventListener('click', function () {
            const selectedDate = this.dataset.date;
            if (!selectedDate) return;

            const modalEl = document.getElementById('dayDetailsModal');
            if (!modalEl) return;

            const modalTitle = document.getElementById('dayDetailsModalDate');
            const modalBody = document.getElementById('dayDetailsModalBody');
            
            if (modalTitle) {
                modalTitle.textContent = selectedDate;
            }
            if (modalBody) {
                modalBody.innerHTML = '<div class="text-center py-4"><div class="spinner-border text-success" role="status"></div><p class="text-muted mt-2">Loading day details...</p></div>';
            }

            const bsModal = new bootstrap.Modal(modalEl);
            bsModal.show();

            // Fetch day records via API
            fetch(`api/get-day-details.php?date=${encodeURIComponent(selectedDate)}`)
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        modalBody.innerHTML = data.html;
                    } else {
                        modalBody.innerHTML = `<div class="alert alert-danger">${data.message || 'Failed to load details.'}</div>`;
                    }
                })
                .catch(err => {
                    console.error(err);
                    modalBody.innerHTML = '<div class="alert alert-danger">Error loading day records.</div>';
                });
        });
    });
});
