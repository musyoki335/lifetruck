# LifeTrack - Personal Growth Diary & Habit Tracker Web Application

> **Plan. Build. Reflect. Grow.**

LifeTrack is a full-featured, production-quality personal productivity, habit tracking, daily/weekly planning, and reflective journaling system built with **PHP 8+**, **MySQL**, **HTML5/CSS3**, and **JavaScript**. It incorporates daily Scripture-based encouragement, habit streak tracking, and interactive growth metrics in a calm, modern SaaS aesthetic.

---

## 🌟 Key Features

### 1. 🔐 Complete Authentication & User Isolation
- Secure user registration, login, logout, and password recovery (`register.php`, `login.php`, `logout.php`, `forgot-password.php`).
- Passwords securely hashed with `password_hash()` (Bcrypt).
- Session fixation protection using `session_regenerate_id(true)`.
- Full user data isolation (`WHERE user_id = :user_id`) on all database queries.
- CSRF protection across all forms and AJAX requests.
- Output escaping with `htmlspecialchars()` to eliminate XSS.

### 2. 📖 Daily Bible Encouragement System
- Prominent encouragement card on the dashboard with verse text and Scripture reference.
- **Deterministic Date Rotation**: The same calendar date displays the same verse without changing on page refreshes.
- **120+ Seeded Bible Verses** (covering Discipline, Wisdom, Hope, Courage, Patience, Faith, Work, Purpose, Perseverance, Integrity, Peace, Strength, Planning, Growth) using public-domain texts (World English Bible / KJV).
- Built-in fallback algorithm ensuring any future date has an inspiring verse.
- Instant AJAX **Favorite Toggle**: Save cherished verses to your personal `favorites.php` collection.

### 3. 📅 Daily Planner (`daily-plan.php`)
- Plan tasks for today or any past/future calendar date.
- Prioritize tasks (**High**, **Medium**, **Low**) with visual badges.
- Add contextual notes or sub-tasks.
- Instant AJAX checkboxes for ticking tasks complete without page reloading.
- Real-time progress bar: `(Completed Tasks / Total Tasks) × 100%`.
- Filter tasks by All, Pending, or Completed.

### 4. 🗓️ Weekly Planner (`weekly-plan.php`)
- Set high-level weekly goals and milestones with success criteria.
- 7-Day Day-by-Day schedule view (Monday through Sunday) showing daily tasks in one unified view.
- Weekly progress bar and completion percentage.
- Navigate effortlessly between past, current, and upcoming weeks.

### 5. 🔥 Habit Tracker & Streak Engine (`habits.php`)
- Create and customize habits with custom frequencies (Daily, Weekdays, Weekends, Custom) and color tags.
- Visual 7-day mini-calendar matrix with one-tap completion buttons.
- **Accurate Habit Streak Calculation**:
  - **Current Streak**: Consecutive days completed ending today (or yesterday if today isn't completed yet). Automatically resets when days are missed.
  - **Best Streak**: Maximum consecutive streak record ever achieved.
  - **Completion Rate**: All-time execution consistency percentage.
- Archive habits without losing historical log data.

### 6. 📝 Personal Growth Journal & Diary (`journal.php`)
- Private, reflective journaling for any date.
- Track daily moods with intuitive emotional states: 😊 Great, 🙂 Good, 😐 Okay, 😔 Difficult, 😣 Very difficult.
- Built-in reflection prompts:
  - *"What am I grateful for?"* (cultivates gratitude)
  - *"What did I learn today?"* (identifies growth principles)
- Full-text search and filtering by keywords, dates, and mood states.

### 7. 📆 Interactive Growth Calendar (`calendar.php`)
- Monthly interactive calendar with visual status indicators:
  - **✓ Plan**: Tasks completed on that day.
  - **🔥 Habit**: Habits completed on that day.
  - **📝 Journal**: Journal entry written on that day.
- **Day Inspector Modal**: Click on any date to inspect that day's tasks, completed habits, journal reflections, and Bible verse.

### 8. 📊 Progress & Analytics Dashboard (`progress.php`)
- **Daily KPIs**: Tasks planned, tasks finished, and daily execution rate.
- **Weekly & Monthly KPIs**: Goals achieved, habit logs, best habit streak, journal counts.
- **Interactive Visualizations (Chart.js)**:
  - 7-Day Habit Activity Bar Chart.
  - Mood Distribution Chart.

### 9. 🎨 Design System & Mobile Responsiveness
- Colors:
  - Primary: `#1F4D3A` (Deep Forest Pine)
  - Secondary: `#D4AF37` (Warm Gold / Brass)
  - Background: `#F7F8F5` (Soft Alabaster)
  - Cards: `#FFFFFF`
  - Text: `#1F2937`
  - Muted: `#6B7280`
- Sleek desktop sidebar (260px fixed width).
- Smooth mobile off-canvas navigation and hamburger menu.
- Large touch-friendly hit areas for checkboxes and buttons on mobile screens.

---

## 🗄️ Database Architecture (`database/lifetrack.sql`)

The database `lifetrack` contains 9 relational tables:

| Table | Purpose |
|---|---|
| `users` | User credentials, full name, email, password hash, timestamps. |
| `habits` | Habits created by users, frequencies, color indicators, active/archived status. |
| `habit_logs` | Daily completion logs per habit with unique `(habit_id, completion_date)` constraint. |
| `daily_plans` | Tasks assigned to dates with priority levels (`high`, `medium`, `low`) and notes. |
| `weekly_plans` | Weekly objectives tied to Monday `week_start` dates. |
| `journal_entries` | Private diary reflections, moods, gratitude lists, and daily lessons. |
| `bible_verses` | 120+ Scripture verses with themes and display dates. |
| `favorite_verses` | User-favorited scriptures linking `users` and `bible_verses`. |
| `notifications` | System feedback and milestone notifications. |

---

## 🚀 Installation & Setup (XAMPP)

### Step 1: Copy Project Files to XAMPP
Copy the entire `lifetrack` folder into your XAMPP Apache root directory:
```
C:\xampp\htdocs\lifetrack\
```

### Step 2: Start Apache and MySQL
1. Open the **XAMPP Control Panel**.
2. Click **Start** next to **Apache**.
3. Click **Start** next to **MySQL**.

### Step 3: Create Database & Import SQL
1. Open your browser and navigate to:
   ```
   http://localhost/phpmyadmin/
   ```
2. Click on **New** in the left sidebar.
3. Name the database: `lifetrack` and choose Collation `utf8mb4_unicode_ci`, then click **Create**.
4. With `lifetrack` selected, click the **Import** tab at the top.
5. Click **Choose File**, select `C:\xampp\htdocs\lifetrack\database\lifetrack.sql`, and click **Import** (or **Go**).
   *(All 9 tables and 120+ Bible verses will be created automatically).*

### Step 4: Verify Database Configuration
Open `config/database.php`. The default credentials work out of the box with standard XAMPP:
```php
define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', 'lifetrack');
define('DB_USER', 'root');
define('DB_PASS', '');
```
*If your MySQL root password is non-empty or uses a different port, update it here.*

### Step 5: Launch LifeTrack
Open your web browser and visit:
```
http://localhost/lifetrack/
```

---

## 👤 Creating Your First Account & Onboarding

1. Click **Get Started Free** or navigate to `http://localhost/lifetrack/register.php`.
2. Enter your Name, Email, and Password (at least 6 characters).
3. Upon registration, LifeTrack automatically sets up:
   - 4 foundational starter habits (*Morning Prayer & Reflection*, *Read Bible & Journal*, *Physical Exercise*, *Drink 2L Water*).
   - 3 initial focus tasks for today.
4. You will be redirected straight to your personalized dashboard!

---

## 💡 How Key Systems Work

### 1. Bible Verse Rotation
- Every day queries `SELECT * FROM bible_verses WHERE display_date = :today`.
- **Deterministic Fallback**: If a date has no explicit verse assigned (e.g., years in the future), LifeTrack calculates an integer hash of the date string: `abs(crc32($date)) % total_verses`.
- This guarantees that **any date** in the calendar always renders the exact same verse consistently, without randomly changing upon page refreshes!

### 2. Habit Streaks System
- **Current Streak**: Scans backwards starting from today (or yesterday if today is not yet checked). For every continuous previous day found in `habit_logs` with `completed = 1`, the streak counter increments by 1. If a day is missed, the streak resets to 0.
- **Longest Streak**: Iterates chronologically through all completed dates in history to determine the user's highest unbroken sequence.

---

## 🌐 Deploying to Production (cPanel / VPS / Cloud)

1. **Upload Files**: Upload the contents of `lifetrack/` to your web server's `public_html/` or subdomain directory.
2. **Create MySQL Database**: In cPanel or phpMyAdmin, create a new MySQL database and user with all privileges.
3. **Import SQL**: Import `database/lifetrack.sql` into your remote database.
4. **Update `config/database.php`**: Set your live database host, user, password, and database name.
5. **SSL (HTTPS)**: Ensure SSL is enabled. LifeTrack cookies are configured with `httponly` and secure flags.

---

## 📂 Project Directory Structure

```
lifetrack/
├── index.php                 # Landing page & feature showcase
├── login.php                 # Authentication login
├── register.php              # User registration with starter habit onboarding
├── logout.php                # Safe session termination
├── forgot-password.php       # Password reset flow
├── dashboard.php             # Core dashboard with verse, progress, tasks, habits
├── daily-plan.php            # Daily planner with date picker & priority filter
├── weekly-plan.php           # Weekly planner with 7-day schedule & goals
├── habits.php                # Habit tracker with 7-day matrix & streak counts
├── journal.php               # Diary & gratitude journal with mood tags & search
├── calendar.php              # Interactive monthly calendar with day inspector
├── progress.php              # Growth analytics & Chart.js visualizations
├── favorites.php             # Saved Bible verses
├── profile.php               # User profile & password settings
│
├── config/
│   └── database.php          # PDO connection singleton & graceful error handling
│
├── includes/
│   ├── auth.php              # Authentication guards & session management
│   ├── functions.php         # Streak calculator, Bible verse resolver, CSRF helpers
│   ├── header.php            # HTML head, typography, Bootstrap 5 CSS, favicon
│   ├── navbar.php            # Sticky top bar with quick actions & user menu
│   ├── sidebar.php           # Desktop navigation & mobile offcanvas drawer
│   └── footer.php            # Motivational motto, day modal, Chart.js & app.js
│
├── api/
│   ├── toggle-task.php       # AJAX endpoint for task check/uncheck
│   ├── toggle-habit.php      # AJAX endpoint for habit log & streak sync
│   ├── toggle-weekly-goal.php# AJAX endpoint for weekly goal check/uncheck
│   ├── toggle-favorite.php   # AJAX endpoint for Bible verse bookmarking
│   └── get-day-details.php   # AJAX endpoint for calendar day breakdown
│
├── assets/
│   ├── css/
│   │   └── style.css         # Custom SaaS design system & responsive styling
│   ├── js/
│   │   └── app.js            # AJAX handlers, toast alerts, calendar modal
│   └── images/
│       └── logo.svg          # High-resolution vector brand icon
│
├── database/
│   └── lifetrack.sql         # Complete schema, constraints, and 120+ verses
└── README.md                 # Full documentation & setup guide
```

---

## 🛡️ Security Highlights

- **Prepared Statements**: All database interactions use PDO parameter binding to prevent SQL Injection.
- **XSS Prevention**: All dynamic user-submitted content is sanitized using `htmlspecialchars(..., ENT_QUOTES, 'UTF-8')`.
- **CSRF Protection**: Form submissions and AJAX headers validate unique cryptographic session tokens.
- **Multi-Tenant Data Isolation**: Every read, write, update, and delete operation is strictly restricted to the authenticated `user_id`.
- **Graceful Error Handling**: Database connection issues or invalid requests output user-friendly guidance without ever exposing system paths, SQL queries, or credentials.

---

&copy; LifeTrack &bull; Plan. Build. Reflect. Grow.
