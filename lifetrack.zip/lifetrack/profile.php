<?php
/**
 * LifeTrack - User Profile & Account Settings
 */
require_once __DIR__ . '/includes/auth.php';

require_login();

$auth_user = get_auth_user();
$user_id = (int)$auth_user['id'];
$pdo = get_db();

$error = '';
$success = '';

// Handle Profile Updates & Password Change
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        set_flash('danger', 'Security session expired. Please try again.');
        header('Location: profile.php');
        exit;
    }

    if ($action === 'update_profile') {
        $full_name = trim($_POST['full_name'] ?? '');
        $email = trim($_POST['email'] ?? '');

        if (empty($full_name) || mb_strlen($full_name) < 2) {
            $error = 'Full name must be at least 2 characters.';
        } elseif (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Please provide a valid email address.';
        } else {
            // Check if email taken by someone else
            $check = $pdo->prepare("SELECT id FROM users WHERE email = :email AND id != :id LIMIT 1");
            $check->execute(['email' => strtolower($email), 'id' => $user_id]);
            if ($check->fetch()) {
                $error = 'This email address is already in use by another account.';
            } else {
                $upd = $pdo->prepare("UPDATE users SET full_name = :name, email = :email WHERE id = :id");
                $upd->execute([
                    'name' => $full_name,
                    'email' => strtolower($email),
                    'id' => $user_id
                ]);
                $_SESSION['user_name'] = $full_name;
                $_SESSION['user_email'] = strtolower($email);
                set_flash('success', 'Profile updated successfully.');
                header('Location: profile.php');
                exit;
            }
        }
    }

    if ($action === 'change_password') {
        $current_pass = $_POST['current_password'] ?? '';
        $new_pass = $_POST['new_password'] ?? '';
        $confirm_pass = $_POST['confirm_password'] ?? '';

        if (empty($current_pass) || empty($new_pass)) {
            $error = 'Please fill in all password fields.';
        } elseif (strlen($new_pass) < 6) {
            $error = 'New password must be at least 6 characters long.';
        } elseif ($new_pass !== $confirm_pass) {
            $error = 'New passwords do not match.';
        } else {
            // Verify current password
            $st = $pdo->prepare("SELECT password FROM users WHERE id = :id LIMIT 1");
            $st->execute(['id' => $user_id]);
            $current_hash = $st->fetchColumn();

            if (!password_verify($current_pass, $current_hash)) {
                $error = 'Current password entered is incorrect.';
            } else {
                $new_hash = password_hash($new_pass, PASSWORD_DEFAULT);
                $upd = $pdo->prepare("UPDATE users SET password = :hash WHERE id = :id");
                $upd->execute(['hash' => $new_hash, 'id' => $user_id]);
                set_flash('success', 'Password updated successfully.');
                header('Location: profile.php');
                exit;
            }
        }
    }
}

// Fetch user summary statistics
$task_count = (int)$pdo->query("SELECT COUNT(*) FROM daily_plans WHERE user_id = $user_id")->fetchColumn();
$habit_count = (int)$pdo->query("SELECT COUNT(*) FROM habits WHERE user_id = $user_id")->fetchColumn();
$journal_count = (int)$pdo->query("SELECT COUNT(*) FROM journal_entries WHERE user_id = $user_id")->fetchColumn();

$page_title = 'Account Profile - LifeTrack';
$page_heading = "Account Profile & Settings";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<main class="app-main">
    <?php require_once __DIR__ . '/includes/navbar.php'; ?>

    <div class="app-content">
        <?php $flash = get_flash(); if ($flash): ?>
            <div class="alert alert-<?= e($flash['type']) ?> alert-dismissible fade show mb-4 rounded-3 border-0 shadow-sm" role="alert">
                <i class="bi bi-info-circle-fill me-2"></i> <?= e($flash['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if (!empty($error)): ?>
            <div class="alert alert-danger alert-dismissible fade show mb-4 rounded-3 border-0 shadow-sm" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= e($error) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- User Identity Header Card -->
        <div class="card border-0 shadow-sm p-4 mb-4">
            <div class="d-flex flex-column flex-sm-row align-items-center gap-4">
                <div class="avatar-initial" style="width: 72px; height: 72px; font-size: 2rem; border-radius: 20px;">
                    <?= strtoupper(substr(e($auth_user['full_name']), 0, 1)) ?>
                </div>
                <div class="text-center text-sm-start flex-grow-1">
                    <h3 class="fw-bold text-dark mb-1"><?= e($auth_user['full_name']) ?></h3>
                    <p class="text-muted mb-2"><i class="bi bi-envelope me-1"></i> <?= e($auth_user['email']) ?></p>
                    <span class="badge bg-light text-muted border">
                        <i class="bi bi-calendar-check me-1"></i> Member since <?= e(format_date_short($auth_user['created_at'])) ?>
                    </span>
                </div>
                <div>
                    <a href="logout.php" class="btn btn-outline-danger btn-sm">
                        <i class="bi bi-box-arrow-right me-1"></i> Sign Out
                    </a>
                </div>
            </div>

            <!-- Activity Summary Badges -->
            <div class="row g-3 mt-3 pt-3 border-top text-center">
                <div class="col-4">
                    <div class="h5 fw-bold text-primary mb-0"><?= $task_count ?></div>
                    <small class="text-muted">Total Tasks Logged</small>
                </div>
                <div class="col-4">
                    <div class="h5 fw-bold text-warning mb-0"><?= $habit_count ?></div>
                    <small class="text-muted">Habits Tracked</small>
                </div>
                <div class="col-4">
                    <div class="h5 fw-bold text-success mb-0"><?= $journal_count ?></div>
                    <small class="text-muted">Journal Entries</small>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <!-- Profile Details Form -->
            <div class="col-lg-6">
                <div class="card border-0 shadow-sm h-100 p-4">
                    <h5 class="fw-bold text-dark mb-3"><i class="bi bi-person-gear text-primary me-2"></i> Update Personal Details</h5>
                    
                    <form method="POST" action="profile.php">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="update_profile">

                        <div class="mb-3">
                            <label for="fullNameInput" class="form-label fw-semibold small">Full Name</label>
                            <input type="text" id="fullNameInput" name="full_name" class="form-control" value="<?= e($auth_user['full_name']) ?>" required>
                        </div>

                        <div class="mb-4">
                            <label for="emailInput" class="form-label fw-semibold small">Email Address</label>
                            <input type="email" id="emailInput" name="email" class="form-control" value="<?= e($auth_user['email']) ?>" required>
                        </div>

                        <button type="submit" class="btn btn-primary">
                            Save Profile Changes
                        </button>
                    </form>
                </div>
            </div>

            <!-- Change Password Form -->
            <div class="col-lg-6">
                <div class="card border-0 shadow-sm h-100 p-4">
                    <h5 class="fw-bold text-dark mb-3"><i class="bi bi-shield-lock text-warning me-2"></i> Change Password</h5>
                    
                    <form method="POST" action="profile.php">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="change_password">

                        <div class="mb-3">
                            <label for="currPassInput" class="form-label fw-semibold small">Current Password</label>
                            <input type="password" id="currPassInput" name="current_password" class="form-control" placeholder="Enter current password" required>
                        </div>

                        <div class="mb-3">
                            <label for="newPassInput" class="form-label fw-semibold small">New Password</label>
                            <input type="password" id="newPassInput" name="new_password" class="form-control" placeholder="At least 6 characters" required>
                        </div>

                        <div class="mb-4">
                            <label for="confPassInput" class="form-label fw-semibold small">Confirm New Password</label>
                            <input type="password" id="confPassInput" name="confirm_password" class="form-control" placeholder="Re-enter new password" required>
                        </div>

                        <button type="submit" class="btn btn-outline-primary">
                            Update Password
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
