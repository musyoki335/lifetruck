<?php
/**
 * LifeTrack - AJAX API: Toggle Bible Verse Favorite
 */
header('Content-Type: application/json');

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized. Please log in.']);
    exit;
}

$user_id = current_user_id();
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid JSON payload.']);
    exit;
}

$verse_id = (int)($input['verse_id'] ?? 0);
$csrf_token = $input['csrf_token'] ?? '';

if (!verify_csrf_token($csrf_token)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Security token invalid or expired.']);
    exit;
}

if ($verse_id <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid verse ID.']);
    exit;
}

try {
    $pdo = get_db();

    // Check if verse exists
    $v_stmt = $pdo->prepare("SELECT id FROM bible_verses WHERE id = :id LIMIT 1");
    $v_stmt->execute(['id' => $verse_id]);
    if (!$v_stmt->fetch()) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Verse not found.']);
        exit;
    }

    // Check if currently favorited
    $check_stmt = $pdo->prepare("SELECT id FROM favorite_verses WHERE user_id = :user_id AND verse_id = :verse_id LIMIT 1");
    $check_stmt->execute(['user_id' => $user_id, 'verse_id' => $verse_id]);
    $fav_id = $check_stmt->fetchColumn();

    if ($fav_id) {
        // Remove favorite
        $del_stmt = $pdo->prepare("DELETE FROM favorite_verses WHERE id = :id AND user_id = :user_id");
        $del_stmt->execute(['id' => $fav_id, 'user_id' => $user_id]);
        $favorited = false;
    } else {
        // Add favorite
        $ins_stmt = $pdo->prepare("INSERT INTO favorite_verses (user_id, verse_id) VALUES (:user_id, :verse_id)");
        $ins_stmt->execute(['user_id' => $user_id, 'verse_id' => $verse_id]);
        $favorited = true;
    }

    echo json_encode([
        'success' => true,
        'verse_id' => $verse_id,
        'favorited' => $favorited
    ]);
} catch (Exception $e) {
    error_log("toggle-favorite error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error occurred.']);
}
