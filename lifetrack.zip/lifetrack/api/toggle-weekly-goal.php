<?php
/**
 * LifeTrack - AJAX API: Toggle Weekly Goal Completion
 */
header('Content-Type: application/json');

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized. Please log in.']);
    exit;
}

$user_id = current_user_id();
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid JSON payload.']);
    exit;
}

$goal_id = (int)($input['goal_id'] ?? 0);
$completed = !empty($input['completed']) ? 1 : 0;
$csrf_token = $input['csrf_token'] ?? '';

if (!verify_csrf_token($csrf_token)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Security token invalid or expired.']);
    exit;
}

if ($goal_id <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid goal ID.']);
    exit;
}

try {
    $pdo = get_db();

    // Verify goal belongs to user
    $check_stmt = $pdo->prepare("SELECT week_start FROM weekly_plans WHERE id = :id AND user_id = :user_id LIMIT 1");
    $check_stmt->execute(['id' => $goal_id, 'user_id' => $user_id]);
    $week_start = $check_stmt->fetchColumn();

    if (!$week_start) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Weekly goal not found.']);
        exit;
    }

    $update_stmt = $pdo->prepare("UPDATE weekly_plans SET completed = :completed WHERE id = :id AND user_id = :user_id");
    $update_stmt->execute([
        'completed' => $completed,
        'id' => $goal_id,
        'user_id' => $user_id
    ]);

    // Recalculate completion rate for this week
    $stats_stmt = $pdo->prepare("
        SELECT 
            COUNT(*) AS total,
            SUM(CASE WHEN completed = 1 THEN 1 ELSE 0 END) AS completed
        FROM weekly_plans 
        WHERE user_id = :user_id AND week_start = :week_start
    ");
    $stats_stmt->execute(['user_id' => $user_id, 'week_start' => $week_start]);
    $stats = $stats_stmt->fetch();

    $total = (int)($stats['total'] ?? 0);
    $completed_count = (int)($stats['completed'] ?? 0);
    $completion_rate = $total > 0 ? (int)round(($completed_count / $total) * 100) : 0;

    echo json_encode([
        'success' => true,
        'goal_id' => $goal_id,
        'completed' => $completed,
        'completed_count' => $completed_count,
        'total_count' => $total,
        'completion_rate' => $completion_rate
    ]);
} catch (Exception $e) {
    error_log("toggle-weekly-goal error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error occurred.']);
}
