<?php
/**
 * LifeTrack - AJAX API: Get Day Details for Calendar Inspector
 */
header('Content-Type: application/json');

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized.']);
    exit;
}

$user_id = current_user_id();
$date = $_GET['date'] ?? date('Y-m-d');

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid date format.']);
    exit;
}

try {
    $pdo = get_db();

    // 1. Get tasks for this date
    $task_stmt = $pdo->prepare("
        SELECT id, task, priority, completed, notes 
        FROM daily_plans 
        WHERE user_id = :user_id AND plan_date = :plan_date
        ORDER BY completed ASC, priority DESC, id ASC
    ");
    $task_stmt->execute(['user_id' => $user_id, 'plan_date' => $date]);
    $tasks = $task_stmt->fetchAll();

    // 2. Get habits logged for this date
    $habit_stmt = $pdo->prepare("
        SELECT h.name, h.color 
        FROM habit_logs hl
        JOIN habits h ON hl.habit_id = h.id
        WHERE hl.user_id = :user_id AND hl.completion_date = :date AND hl.completed = 1
    ");
    $habit_stmt->execute(['user_id' => $user_id, 'date' => $date]);
    $habits = $habit_stmt->fetchAll();

    // 3. Get journal entry for this date
    $j_stmt = $pdo->prepare("
        SELECT id, title, content, mood, gratitude, lessons 
        FROM journal_entries 
        WHERE user_id = :user_id AND entry_date = :entry_date
        LIMIT 1
    ");
    $j_stmt->execute(['user_id' => $user_id, 'entry_date' => $date]);
    $journal = $j_stmt->fetch();

    // 4. Get Bible verse
    $verse = get_daily_verse($pdo, $date, $user_id);

    // Build HTML representation for modal
    ob_start();
    ?>
    <div class="day-details-container">
        <!-- Verse for the day -->
        <div class="p-3 mb-4 rounded-3 text-white" style="background: linear-gradient(135deg, #1F4D3A, #285E47);">
            <div class="small text-uppercase fw-bold text-warning mb-1"><i class="bi bi-book"></i> Verse for <?= e(format_date_short($date)) ?></div>
            <div class="fst-italic mb-1">"<?= e($verse['verse_text']) ?>"</div>
            <div class="small text-warning-subtle fw-semibold text-end">— <?= e($verse['reference']) ?></div>
        </div>

        <div class="row g-4">
            <!-- Tasks Section -->
            <div class="col-md-6">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-header bg-white border-bottom py-2 d-flex justify-content-between align-items-center">
                        <span class="fw-bold text-dark"><i class="bi bi-check2-square text-success me-1"></i> Daily Tasks</span>
                        <span class="badge bg-light text-dark border"><?= count($tasks) ?></span>
                    </div>
                    <div class="card-body p-3">
                        <?php if (empty($tasks)): ?>
                            <p class="text-muted small mb-0 fst-italic">No tasks planned for this day.</p>
                        <?php else: ?>
                            <ul class="list-unstyled mb-0">
                                <?php foreach ($tasks as $t): ?>
                                    <li class="d-flex align-items-center mb-2 small">
                                        <i class="bi <?= $t['completed'] ? 'bi-check-circle-fill text-success' : 'bi-circle text-muted' ?> me-2"></i>
                                        <span class="<?= $t['completed'] ? 'text-decoration-line-through text-muted' : 'fw-medium' ?>">
                                            <?= e($t['task']) ?>
                                        </span>
                                        <span class="ms-auto badge priority-<?= e($t['priority']) ?>" style="font-size: 0.65rem;">
                                            <?= strtoupper(e($t['priority'])) ?>
                                        </span>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Habits Section -->
            <div class="col-md-6">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-header bg-white border-bottom py-2 d-flex justify-content-between align-items-center">
                        <span class="fw-bold text-dark"><i class="bi bi-fire text-warning me-1"></i> Completed Habits</span>
                        <span class="badge bg-light text-dark border"><?= count($habits) ?></span>
                    </div>
                    <div class="card-body p-3">
                        <?php if (empty($habits)): ?>
                            <p class="text-muted small mb-0 fst-italic">No habits logged on this day.</p>
                        <?php else: ?>
                            <div class="d-flex flex-wrap gap-2">
                                <?php foreach ($habits as $h): ?>
                                    <span class="badge d-inline-flex align-items-center gap-1 p-2" style="background-color: #E8EFEA; color: #1F4D3A; border: 1px solid #C4D9CD;">
                                        <i class="bi bi-check-circle-fill text-success"></i> <?= e($h['name']) ?>
                                    </span>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Journal Section -->
            <div class="col-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white border-bottom py-2 d-flex justify-content-between align-items-center">
                        <span class="fw-bold text-dark"><i class="bi bi-journal-text text-primary me-1"></i> Journal Entry</span>
                        <?php if ($journal): 
                            $mood_info = get_mood_details($journal['mood']);
                        ?>
                            <span class="badge bg-light text-dark border"><?= $mood_info['emoji'] ?> <?= $mood_info['label'] ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="card-body p-3">
                        <?php if (!$journal): ?>
                            <p class="text-muted small mb-0 fst-italic">No journal entry recorded for this day.</p>
                        <?php else: ?>
                            <h6 class="fw-bold text-dark mb-2"><?= e($journal['title']) ?></h6>
                            <p class="text-secondary small mb-3"><?= nl2br(e($journal['content'])) ?></p>
                            
                            <?php if (!empty($journal['gratitude'])): ?>
                                <div class="p-2 mb-2 rounded bg-light border-start border-3 border-warning small">
                                    <strong><i class="bi bi-heart text-danger me-1"></i> Gratitude:</strong> <?= e($journal['gratitude']) ?>
                                </div>
                            <?php endif; ?>

                            <?php if (!empty($journal['lessons'])): ?>
                                <div class="p-2 rounded bg-light border-start border-3 border-success small">
                                    <strong><i class="bi bi-lightbulb text-warning me-1"></i> Lesson Learned:</strong> <?= e($journal['lessons']) ?>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
    $html = ob_get_clean();

    echo json_encode([
        'success' => true,
        'date' => $date,
        'html' => $html
    ]);
} catch (Exception $e) {
    error_log("get-day-details error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error retrieving day details.']);
}
