<?php
/**
 * LifeTrack - AJAX API: Toggle Habit Completion Log
 */
header('Content-Type: application/json');

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized. Please log in.']);
    exit;
}

$user_id = current_user_id();
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid JSON payload.']);
    exit;
}

$habit_id = (int)($input['habit_id'] ?? 0);
$date = !empty($input['date']) ? trim($input['date']) : date('Y-m-d');
$completed = !empty($input['completed']) ? 1 : 0;
$csrf_token = $input['csrf_token'] ?? '';

if (!verify_csrf_token($csrf_token)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Security token invalid or expired.']);
    exit;
}

if ($habit_id <= 0 || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid habit ID or date format.']);
    exit;
}

try {
    $pdo = get_db();

    // Verify habit belongs to user
    $h_stmt = $pdo->prepare("SELECT id FROM habits WHERE id = :id AND user_id = :user_id LIMIT 1");
    $h_stmt->execute(['id' => $habit_id, 'user_id' => $user_id]);
    if (!$h_stmt->fetch()) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Habit not found or access denied.']);
        exit;
    }

    if ($completed === 1) {
        // Upsert log as completed
        $log_stmt = $pdo->prepare("
            INSERT INTO habit_logs (habit_id, user_id, completion_date, completed)
            VALUES (:habit_id, :user_id, :completion_date, 1)
            ON DUPLICATE KEY UPDATE completed = 1
        ");
        $log_stmt->execute([
            'habit_id' => $habit_id,
            'user_id' => $user_id,
            'completion_date' => $date
        ]);
    } else {
        // Remove completion record
        $del_stmt = $pdo->prepare("
            DELETE FROM habit_logs 
            WHERE habit_id = :habit_id AND user_id = :user_id AND completion_date = :completion_date
        ");
        $del_stmt->execute([
            'habit_id' => $habit_id,
            'user_id' => $user_id,
            'completion_date' => $date
        ]);
    }

    // Recalculate streak
    $streaks = calculate_habit_streak($pdo, $habit_id, $user_id);

    echo json_encode([
        'success' => true,
        'habit_id' => $habit_id,
        'date' => $date,
        'completed' => $completed,
        'current_streak' => $streaks['current_streak'],
        'longest_streak' => $streaks['longest_streak'],
        'completion_rate' => $streaks['completion_rate']
    ]);
} catch (Exception $e) {
    error_log("toggle-habit error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'A database error occurred.']);
}
