<?php
/**
 * LifeTrack - AJAX API: Toggle Daily Task Status
 */
header('Content-Type: application/json');

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized. Please log in.']);
    exit;
}

$user_id = current_user_id();
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid JSON payload.']);
    exit;
}

$task_id = (int)($input['task_id'] ?? 0);
$completed = !empty($input['completed']) ? 1 : 0;
$csrf_token = $input['csrf_token'] ?? '';

if (!verify_csrf_token($csrf_token)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Security token invalid or expired.']);
    exit;
}

if ($task_id <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid task ID.']);
    exit;
}

try {
    $pdo = get_db();

    // Verify task belongs to current user and get its plan_date
    $check_stmt = $pdo->prepare("SELECT plan_date FROM daily_plans WHERE id = :id AND user_id = :user_id LIMIT 1");
    $check_stmt->execute(['id' => $task_id, 'user_id' => $user_id]);
    $plan_date = $check_stmt->fetchColumn();

    if (!$plan_date) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Task not found or access denied.']);
        exit;
    }

    // Update status
    $update_stmt = $pdo->prepare("UPDATE daily_plans SET completed = :completed WHERE id = :id AND user_id = :user_id");
    $update_stmt->execute([
        'completed' => $completed,
        'id' => $task_id,
        'user_id' => $user_id
    ]);

    // Recalculate daily stats for that date
    $stats_stmt = $pdo->prepare("
        SELECT 
            COUNT(*) AS total,
            SUM(CASE WHEN completed = 1 THEN 1 ELSE 0 END) AS completed
        FROM daily_plans 
        WHERE user_id = :user_id AND plan_date = :plan_date
    ");
    $stats_stmt->execute(['user_id' => $user_id, 'plan_date' => $plan_date]);
    $stats = $stats_stmt->fetch();

    $total = (int)($stats['total'] ?? 0);
    $completed_count = (int)($stats['completed'] ?? 0);
    $completion_rate = $total > 0 ? (int)round(($completed_count / $total) * 100) : 0;

    echo json_encode([
        'success' => true,
        'task_id' => $task_id,
        'completed' => $completed,
        'completed_count' => $completed_count,
        'total_count' => $total,
        'completion_rate' => $completion_rate
    ]);
} catch (Exception $e) {
    error_log("toggle-task error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'A database error occurred.']);
}
